#!/usr/bin/env python3
"""One-Tap Launcher for Pydroid 3 (Android) & Standard Python.
Open this file (or bot.py) in Pydroid 3 and press the Yellow Play Button!
"""
import os
import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).parent.resolve()
os.chdir(BASE_DIR)

REQUIRED_PACKAGES = [
    ("requests", "requests"),
    ("urllib3", "urllib3"),
    ("socks", "PySocks"),
    ("cryptography", "cryptography"),
    ("asn1crypto", "asn1crypto"),
]

def ensure_dependencies():
    missing = []
    for mod_name, pip_name in REQUIRED_PACKAGES:
        try:
            __import__(mod_name)
        except ImportError:
            missing.append(pip_name)
    if missing:
        print(f"📦 Installing missing packages for Pydroid 3: {', '.join(missing)}...")
        for pkg in missing:
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])
            except Exception as e:
                print(f"⚠️ Could not auto-install {pkg}: {e}")

if __name__ == "__main__":
    ensure_dependencies()
    import bot
    bot.VexorBot().run()
