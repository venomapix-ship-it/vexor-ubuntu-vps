# VEXOR Mk2 — Multi-Checker Telegram Bot (Auto-Queue & Smart Proxy Cascade)

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Environment (Optional if set in `config.py`)
```bash
cp .env.example .env
# Edit .env with your VEXOR_BOT_TOKEN and VEXOR_ADMIN_ID
```

### 3. Run the Bot
```bash
bash start.sh
# or directly:
python3 bot.py
```

## Key Features
- **Multi-File Auto-Queue System**: Upload 2, 3, or more `.txt` / `.zip` combo files at the same time. Choose the desired scan mode for each file, and the bot will automatically queue them and run them sequentially without losing any file.
  - `/queue` — View waiting files in your queue
  - `/clearqueue` — Clear waiting files
- **Smart 3-Tier Proxy Cascade**:
  1. **Attempt 1**: Uses a Static IP proxy from `Working_Proxies_99.txt` (Type 1).
  2. **Attempt 2 (on error / rate-limit)**: Switches to a different Static IP proxy from `Working_Proxies_99.txt` (Type 1).
  3. **Attempt 3+ (if still rate-limited / failing)**: Automatically escalates to the Residential Rotating Proxy (`proxy.op.wtf:58996`) with a fresh random `sid` (new residential IP on every attempt).
- **Always-On Full Debug Logging**:
  - No `/debug*` toggle commands needed — full debug is enabled permanently across all services.
  - Master full bot debug log: `./bot_debug.log` (and `./vexor_bot.log`)
  - Per-service dedicated debug logs inside `./logs/`:
    - `logs/bot_core_debug.log` — Bot engine, API requests, callbacks, and queue events
    - `logs/hotmail_debug.log` — Hotmail / Outlook OAuth & Substrate inbox debug
    - `logs/imap_debug.log` — MixMail (IMAP) connection, DNS, and login debug
    - `logs/xbox_debug.log` — Xbox Live, GamePass, Minecraft, and payment cards debug
    - `logs/crunchyroll_debug.log` — Crunchyroll token & subscription tier debug
    - `logs/capcut_debug.log` — CapCut check_email, login, CSRF, and VIP plan debug
    - `logs/proxy_debug.log` — Static & Residential proxy cascade events
