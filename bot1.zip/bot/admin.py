"""Admin commands + admin callback handler (Debug always active — no toggle commands)."""
import re
import threading
import time

import config
from config import (
    BASE_DIR,
    add_allowed,
    add_banned,
    esc_html,
    get_user_stats,
    list_allowed,
    list_banned,
    load_stats,
    remove_allowed,
    remove_banned,
)

# ── animated emoji for admin screens ──────────────────────────────────────────────
_ADMIN_P: dict = {
    "📊": "5884161133174067365",
    "👥": "5258513401784573443",
    "🔄": "5260687119092817530",
    "🛑": "5420323339723881652",
    "✅": "5920052658743283381",
    "❌": "5258226313285607065",
    "🔍": "5260341314095947411",
    "📢": "5116445341150872576",
    "⚠️": "5258474669769497337",
    "🤵": "4949560993840629085",
}


def _pe(c: str) -> str:
  eid = _ADMIN_P.get(c)
  return f'<tg-emoji emoji-id="{eid}">{c}</tg-emoji>' if eid else c


def _is_admin(msg):
  return msg.get("from", {}).get("id") == config.ADMIN_ID


def _reply(bot, chat_id, html):
  bot.api.send_rich(chat_id, html)


# ═══════════════ COMMANDS ═══════════════
def cmd_allow(bot, msg):
  if not _is_admin(msg):
    _reply(bot, msg["chat"]["id"], "🚫 <b>Admin only.</b>")
    return
  parts = (msg.get("text") or "").split()
  if len(parts) != 2:
    _reply(bot, msg["chat"]["id"], "Usage: <code>/allow user_id</code>")
    return
  try:
    uid = int(parts[1])
  except ValueError:
    _reply(bot, msg["chat"]["id"], "❌ <b>Invalid ID.</b>")
    return
  add_allowed(uid)
  _reply(
      bot,
      msg["chat"]["id"],
      f"✅ <b>Allowed</b> <code>{uid}</code>\n"
      f"Total: <code>{len(list_allowed())}</code>",
  )


def cmd_deny(bot, msg):
  if not _is_admin(msg):
    _reply(bot, msg["chat"]["id"], "🚫 <b>Admin only.</b>")
    return
  parts = (msg.get("text") or "").split()
  if len(parts) != 2:
    _reply(bot, msg["chat"]["id"], "Usage: <code>/deny user_id</code>")
    return
  try:
    uid = int(parts[1])
  except ValueError:
    _reply(bot, msg["chat"]["id"], "❌ <b>Invalid ID.</b>")
    return

  if uid == config.ADMIN_ID:
    _reply(bot, msg["chat"]["id"], "❌ <b>Cannot remove admin.</b>")
    return

  allowed = set(list_allowed())
  if uid not in allowed:
    _reply(
        bot,
        msg["chat"]["id"],
        f"⚠️ <b>User <code>{uid}</code> not in allowed list.</b>",
    )
    return

  remove_allowed(uid)
  _reply(bot, msg["chat"]["id"], f"✅ <b>Removed</b> <code>{uid}</code>")


def cmd_ban(bot, msg):
  """Permanently block a user from using the bot."""
  if not _is_admin(msg):
    _reply(bot, msg["chat"]["id"], "🚫 <b>Admin only.</b>")
    return
  parts = (msg.get("text") or "").split()
  if len(parts) != 2:
    _reply(bot, msg["chat"]["id"], "Usage: <code>/ban user_id</code>")
    return
  try:
    uid = int(parts[1])
  except ValueError:
    _reply(bot, msg["chat"]["id"], "❌ <b>Invalid ID.</b>")
    return
  if uid == config.ADMIN_ID:
    _reply(bot, msg["chat"]["id"], "❌ <b>Cannot ban admin.</b>")
    return
  add_banned(uid)
  remove_allowed(uid)
  _reply(bot, msg["chat"]["id"], f"🔨 <b>Banned</b> <code>{uid}</code>")


def cmd_unban(bot, msg):
  """Unban a previously banned user."""
  if not _is_admin(msg):
    _reply(bot, msg["chat"]["id"], "🚫 <b>Admin only.</b>")
    return
  parts = (msg.get("text") or "").split()
  if len(parts) != 2:
    _reply(bot, msg["chat"]["id"], "Usage: <code>/unban user_id</code>")
    return
  try:
    uid = int(parts[1])
  except ValueError:
    _reply(bot, msg["chat"]["id"], "❌ <b>Invalid ID.</b>")
    return
  remove_banned(uid)
  _reply(bot, msg["chat"]["id"], f"✅ <b>Unbanned</b> <code>{uid}</code>")


def cmd_listbanned(bot, msg):
  if not _is_admin(msg):
    _reply(bot, msg["chat"]["id"], "🚫 <b>Admin only.</b>")
    return
  banned = list_banned()
  if not banned:
    _reply(bot, msg["chat"]["id"], "ℹ️ <b>No banned users.</b>")
    return
  with bot.usernames_lock:
    unames = dict(bot.usernames)

  def _bline(uid):
    e = unames.get(uid, {})
    nm = esc_html(e.get("name", ""))
    un = e.get("uname", "")
    lbl = (f" — <b>{nm}</b>" + (f" @{un}" if un else "")) if nm else ""
    return f"<code>{uid}</code>{lbl}"

  lines = [_bline(u) for u in banned[:100]]
  more = f"\n<i>…and {len(banned)-100} more</i>" if len(banned) > 100 else ""
  _reply(
      bot,
      msg["chat"]["id"],
      f"🔨 <b>Banned Users ({len(banned)})</b>\n\n" + "\n".join(lines) + more,
  )


def cmd_listusers(bot, msg):
  if not _is_admin(msg):
    _reply(bot, msg["chat"]["id"], "🚫 <b>Admin only.</b>")
    return
  users = list_allowed()
  if not users:
    _reply(bot, msg["chat"]["id"], "ℹ️ <b>No users.</b>")
    return
  lines = [f"<code>{u}</code>" for u in users[:200]]
  _reply(
      bot,
      msg["chat"]["id"],
      f"{_pe('👥')} <b>Allowed Users ({len(users)})</b>\n"
      f"<pre>vexor • allowed</pre>\n\n"
      + "\n".join(lines),
  )


def cmd_broadcast(bot, msg):
  if not _is_admin(msg):
    _reply(bot, msg["chat"]["id"], "🚫 <b>Admin only.</b>")
    return
  text = msg.get("text") or ""
  parts = text.split(None, 1)
  body = parts[1].strip() if len(parts) > 1 else ""
  if not body:
    _reply(
        bot, msg["chat"]["id"], "Usage: <code>/broadcast your message</code>"
    )
    return
  users = list_allowed()
  chat_id = msg["chat"]["id"]
  _reply(bot, chat_id, f"📢 <b>Broadcasting to {len(users)} users…</b>")

  def _do_broadcast():
    ok = 0
    fail = 0
    has_tags = bool(re.search(r"</?[a-zA-Z]", body))
    safe_body = body if has_tags else esc_html(body)
    for uid in users:
      try:
        r = bot.api.send_rich(uid, safe_body)
        if r.get("ok"):
          ok += 1
        else:
          fail += 1
        time.sleep(0.05)
      except Exception:
        fail += 1
    _reply(bot, chat_id, f"📢 <b>Broadcast done</b>\n✅ {ok} | ❌ {fail}")

  threading.Thread(target=_do_broadcast, daemon=True).start()


def cmd_killjob(bot, msg):
  """Cancel one specific job by chat_id."""
  if not _is_admin(msg):
    _reply(bot, msg["chat"]["id"], "🚫 <b>Admin only.</b>")
    return
  parts = (msg.get("text") or "").split()
  if len(parts) != 2:
    _reply(bot, msg["chat"]["id"], "Usage: <code>/killjob chat_id</code>")
    return
  try:
    target = int(parts[1])
  except ValueError:
    _reply(bot, msg["chat"]["id"], "❌ <b>Invalid ID.</b>")
    return
  with bot.active_lock:
    job = bot.active.get(target)
  if not job:
    _reply(
        bot,
        msg["chat"]["id"],
        f"⚠️ <b>No active job for <code>{target}</code>.</b>",
    )
    return
  job.cancelled = True
  _reply(
      bot,
      msg["chat"]["id"],
      f"🛑 <b>Cancelled job for <code>{target}</code>.</b>",
  )


def cmd_userstats(bot, msg):
  """/userstats user_id — admin lookup for a specific user's stats."""
  if not _is_admin(msg):
    _reply(bot, msg["chat"]["id"], "🚫 <b>Admin only.</b>")
    return
  parts = (msg.get("text") or "").split()
  if len(parts) != 2:
    _reply(bot, msg["chat"]["id"], "Usage: <code>/userstats user_id</code>")
    return
  try:
    uid = int(parts[1])
  except ValueError:
    _reply(bot, msg["chat"]["id"], "❌ <b>Invalid ID.</b>")
    return
  s = get_user_stats(uid)
  name = "Unknown"
  if hasattr(bot, "usernames"):
    with bot.usernames_lock:
      name = bot.usernames.get(uid, {}).get("name", "Unknown")
  by_mode = s.get("by_mode", {})
  mode_lines = (
      "\n".join(
          f"  • {m}: <code>{v}</code>" for m, v in sorted(by_mode.items())
      )
      or "  (no data)"
  )
  _reply(
      bot,
      msg["chat"]["id"],
      f"{_pe('📊')} <b>Stats: {esc_html(str(name))}</b>\n"
      f"<pre>vexor • user stats</pre>\n\n"
      f"<blockquote>"
      f"🆔 <code>{uid}</code>\n"
      f"Jobs:   <code>{s['jobs']}</code>\n"
      f"Valid:  <code>{s['valid']}</code>\n"
      f"Combos: <code>{s['combos']}</code>"
      f"</blockquote>\n\n"
      f"<b>By mode:</b>\n{mode_lines}",
  )




def cmd_logs(bot, msg):
  """Package all debug logs (bot_debug.log + logs/*.log) and send as a ZIP to admin."""
  if not _is_admin(msg):
    _reply(bot, msg["chat"]["id"], "🚫 <b>Admin only.</b>")
    return
  import io, zipfile
  from pathlib import Path
  buf = io.BytesIO()
  count = 0
  with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
    for p in [BASE_DIR / "bot_debug.log", BASE_DIR / "vexor_bot.log"] + sorted((BASE_DIR / "logs").glob("*.log")):
      if p.exists() and p.stat().st_size > 0:
        zf.writestr(p.name, p.read_bytes())
        count += 1
  if count == 0:
    _reply(bot, msg["chat"]["id"], "ℹ️ <b>No debug logs generated yet.</b>")
    return
  buf.seek(0)
  bot.api.send_zip(
      msg["chat"]["id"],
      buf,
      filename=f"vexor_debug_logs_{int(time.time())}.zip",
      caption=f"{_pe('🔍')} <b>Full Bot & Service Debug Logs ({count} files)</b>",
  )


def cmd_proxies(bot, msg):
  """Show static & residential proxy cascade health status."""
  if not _is_admin(msg):
    _reply(bot, msg["chat"]["id"], "🚫 <b>Admin only.</b>")
    return
  tot, healthy, quar = config.get_proxy_health_summary()
  ok_res, res_info = config.verify_proxy_sample()
  _reply(
      bot,
      msg["chat"]["id"],
      f"{_pe('📊')} <b>Proxy Cascade Status</b>\n"
      f"<pre>vexor • proxy health</pre>\n\n"
      f"<blockquote>"
      f"🔹 <b>Type 1 (Static Pool):</b> <code>{healthy}/{tot}</code> healthy (<code>{quar}</code> on 60s cooldown)\n"
      f"🔹 <b>Type 2 (Residential SID):</b> <code>{'ONLINE' if ok_res else 'CHECK'}</code>\n"
      f"📡 <b>Sample Check:</b> <code>{esc_html(res_info)}</code>"
      f"</blockquote>",
  )


# ═══════════════ CALLBACKS ═══════════════
def handle_admin_callback(bot, cb, data):
  chat_id = cb.get("message", {}).get("chat", {}).get("id")
  msg_id = cb.get("message", {}).get("message_id")
  user_id = cb.get("from", {}).get("id")

  if user_id != config.ADMIN_ID:
    bot.api.answer_callback(cb["id"], text="🚫 Admin only", alert=True)
    return

  if data == "admin_stats":
    stats = load_stats()
    total_jobs = sum(s.get("jobs", 0) for s in stats.values())
    total_valid = sum(s.get("valid", 0) for s in stats.values())
    total_combos = sum(s.get("combos", 0) for s in stats.values())
    ratio = f"{total_valid * 100 / total_combos:.1f}%" if total_combos else "0%"
    top = sorted(stats.items(), key=lambda x: -x[1].get("valid", 0))[:5]
    top_lines = "\n".join(
        f"  • <code>{uid}</code>: {s.get('valid', 0)} valid / "
        f"{s.get('combos', 0)} combos"
        for uid, s in top
    )
    mode_breakdown = {}
    for _, s in stats.items():
      for mode, count in s.get("by_mode", {}).items():
        mode_breakdown[mode] = mode_breakdown.get(mode, 0) + count
    mode_lines = (
        "\n".join(
            f"  • {m}: <code>{v}</code>"
            for m, v in sorted(mode_breakdown.items(), key=lambda x: -x[1])
        )
        or "  (no data)"
    )
    bot.api.edit_rich(
        chat_id,
        msg_id,
        f"{_pe('📊')} <b>Global Statistics</b>\n"
        f"<pre>vexor • global stats</pre>\n\n"
        f"<blockquote>"
        f"{_pe('👥')} Users:    <code>{len(stats)}</code>\n"
        f"{_pe('🔍')} Jobs:     <code>{total_jobs}</code>\n"
        f"{_pe('✅')} Valid:    <code>{total_valid}</code>\n"
        f"{_pe('📊')} Combos:   <code>{total_combos}</code>\n"
        f"📈 Hit Rate: <code>{ratio}</code>"
        f"</blockquote>\n\n"
        f"<b>Top 5:</b>\n{top_lines or '  (none)'}\n\n"
        f"<b>By mode:</b>\n{mode_lines}",
        bot.admin_menu_kb(),
    )

  elif data == "admin_jobs":
    with bot.active_lock:
      actives = list(bot.active.values())
    with bot.queue_lock:
      total_queued = sum(len(q) for q in bot.job_queues.values())
    if not actives and not total_queued:
      bot.api.edit_rich(
          chat_id,
          msg_id,
          f"{_pe('🔄')} <b>No active or queued jobs.</b>",
          bot.admin_menu_kb(),
      )
      return
    lines = []
    for j in actives[:30]:
      with j.lock:
        elapsed = int(time.time() - j.start_time)
        pct = int(j.processed * 100 / j.total) if j.total else 0
        lines.append(
            f"  • <code>{j.chat_id}</code> — {j.mode_label} (<code>{esc_html(j.file_label)}</code>)\n"
            f"    <code>{j.processed}/{j.total}</code> ({pct}%) "
            f"✅{j.valid} ❌{j.bad} | {elapsed}s"
        )
    more_line = (
        f"\n\n<i>…and {len(actives)-30} more</i>" if len(actives) > 30 else ""
    )
    bot.api.edit_rich(
        chat_id,
        msg_id,
        f"{_pe('🔄')} <b>Active Jobs ({len(actives)}) | Queued ({total_queued})</b>\n"
        f"<pre>vexor • live jobs</pre>\n\n"
        + ("\n".join(lines) if lines else "<i>No active jobs running right now.</i>")
        + more_line,
        bot.admin_menu_kb(),
    )

  elif data == "admin_users":
    users = list_allowed()
    with bot.usernames_lock:
      unames = dict(bot.usernames)

    def _uline(uid):
      e = unames.get(uid, {})
      nm = esc_html(e.get("name", ""))
      un = e.get("uname", "")
      lbl = (f" — <b>{nm}</b>" + (f" @{un}" if un else "")) if nm else ""
      return f"<code>{uid}</code>{lbl}"

    more_u = f"\n<i>…and {len(users)-100} more</i>" if len(users) > 100 else ""
    bot.api.edit_rich(
        chat_id,
        msg_id,
        f"{_pe('👥')} <b>Allowed Users ({len(users)})</b>\n"
        f"<pre>vexor • user list</pre>\n\n"
        + "\n".join(_uline(u) for u in users[:100])
        + more_u,
        bot.admin_menu_kb(),
    )

  elif data == "admin_broadcast":
    bot.api.edit_rich(
        chat_id,
        msg_id,
        f"{_pe('📢')} <b>Broadcast</b>\n"
        f"<pre>vexor • broadcast</pre>\n\n"
        f"<blockquote>Send:\n<code>/broadcast your message here</code>\n"
        f"Delivers to <b>{len(list_allowed())}</b> users.</blockquote>",
        bot.admin_menu_kb(),
    )

  elif data == "admin_logs":
    cmd_logs(bot, {"chat": {"id": chat_id}, "from": {"id": user_id}})

  elif data == "admin_proxies":
    tot, healthy, quar = config.get_proxy_health_summary()
    ok_res, res_info = config.verify_proxy_sample()
    bot.api.edit_rich(
        chat_id,
        msg_id,
        f"{_pe('📊')} <b>Proxy Cascade Status</b>\n"
        f"<pre>vexor • proxy health</pre>\n\n"
        f"<blockquote>"
        f"🔹 <b>Type 1 (Static Pool):</b> <code>{healthy}/{tot}</code> healthy (<code>{quar}</code> cooldown)\n"
        f"🔹 <b>Type 2 (Residential SID):</b> <code>{esc_html(res_info)}</code>"
        f"</blockquote>",
        bot.admin_menu_kb(),
    )

  elif data == "admin_stopall":
    with bot.active_lock:
      count = len(bot.active)
      for j in bot.active.values():
        j.cancelled = True
    with bot.queue_lock:
      q_count = sum(len(q) for q in bot.job_queues.values())
      for cid in list(bot.job_queues.keys()):
        bot.job_queues[cid].clear()
        config.save_user_queue(cid, [])
    bot.api.edit_rich(
        chat_id,
        msg_id,
        f"{_pe('🛑')} <b>Cancelled {count} active job(s) & cleared {q_count} queued file(s).</b>",
        bot.admin_menu_kb(),
    )

  else:
    bot.api.edit_rich(
        chat_id,
        msg_id,
        f"{_pe('⚠️')} <b>Unknown action.</b>",
        bot.admin_menu_kb(),
    )
