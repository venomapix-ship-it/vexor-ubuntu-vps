#!/bin/bash
# VEXOR Bot Startup Script

set -e

echo "🤖 Starting VEXOR Bot..."

if [ -f .env ]; then
    echo "📝 Loading environment from .env"
    set -a
    source .env
    set +a
fi

exec python3 -u bot.py
