"""Shared configuration, proxy cascade + quarantine, full debug logger, CheckJob & Queue state."""
from collections import defaultdict
from datetime import datetime
import html
import http.server
import io
import json
import logging as _logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import random
import re
import shutil
import string
import threading
import time
import zipfile

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ═══════════════ BASE DIRECTORY & .ENV LOADER ═══════════════
BASE_DIR = Path(__file__).parent.resolve()


def _load_dotenv(env_file: Path):
  """Pure-Python .env loader so the bot works whether started via start.sh or python3 bot.py."""
  if not env_file.exists():
    return
  try:
    with open(env_file, "r", encoding="utf-8", errors="ignore") as f:
      for line in f:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
          continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k and k not in os.environ:
          os.environ[k] = v
  except Exception:
    pass


_load_dotenv(BASE_DIR / ".env")

# ═══════════════ BOT CREDENTIALS (NO HARDCODED FALLBACKS) ═══════════════
BOT_TOKEN = os.environ.get("VEXOR_BOT_TOKEN", "").strip()
if not BOT_TOKEN or BOT_TOKEN == "your_bot_token_here":
  raise SystemExit(
      "❌ ERROR: VEXOR_BOT_TOKEN is not set! Please configure it in .env or environment variables."
  )

try:
  ADMIN_ID = int(os.environ.get("VEXOR_ADMIN_ID", "0").strip() or "0")
except ValueError:
  ADMIN_ID = 0
if not ADMIN_ID:
  raise SystemExit(
      "❌ ERROR: VEXOR_ADMIN_ID is not set! Please configure it in .env or environment variables."
  )

# Thread counts
THREADS = int(os.environ.get("VEXOR_THREADS", "30"))
EXTRACT_THREADS = int(os.environ.get("VEXOR_EXTRACT_THREADS", "30"))
IMAP_THREADS = int(os.environ.get("VEXOR_IMAP_THREADS", "100"))
XBOX_THREADS = int(os.environ.get("VEXOR_XBOX_THREADS", "30"))
CRUNCHY_THREADS = int(os.environ.get("VEXOR_CRUNCHY_THREADS", "25"))
CAPCUT_THREADS = int(os.environ.get("VEXOR_CAPCUT_THREADS", "30"))
EXPRESS_THREADS = int(os.environ.get("VEXOR_EXPRESS_THREADS", "25"))
DUOLINGO_THREADS = int(os.environ.get("VEXOR_DUOLINGO_THREADS", "25"))
IMAP_MAX_MESSAGES = 500

# ZIP extraction safety cap — zip-bomb protection
MAX_EXTRACT_FILE_BYTES = 100 * 1024 * 1024  # 100 MB per extracted file

# Proxy (Residential rotating + Static pool)
PROXY_ENABLED = os.environ.get("VEXOR_PROXY_ENABLED", "1").strip() not in (
    "0",
    "false",
    "False",
)
PROXY_USER_BASE = os.environ.get("VEXOR_PROXY_USER_BASE", "sr_res-any-sid-").strip()
PROXY_PASS = os.environ.get("VEXOR_PROXY_PASS", "").strip()
PROXY_HOST = os.environ.get("VEXOR_PROXY_HOST", "proxy.op.wtf").strip()
PROXY_PORT = int(os.environ.get("VEXOR_PROXY_PORT", "58996").strip() or "58996")
STATIC_PROXY_COOLDOWN_SEC = 60

# Optional IMAP Proxy toggle (uses HTTP CONNECT / SOCKS5 via PySocks if enabled)
IMAP_USE_PROXY = os.environ.get("VEXOR_IMAP_USE_PROXY", "0").strip() in (
    "1",
    "true",
    "True",
)

# High-value inbox target services for Target Sniper
HIGH_VALUE_TARGETS = {
    "Netflix": ("netflix.com",),
    "Steam": ("steampowered.com", "steamcommunity.com"),
    "PlayStation": ("playstation.com", "sonyentertainmentnetwork.com"),
    "EpicGames": ("epicgames.com",),
    "RiotGames": ("riotgames.com", "leagueoflegends.com", "valorant.com"),
    "Rockstar": ("rockstargames.com",),
    "Supercell": ("supercell.com",),
    "Roblox": ("roblox.com",),
    "TikTok": ("tiktok.com",),
    "Instagram": ("instagram.com", "mail.instagram.com"),
    "Facebook": ("facebookmail.com", "facebook.com"),
    "Discord": ("discordapp.com", "discord.com"),
    "Spotify": ("spotify.com",),
    "PayPal": ("paypal.com", "e.paypal.com"),
    "Binance": ("binance.com",),
    "Coinbase": ("coinbase.com",),
    "Amazon": ("amazon.com", "amazon.co.uk", "amazon.de", "amazon.fr"),
    "Apple": ("apple.com", "id.apple.com", "insideapple.apple.com"),
    "EA_Origin": ("ea.com", "e.ea.com"),
    "Ubisoft": ("ubisoft.com", "ubi.com"),
}

# Country codes & TLD mapping
COUNTRY_NAMES = {
    "US": "United States", "GB": "United Kingdom", "UK": "United Kingdom",
    "CA": "Canada", "AU": "Australia", "NZ": "New Zealand",
    "DE": "Germany", "FR": "France", "IT": "Italy", "ES": "Spain",
    "PT": "Portugal", "NL": "Netherlands", "BE": "Belgium", "CH": "Switzerland",
    "AT": "Austria", "SE": "Sweden", "NO": "Norway", "DK": "Denmark",
    "FI": "Finland", "IE": "Ireland", "PL": "Poland", "CZ": "Czechia",
    "GR": "Greece", "TR": "Turkey", "RU": "Russia", "UA": "Ukraine",
    "RO": "Romania", "HU": "Hungary", "BG": "Bulgaria", "HR": "Croatia",
    "SK": "Slovakia", "SI": "Slovenia", "RS": "Serbia", "LT": "Lithuania",
    "LV": "Latvia", "EE": "Estonia", "IS": "Iceland", "LU": "Luxembourg",
    "MT": "Malta", "CY": "Cyprus", "BR": "Brazil", "MX": "Mexico",
    "AR": "Argentina", "CL": "Chile", "CO": "Colombia", "PE": "Peru",
    "VE": "Venezuela", "EC": "Ecuador", "UY": "Uruguay", "PY": "Paraguay",
    "BO": "Bolivia", "CR": "Costa Rica", "PA": "Panama", "GT": "Guatemala",
    "DO": "Dominican Republic", "IN": "India", "PK": "Pakistan",
    "BD": "Bangladesh", "LK": "Sri Lanka", "NP": "Nepal", "CN": "China",
    "JP": "Japan", "KR": "South Korea", "TW": "Taiwan", "HK": "Hong Kong",
    "SG": "Singapore", "MY": "Malaysia", "ID": "Indonesia", "TH": "Thailand",
    "VN": "Vietnam", "PH": "Philippines", "AE": "United Arab Emirates",
    "SA": "Saudi Arabia", "QA": "Qatar", "KW": "Kuwait", "BH": "Bahrain",
    "OM": "Oman", "IQ": "Iraq", "JO": "Jordan", "LB": "Lebanon",
    "EG": "Egypt", "MA": "Morocco", "DZ": "Algeria", "TN": "Tunisia",
    "LY": "Libya", "NG": "Nigeria", "ZA": "South Africa", "KE": "Kenya",
}

TLD_COUNTRY_MAP = {
    "de": "DE", "fr": "FR", "uk": "GB", "es": "ES", "it": "IT", "nl": "NL",
    "be": "BE", "ru": "RU", "jp": "JP", "cn": "CN", "kr": "KR", "in": "IN",
    "br": "BR", "au": "AU", "ca": "CA", "mx": "MX", "ar": "AR", "ch": "CH",
    "at": "AT", "se": "SE", "no": "NO", "dk": "DK", "fi": "FI", "pl": "PL",
    "cz": "CZ", "gr": "GR", "pt": "PT", "tr": "TR", "sa": "SA", "ae": "AE",
    "za": "ZA", "ng": "NG", "eg": "EG", "ma": "MA", "pk": "PK", "bd": "BD",
    "ph": "PH", "id": "ID", "th": "TH", "vn": "VN", "my": "MY", "sg": "SG",
    "tw": "TW", "hk": "HK", "us": "US", "ro": "RO", "hu": "HU", "ua": "UA",
    "cl": "CL", "co": "CO", "pe": "PE", "ie": "IE", "nz": "NZ", "sk": "SK",
}

DOMAIN_COUNTRY_MAP = {
    "wp.pl": "PL", "o2.pl": "PL", "interia.pl": "PL", "onet.pl": "PL",
    "tlen.pl": "PL", "web.de": "DE", "gmx.de": "DE", "t-online.de": "DE",
    "freenet.de": "DE", "gmx.at": "AT", "orange.fr": "FR", "free.fr": "FR",
    "laposte.net": "FR", "sfr.fr": "FR", "wanadoo.fr": "FR",
    "libero.it": "IT", "virgilio.it": "IT", "alice.it": "IT", "tin.it": "IT",
    "tiscali.it": "IT", "seznam.cz": "CZ", "mail.ru": "RU", "bk.ru": "RU",
    "list.ru": "RU", "inbox.ru": "RU", "rambler.ru": "RU", "yandex.ru": "RU",
    "ukr.net": "UA", "qq.com": "CN", "163.com": "CN", "126.com": "CN",
    "sina.com": "CN", "naver.com": "KR", "daum.net": "KR", "nate.com": "KR",
    "uol.com.br": "BR", "bol.com.br": "BR", "terra.com.br": "BR",
    "ig.com.br": "BR", "globo.com": "BR", "btinternet.com": "GB",
    "sky.com": "GB", "virginmedia.com": "GB", "talktalk.net": "GB",
    "comcast.net": "US", "sbcglobal.net": "US", "att.net": "US",
    "verizon.net": "US", "cox.net": "US", "charter.net": "US",
    "bellsouth.net": "US", "earthlink.net": "US", "optonline.net": "US",
}


def resolve_country_code(email, meta=None):
  """Resolve 2-letter ISO country code from meta dict or email domain/TLD."""
  if meta and isinstance(meta, dict):
    c = (meta.get("country") or meta.get("country_code") or "").strip().upper()
    if len(c) == 2 and c.isalpha():
      return "GB" if c == "UK" else c
    if c in COUNTRY_NAMES:
      return c
  if email and "@" in email:
    dom = email.split("@", 1)[1].lower().strip()
    if dom in DOMAIN_COUNTRY_MAP:
      return DOMAIN_COUNTRY_MAP[dom]
    tld = dom.rsplit(".", 1)[-1]
    if tld in TLD_COUNTRY_MAP:
      return TLD_COUNTRY_MAP[tld]
  return "UNK"


def format_country_label(code):
  code = (code or "UNK").strip().upper()
  if code == "UK":
    code = "GB"
  if code in COUNTRY_NAMES:
    return f"{code} ({COUNTRY_NAMES[code]})"
  return code if code and code != "UNK" else "UNK (Unknown)"


def detect_high_value_targets(domains_dict):
  """Return list of matched target service names from an account's domains dict."""
  if not domains_dict:
    return []
  matched = []
  dom_keys = [d.lower() for d in domains_dict.keys()]
  for target_name, patterns in HIGH_VALUE_TARGETS.items():
    for d in dom_keys:
      if any(d == pat or d.endswith("." + pat) for pat in patterns):
        matched.append(target_name)
        break
  return matched


# Limits
MAX_FILE_SIZE_MB = 50
MAX_PW_ATTEMPTS = 3
UPLOAD_COOLDOWN_SEC = 2
API_RATE_SEM = 30
MAX_ZIP_SIZE_BYTES = 40 * 1024 * 1024  # 40 MB per Telegram chunk
MAX_COMBOS_PER_CHECK = 500_000
MAX_QUEUE_PER_USER = 20

# Timing
STATUS_UPDATE_INTERVAL = 3
JOB_STATE_INTERVAL = 15
LAST_JOB_RETENTION = 3600
PENDING_ZIP_TTL = 300
PENDING_CHECK_TTL = 600
CLEANUP_MAX_AGE = 3600
PERIODIC_CLEANUP_INTERVAL = 600
TAIL_REMAINING = 200
TAIL_MIN_BATCH = 500

# Health check bind host & port (bound to 127.0.0.1 by default for security)
HEALTH_HOST = os.environ.get("VEXOR_HEALTH_HOST", "127.0.0.1").strip()
HEALTH_PORT = int(os.environ.get("VEXOR_HEALTH_PORT", "8080").strip() or "8080")
HEALTH_TOKEN = os.environ.get("VEXOR_HEALTH_TOKEN", "").strip()

# Always-on Debug Flags
DEBUG_ALL = True
DEBUG_HOTMAIL = True
DEBUG_IMAP = True
DEBUG_XBOX = True
DEBUG_CAPCUT = True
DEBUG_CRUNCHY = True
DEBUG_EXPRESS = True
DEBUG_DUOLINGO = True

admin_alert_hook = None


# ═══════════════ FULL DEBUG LOGGING SYSTEM (ANCHORED TO BASE_DIR) ═══════════════
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)
BACKUP_DIR = BASE_DIR / "results_backup"
BACKUP_DIR.mkdir(exist_ok=True)

_formatter = _logging.Formatter(
    "%(asctime)s.%(msecs)03d [%(levelname)s] [%(threadName)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def _make_rotating_logger(name, filepath, max_mb=20, backups=5):
  logger = _logging.getLogger(name)
  logger.setLevel(_logging.DEBUG)
  logger.propagate = False
  if not logger.handlers:
    handler = RotatingFileHandler(
        filepath,
        encoding="utf-8",
        maxBytes=max_mb * 1024 * 1024,
        backupCount=backups,
    )
    handler.setFormatter(_formatter)
    logger.addHandler(handler)
  return logger


_master_logger = _make_rotating_logger(
    "vexor.master", BASE_DIR / "bot_debug.log", max_mb=25, backups=5
)
_legacy_logger = _make_rotating_logger(
    "vexor.legacy", BASE_DIR / "vexor_bot.log", max_mb=15, backups=3
)

_service_loggers = {
    "bot": _make_rotating_logger("vexor.bot", LOG_DIR / "bot_core_debug.log"),
    "hotmail": _make_rotating_logger(
        "vexor.hotmail", LOG_DIR / "hotmail_debug.log"
    ),
    "imap": _make_rotating_logger("vexor.imap", LOG_DIR / "imap_debug.log"),
    "xbox": _make_rotating_logger("vexor.xbox", LOG_DIR / "xbox_debug.log"),
    "crunchyroll": _make_rotating_logger(
        "vexor.crunchyroll", LOG_DIR / "crunchyroll_debug.log"
    ),
    "capcut": _make_rotating_logger(
        "vexor.capcut", LOG_DIR / "capcut_debug.log"
    ),
    "express": _make_rotating_logger(
        "vexor.express", LOG_DIR / "express_debug.log"
    ),
    "duolingo": _make_rotating_logger(
        "vexor.duolingo", LOG_DIR / "duolingo_debug.log"
    ),
    "proxy": _make_rotating_logger("vexor.proxy", LOG_DIR / "proxy_debug.log"),
}


def _route_service_tag(tag):
  t = (tag or "").lower()
  if "hotmail" in t or "substrate" in t:
    return "hotmail"
  if "imap" in t or "mix" in t:
    return "imap"
  if "xbox" in t or "mc" in t or "minecraft" in t:
    return "xbox"
  if "crunchy" in t:
    return "crunchyroll"
  if "capcut" in t or "cupcut" in t:
    return "capcut"
  if "express" in t or "vpn" in t:
    return "express"
  if "duolingo" in t or "duo" in t:
    return "duolingo"
  if "proxy" in t:
    return "proxy"
  return "bot"


def log(tag, msg, level="INFO"):
  ts = datetime.now().strftime("%H:%M:%S")
  line = f"[{ts}] [{level}] [{tag}] {msg}"
  try:
    print(line, flush=True)
  except Exception:
    pass
  lvl = getattr(_logging, level.upper(), _logging.DEBUG)
  formatted_msg = f"[{tag}] {msg}"
  try:
    _master_logger.log(lvl, formatted_msg)
    _legacy_logger.log(lvl, formatted_msg)
    svc = _route_service_tag(tag)
    if svc in _service_loggers:
      _service_loggers[svc].log(lvl, formatted_msg)
  except Exception:
    pass


# ═══════════════ HELPERS ═══════════════
def esc_html(s):
  return html.escape(str(s), quote=False)


def gen_session_id():
  return "".join(random.choices(string.ascii_lowercase + string.digits, k=8))


# ═══════════════ DUAL-TIER PROXY CASCADE + QUARANTINE ═══════════════
_static_proxies_cache = None
_static_proxy_idx = 0
_static_proxy_lock = threading.Lock()
_proxy_quarantine = {}  # {proxy_url: {"fails": int, "until": float}}


def _resolve_proxy_path():
  env_path = os.environ.get("CAPCUT_PROXY_FILE")
  if env_path:
    p = Path(env_path)
    if not p.is_absolute():
      p = BASE_DIR / p
    if p.exists():
      return p
  for fname in ("Working_Proxies_99.txt", "proxies.txt"):
    p = BASE_DIR / fname
    if p.exists():
      return p
  return BASE_DIR / "Working_Proxies_99.txt"


def _parse_proxy_line(line):
  line = line.strip()
  if not line or line.startswith("#"):
    return None
  if line.startswith(("http://", "https://", "socks5://", "socks4://")):
    return line
  if "@" in line:
    return f"http://{line}"
  parts = line.split(":")
  if len(parts) == 2:
    return f"http://{parts[0]}:{parts[1]}"
  elif len(parts) == 4:
    ip, port, user, pwd = parts
    return f"http://{user}:{pwd}@{ip}:{port}"
  return None


def load_static_proxies(force_reload=False):
  """Load Type 1 static proxies from file."""
  global _static_proxies_cache
  with _static_proxy_lock:
    if _static_proxies_cache is not None and not force_reload:
      return list(_static_proxies_cache)
    proxies = []
    proxy_path = _resolve_proxy_path()
    if proxy_path.exists():
      try:
        with open(proxy_path, "r", encoding="utf-8", errors="ignore") as f:
          for line in f:
            parsed = _parse_proxy_line(line)
            if parsed:
              proxies.append(parsed)
      except Exception as e:
        log("proxy", f"Error reading {proxy_path}: {e}", level="WARN")
    _static_proxies_cache = proxies
    log(
        "proxy",
        f"Loaded {len(proxies)} Type-1 static proxies from {proxy_path.name}",
        level="DEBUG",
    )
    return list(proxies)


load_capcut_proxies = load_static_proxies


def report_proxy_fail(proxy_url, reason="fail"):
  """Quarantine a static proxy for 60s after 2 consecutive rate-limits/timeouts."""
  if not proxy_url or (PROXY_HOST and PROXY_HOST in proxy_url):
    return
  now = time.time()
  with _static_proxy_lock:
    st = _proxy_quarantine.setdefault(proxy_url, {"fails": 0, "until": 0.0})
    st["fails"] += 1
    if st["fails"] >= 2:
      st["until"] = now + STATIC_PROXY_COOLDOWN_SEC
      ip_part = proxy_url.split("@")[-1] if "@" in proxy_url else proxy_url
      log(
          "proxy",
          f"Quarantined static proxy {ip_part} for {STATIC_PROXY_COOLDOWN_SEC}s (reason={reason})",
          level="DEBUG",
      )


def report_proxy_ok(proxy_url):
  """Clear failure count when a static proxy succeeds."""
  if not proxy_url or (PROXY_HOST and PROXY_HOST in proxy_url):
    return
  with _static_proxy_lock:
    st = _proxy_quarantine.get(proxy_url)
    if st:
      st["fails"] = 0
      st["until"] = 0.0


def get_proxy_health_summary():
  """Return (total_static, healthy_static, quarantined_static)."""
  proxies = load_static_proxies()
  now = time.time()
  with _static_proxy_lock:
    quarantined = sum(
        1
        for p in proxies
        if (_proxy_quarantine.get(p) or {}).get("until", 0.0) > now
    )
  return len(proxies), len(proxies) - quarantined, quarantined


def get_next_static_proxy(exclude=None):
  """Round-robin selection of a healthy Type 1 static proxy (skipping quarantined IPs)."""
  global _static_proxy_idx
  proxies = load_static_proxies()
  if not proxies:
    return None
  now = time.time()
  with _static_proxy_lock:
    n = len(proxies)
    for _ in range(n):
      p = proxies[_static_proxy_idx % n]
      _static_proxy_idx += 1
      if p == exclude and n > 1:
        continue
      st = _proxy_quarantine.get(p)
      if st and st.get("until", 0.0) > now:
        continue
      return p
    for _ in range(n):
      p = proxies[_static_proxy_idx % n]
      _static_proxy_idx += 1
      if p != exclude or n == 1:
        return p
    return proxies[0]


def get_residential_proxy():
  """Generate a fresh Type 2 residential proxy URL with a unique random SID."""
  if not (PROXY_ENABLED and PROXY_PASS):
    return None, "direct"
  sid = gen_session_id()
  user = f"{PROXY_USER_BASE}{sid}"
  url = f"http://{user}:{PROXY_PASS}@{PROXY_HOST}:{PROXY_PORT}"
  return url, f"res-sid-{sid}"


def get_proxy_for_attempt(attempt, prev_proxy=None):
  """Smart Proxy Cascade:

  - attempt 0: Healthy Static Proxy #1 (Type 1)
  - attempt 1: Healthy Static Proxy #2 (different IP from Type 1)
  - attempt >= 2: Residential Rotating Proxy with fresh SID (Type 2)
  """
  if not PROXY_ENABLED:
    return None, "direct"
  if prev_proxy and attempt > 0:
    report_proxy_fail(prev_proxy, reason=f"retry_attempt_{attempt}")
  if attempt == 0:
    p = get_next_static_proxy()
    if p:
      ip_part = p.split("@")[-1] if "@" in p else p
      return p, f"static-1({ip_part})"
  elif attempt == 1:
    p = get_next_static_proxy(exclude=prev_proxy)
    if p:
      ip_part = p.split("@")[-1] if "@" in p else p
      return p, f"static-2({ip_part})"
  res_url, res_label = get_residential_proxy()
  if res_url:
    return res_url, res_label
  p = get_next_static_proxy(exclude=prev_proxy)
  if p:
    ip_part = p.split("@")[-1] if "@" in p else p
    return p, f"static-fallback({ip_part})"
  return None, "direct"


# ═══════════════ JOB STATE & LIGHTWEIGHT QUEUE PERSISTENCE ═══════════════
STATE_DIR = BASE_DIR / "job_states"
STATE_DIR.mkdir(exist_ok=True)
QUEUE_COMBOS_DIR = STATE_DIR / "queued_batches"
QUEUE_COMBOS_DIR.mkdir(exist_ok=True)


def _state_path(chat_id):
  return STATE_DIR / f"job_{chat_id}.json"


def _queue_path(chat_id):
  return STATE_DIR / f"queue_{chat_id}.json"


def save_job_state(job):
  """Persist job progress, remaining combos, AND valid/free hits so nothing is lost on crash."""
  try:
    with job.lock:
      if job.completed:
        return
      done_keys = getattr(job, "done_keys", set())
      if done_keys:
        remaining = [
            list(c) for c in job.combos if (c[0].lower(), c[1]) not in done_keys
        ]
      else:
        remaining = [
            list(job.combos[i]) for i in range(job.processed, len(job.combos))
        ]
      state = {
          "chat_id": job.chat_id,
          "mode": job.mode,
          "total": job.total,
          "file_label": getattr(job, "file_label", ""),
          "start_time": job.start_time,
          "elapsed_before_pause": (
              job.elapsed_before_pause + int(time.time() - job.start_time)
          ),
          "remaining": remaining,
          "valid_list": [list(it) for it in job.valid_list],
          "free_list": [list(it) for it in getattr(job, "free_list", [])],
          "counters": {
              "processed": job.processed,
              "valid": job.valid,
              "free": job.free,
              "twofa": job.twofa,
              "bad": job.bad,
              "net": job.net,
              "skip": job.skip,
              "extracted": job.extracted,
              "extracting": job.extracting,
              "throttled": job.throttled,
              "retried": job.retried,
              "recovered": job.recovered,
              "gamepass": job.gamepass,
              "minecraft": job.minecraft,
              "with_cards": job.with_cards,
              "with_balance": job.with_balance,
              "imap_locked": job.imap_locked,
              "imap_expired": job.imap_expired,
              "imap_rate_limited": job.imap_rate_limited,
              "unclear": job.unclear,
          },
      }
    tmp = _state_path(job.chat_id).with_suffix(".tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
    tmp.replace(_state_path(job.chat_id))
  except Exception as e:
    log("state", f"save_job_state: {e}", "WARN")


def load_job_states():
  states = []
  for f in STATE_DIR.glob("job_*.json"):
    try:
      states.append(json.loads(f.read_text(encoding="utf-8")))
    except Exception:
      try:
        f.unlink()
      except Exception:
        pass
  return states


def clear_job_state(chat_id):
  try:
    _state_path(chat_id).unlink(missing_ok=True)
  except Exception:
    pass


def save_user_queue(chat_id, queue_items):
  """Persist a user's queued jobs using lightweight combo files per batch instead of rewriting huge JSONs."""
  try:
    p = _queue_path(chat_id)
    if not queue_items:
      p.unlink(missing_ok=True)
      for old_f in QUEUE_COMBOS_DIR.glob(f"q_{chat_id}_*.txt"):
        try:
          old_f.unlink(missing_ok=True)
        except Exception:
          pass
      return

    active_bfiles = set()
    serializable = []
    for idx, item in enumerate(queue_items):
      qid = item.get("qid") or f"{int(time.time()*1000)}_{idx}_{gen_session_id()[:4]}"
      item["qid"] = qid
      bfile = QUEUE_COMBOS_DIR / f"q_{chat_id}_{qid}.txt"
      active_bfiles.add(bfile.name)
      if not bfile.exists() and "combos" in item:
        with open(bfile, "w", encoding="utf-8") as bf:
          for c in item["combos"]:
            bf.write(f"{c[0]}:{c[1]}\n")
      serializable.append({
          "qid": qid,
          "combo_file": str(bfile),
          "combo_count": len(item.get("combos", [])),
          "junk": item.get("junk", 0),
          "dup": item.get("dup", 0),
          "mode": item.get("mode", "hotmail"),
          "file_label": item.get("file_label", "combos.txt"),
          "queued_at": item.get("queued_at", time.time()),
      })

    # Clean up any removed batch files for this user
    for old_f in QUEUE_COMBOS_DIR.glob(f"q_{chat_id}_*.txt"):
      if old_f.name not in active_bfiles:
        try:
          old_f.unlink(missing_ok=True)
        except Exception:
          pass

    tmp = p.with_suffix(".tmp")
    tmp.write_text(
        json.dumps(serializable, ensure_ascii=False), encoding="utf-8"
    )
    tmp.replace(p)
  except Exception as e:
    log("queue", f"save_user_queue({chat_id}): {e}", "WARN")


def load_all_queues():
  queues = {}
  for f in STATE_DIR.glob("queue_*.json"):
    try:
      cid_str = f.stem.replace("queue_", "")
      cid = int(cid_str)
      raw = json.loads(f.read_text(encoding="utf-8"))
      items = []
      for r in raw:
        combos = []
        cfile = r.get("combo_file")
        if cfile and Path(cfile).exists():
          combos, _, _ = load_combos(cfile)
        elif "combos" in r:
          combos = [tuple(c) for c in r.get("combos", [])]
        if combos:
          items.append({
              "qid": r.get("qid"),
              "combos": combos,
              "junk": r.get("junk", 0),
              "dup": r.get("dup", 0),
              "mode": r.get("mode", "hotmail"),
              "file_label": r.get("file_label", "combos.txt"),
              "queued_at": r.get("queued_at", time.time()),
          })
      if items:
        queues[cid] = items
    except Exception as e:
      log("queue", f"load queue file {f}: {e}", "WARN")
  return queues


def save_emergency_backup(job):
  """Write a local emergency backup of valid/free hits before ZIP build so hits are NEVER lost."""
  if not job.valid_list and not getattr(job, "free_list", None):
    return None
  try:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    bpath = BACKUP_DIR / f"hits_{job.chat_id}_{job.mode}_{ts}.txt"
    with open(bpath, "w", encoding="utf-8") as f:
      for it in job.valid_list:
        e, pw, meta = _normalize_valid_item(it)
        if e:
          f.write(format_full_capture_line(e, pw, meta, job.mode) + "\n")
      for it in getattr(job, "free_list", []):
        e, pw, meta = _normalize_valid_item(it)
        if e:
          f.write("[FREE] " + format_full_capture_line(e, pw, meta, job.mode) + "\n")
    log("backup", f"Saved emergency hits backup to {bpath.name}", level="DEBUG")
    return bpath
  except Exception as e:
    log("backup", f"Emergency backup error: {e}", level="WARN")
    return None


# ═══════════════ USER STATS (ANCHORED TO BASE_DIR) ═══════════════
STATS_FILE = BASE_DIR / "user_stats.json"
_stats_lock = threading.Lock()


def _load_stats():
  try:
    if STATS_FILE.exists():
      return json.loads(STATS_FILE.read_text(encoding="utf-8"))
  except Exception:
    pass
  return {}


def _save_stats(data):
  try:
    tmp = STATS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    tmp.replace(STATS_FILE)
  except Exception:
    pass


def load_stats():
  return _load_stats()


def bump_user_stats(chat_id, valid, total, mode="unknown"):
  with _stats_lock:
    data = _load_stats()
    uid = str(chat_id)
    entry = data.get(uid, {"jobs": 0, "valid": 0, "combos": 0, "by_mode": {}})
    entry["jobs"] += 1
    entry["valid"] += valid
    entry["combos"] += total
    entry.setdefault("by_mode", {})[mode] = entry["by_mode"].get(mode, 0) + valid
    data[uid] = entry
    _save_stats(data)


def get_user_stats(chat_id):
  data = _load_stats()
  return data.get(
      str(chat_id), {"jobs": 0, "valid": 0, "combos": 0, "by_mode": {}}
  )


# ═══════════════ ALLOWED USERS (ANCHORED TO BASE_DIR) ═══════════════
ALLOWED_FILE = BASE_DIR / "allowed_users.json"
_allowed_cache = None
_allowed_lock = threading.Lock()


def _load_allowed():
  try:
    if ALLOWED_FILE.exists():
      return set(json.loads(ALLOWED_FILE.read_text(encoding="utf-8")))
  except Exception:
    pass
  return {ADMIN_ID} if ADMIN_ID else set()


def _save_allowed(s):
  try:
    tmp = ALLOWED_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(list(s)), encoding="utf-8")
    tmp.replace(ALLOWED_FILE)
  except Exception:
    pass


def _get_allowed():
  global _allowed_cache
  with _allowed_lock:
    if _allowed_cache is None:
      _allowed_cache = _load_allowed()
    return _allowed_cache


def list_allowed():
  return sorted(_get_allowed())


def list_banned():
  return sorted(_get_banned())


def add_allowed(chat_id):
  global _allowed_cache
  with _allowed_lock:
    if _allowed_cache is None:
      _allowed_cache = _load_allowed()
    _allowed_cache.add(int(chat_id))
    _save_allowed(_allowed_cache)


def remove_allowed(chat_id):
  global _allowed_cache
  with _allowed_lock:
    if _allowed_cache is None:
      _allowed_cache = _load_allowed()
    _allowed_cache.discard(int(chat_id))
    _save_allowed(_allowed_cache)


# ═══════════════ BANNED USERS (ANCHORED TO BASE_DIR) ═══════════════
BANNED_FILE = BASE_DIR / "banned_users.json"
_banned_cache = None
_banned_lock = threading.Lock()


def _load_banned():
  try:
    if BANNED_FILE.exists():
      return set(json.loads(BANNED_FILE.read_text(encoding="utf-8")))
  except Exception:
    pass
  return set()


def _save_banned(s):
  try:
    tmp = BANNED_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(list(s)), encoding="utf-8")
    tmp.replace(BANNED_FILE)
  except Exception:
    pass


def _get_banned():
  global _banned_cache
  with _banned_lock:
    if _banned_cache is None:
      _banned_cache = _load_banned()
    return _banned_cache


def is_banned(chat_id):
  return chat_id in _get_banned()


def add_banned(chat_id):
  global _banned_cache
  with _banned_lock:
    if _banned_cache is None:
      _banned_cache = _load_banned()
    _banned_cache.add(int(chat_id))
    _save_banned(_banned_cache)


def remove_banned(chat_id):
  global _banned_cache
  with _banned_lock:
    if _banned_cache is None:
      _banned_cache = _load_banned()
    _banned_cache.discard(int(chat_id))
    _save_banned(_banned_cache)


def is_allowed(chat_id):
  if is_banned(chat_id):
    return False
  if ADMIN_ID and chat_id == ADMIN_ID:
    return True
  return chat_id in _get_allowed()


# ═══════════════ USERNAMES PERSISTENCE (ANCHORED TO BASE_DIR) ═══════════════
USERNAMES_FILE = BASE_DIR / "usernames.json"
_usernames_lock = threading.Lock()
_usernames_cache = None


def load_usernames():
  try:
    if USERNAMES_FILE.exists():
      return json.loads(USERNAMES_FILE.read_text(encoding="utf-8"))
  except Exception:
    pass
  return {}


def save_username(chat_id, name, username=None):
  global _usernames_cache
  try:
    with _usernames_lock:
      if _usernames_cache is None:
        _usernames_cache = load_usernames()
      _usernames_cache[str(chat_id)] = {"name": name, "uname": username or ""}
      tmp = USERNAMES_FILE.with_suffix(".tmp")
      tmp.write_text(
          json.dumps(_usernames_cache, ensure_ascii=False), encoding="utf-8"
      )
      tmp.replace(USERNAMES_FILE)
  except Exception:
    pass


# ═══════════════ UPLOAD RATE LIMIT ═══════════════
_rate_lock = threading.Lock()
_rate_times = defaultdict(float)


def rate_ok(chat_id):
  now = time.time()
  with _rate_lock:
    last = _rate_times.get(chat_id, 0)
    if now - last < UPLOAD_COOLDOWN_SEC:
      return False
    _rate_times[chat_id] = now
    return True


def prune_rate_times():
  cutoff = time.time() - (UPLOAD_COOLDOWN_SEC * 100)
  with _rate_lock:
    stale = [k for k, t in _rate_times.items() if t < cutoff]
    for k in stale:
      _rate_times.pop(k, None)


# ═══════════════ STREAMING COMBO LOADER (LOW MEMORY) ═══════════════
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")


def load_combos(path):
  """Stream-reads combos line-by-line without loading entire file into RAM at once.

  Returns (combos, junk, dup). combos = [(email, pw, meta_dict)].
  """
  combos = []
  seen = set()
  junk = 0
  dup = 0
  try:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
      for line in f:
        line = line.strip()
        if not line:
          continue
        sep = None
        e = pw = None
        for s in (":", "|", ";"):
          if s in line:
            parts = line.split(s, 1)
            if len(parts) == 2 and EMAIL_RE.match(parts[0].strip()):
              sep = s
              e, pw = parts[0].strip(), parts[1].strip()
              break
        if sep is None or not e or not pw:
          junk += 1
          continue
        key = (e.lower(), pw)
        if key in seen:
          dup += 1
          continue
        seen.add(key)
        combos.append((e, pw, {}))
  except Exception:
    return combos, 0, 0
  return combos, junk, dup


# ═══════════════ ZIP HANDLING ═══════════════
def safe_extract_zip(zip_path, dest_dir, password=None):
  """Returns (file_paths, error_str_or_None)."""
  dest = Path(dest_dir)
  dest.mkdir(parents=True, exist_ok=True)
  files = []
  try:
    with zipfile.ZipFile(zip_path) as zf:
      names = zf.namelist()
      if not names:
        return [], "EMPTY"
      pwd_bytes = password.encode() if password else None
      for idx, name in enumerate(names):
        safe_name = name.replace("\\", "/").lstrip("/")
        if ".." in safe_name:
          continue
        if not safe_name.lower().endswith(".txt"):
          continue
        try:
          member = zf.open(name, pwd=pwd_bytes)
        except RuntimeError as e:
          m = str(e).lower()
          if "password" in m or "encrypted" in m:
            return [], (
                "PASSWORD_REQUIRED" if password is None else "BAD_PASSWORD"
            )
          continue
        except Exception:
          continue
        target = dest / f"{idx:04d}_{Path(safe_name).name}"
        try:
          with member:
            data = member.read(MAX_EXTRACT_FILE_BYTES + 1)
          if len(data) > MAX_EXTRACT_FILE_BYTES:
            continue
          with open(target, "wb") as out:
            out.write(data)
          files.append(target)
        except Exception:
          continue
    if not files:
      return [], "NO_TXT"
    return files, None
  except zipfile.BadZipFile:
    return [], "BAD_ZIP"
  except Exception as e:
    return [], f"EXTRACT:{e}"


# ═══════════════ ZIP BUILDER (WITH COUNTRIES/ & FULL.TXT) ═══════════════
def _normalize_valid_item(it):
  if isinstance(it, (tuple, list)):
    email = str(it[0]) if len(it) > 0 else ""
    pw = str(it[1]) if len(it) > 1 else ""
    meta = it[2] if (len(it) > 2 and isinstance(it[2], dict)) else {}
    return email, pw, meta
  if isinstance(it, str):
    core = it.split("|", 1)[0].strip()
    if ":" in core:
      e, pw = core.split(":", 1)
      return e.strip(), pw.strip(), {"raw": it}
    return core, "", {"raw": it}
  return "", "", {}


def format_full_capture_line(email, pw, meta, mode):
  """Build a rich, unified single-line capture for FULL.txt & countries/<CODE>.txt."""
  cc = resolve_country_code(email, meta)
  c_lbl = format_country_label(cc)
  parts = [f"{email}:{pw}", f"Country: {c_lbl}"]

  if mode == "duolingo":
    plan = meta.get("plan", "Duolingo Super")
    expiry = meta.get("expiry", "N/A")
    days = meta.get("days", -1)
    days_str = f" ({days}d)" if isinstance(days, int) and days >= 0 else ""
    renew = meta.get("renew", "N/A")
    invite = meta.get("invite", "")
    streak = meta.get("streak", 0)
    xp = meta.get("xp", 0)
    parts.append(f"Subscription: {plan}")
    parts.append(f"Expiry: {expiry}{days_str}")
    parts.append(f"Renewing: {renew}")
    if invite:
      parts.append(f"FamilyInvite: {invite}")
    if streak or xp:
      parts.append(f"Stats: {streak}🔥 / {xp}XP")
  elif mode == "express":
    plan = meta.get("plan", "Active Plan")
    expiry = meta.get("expiry") or meta.get("expire_date") or "N/A"
    days = meta.get("days", -1)
    days_str = f" ({days}d)" if isinstance(days, int) and days >= 0 else ""
    lic = meta.get("license", "N/A")
    pay = meta.get("payment_method", "Unknown")
    ar = "Yes" if meta.get("auto_renew") else "No"
    ovpn_u = meta.get("ovpn_user", "N/A")
    ovpn_p = meta.get("ovpn_pass", "N/A")
    parts.append(f"Subscription: {plan}")
    parts.append(f"Expiry: {expiry}{days_str}")
    parts.append(f"License: {lic}")
    parts.append(f"Payment: {pay} (AutoRenew: {ar})")
    if ovpn_u != "N/A":
      parts.append(f"OVPN: {ovpn_u}:{ovpn_p}")
  elif mode in ("capcut", "cupcut"):
    plan = meta.get("plan", "Premium")
    expiry = meta.get("expiry", "N/A")
    days = meta.get("days", -1)
    days_str = f" ({days}d)" if isinstance(days, int) and days >= 0 else ""
    parts.append(f"Subscription: {plan}")
    parts.append(f"Expiry: {expiry}{days_str}")
  elif mode == "crunchyroll":
    plan = meta.get("plan") or meta.get("tier") or "Premium"
    sku = meta.get("sku", "")
    expiry = meta.get("expiry") or meta.get("renewal") or "N/A"
    days = meta.get("days", -1)
    days_str = f" ({days}d)" if isinstance(days, int) and days >= 0 else ""
    parts.append(f"Subscription: {plan}")
    if sku and sku != plan:
      parts.append(f"SKU: {sku}")
    parts.append(f"Renewal: {expiry}{days_str}")
  elif mode in ("xbox", "full", "minecraft"):
    gp = meta.get("gamepass", "NO")
    mc = meta.get("minecraft", "NO")
    tag = meta.get("gamertag", "")
    gs = meta.get("gscore", 0)
    cards = meta.get("cards", "NO CC")
    bal = meta.get("balance", "N/A")
    sub_str = f"GamePass({gp})" if gp != "NO" else "No GamePass"
    if mc == "YES":
      sub_str += " + Minecraft"
    parts.append(f"Subscription: {sub_str}")
    if tag:
      parts.append(f"Gamertag: {tag} ({gs}G)")
    if cards and cards != "NO CC":
      parts.append(f"Cards: {cards}")
    if bal and bal != "N/A":
      parts.append(f"Balance: {bal}")
    if mode == "full":
      total_msgs = meta.get("total", 0)
      domains = meta.get("domains") or {}
      targets = detect_high_value_targets(domains)
      parts.append(f"Inbox: {total_msgs} msgs ({len(domains)} domains)")
      if targets:
        parts.append(f"Targets: {', '.join(targets)}")
  elif mode in ("inbox", "imap"):
    server = meta.get("server", "")
    total_msgs = meta.get("total", 0)
    domains = meta.get("domains") or {}
    targets = detect_high_value_targets(domains)
    tag = meta.get("gamertag", "")
    gs = meta.get("gscore", 0)
    parts.append(f"Subscription: Active Mail ({server or mode.upper()})")
    parts.append(f"Messages: {total_msgs}")
    parts.append(f"Domains: {len(domains)}")
    if targets:
      parts.append(f"Targets: {', '.join(targets)}")
    if tag:
      parts.append(f"Gamertag: {tag} ({gs}G)")
  else:
    tag = meta.get("gamertag", "")
    gs = meta.get("gscore", 0)
    sub = "Microsoft + Xbox" if tag else "Microsoft Active"
    parts.append(f"Subscription: {sub}")
    if tag:
      parts.append(f"Gamertag: {tag} ({gs}G)")

  return " | ".join(parts)


def _fill_zip(zf, valid_list, mode, free_list=None):
  normalized = [_normalize_valid_item(it) for it in valid_list]
  normalized = [it for it in normalized if it[0]]

  # 1. valid.txt (clean email:password)
  lines = [f"{e}:{pw}" for e, pw, _ in normalized]
  zf.writestr("valid.txt", "\n".join(lines))

  # 2. FULL.txt (Account : Country : Subscription : Details for EVERY mode)
  full_lines = [
      format_full_capture_line(e, pw, meta, mode) for e, pw, meta in normalized
  ]
  if full_lines:
    zf.writestr("FULL.txt", "\n".join(full_lines))

  # 3. countries/<COUNTRY_CODE>.txt (Grouped by Country for EVERY mode)
  by_country = defaultdict(list)
  for e, pw, meta in normalized:
    cc = resolve_country_code(email=e, meta=meta)
    by_country[cc].append(format_full_capture_line(e, pw, meta, mode))
  for cc, c_items in by_country.items():
    safe_cc = re.sub(r"[^A-Za-z0-9_\-]", "_", cc) or "UNK"
    zf.writestr(f"countries/{safe_cc}.txt", "\n".join(c_items))

  # 4. domains/<domain>.txt
  by_domain = defaultdict(list)
  for e, pw, meta in normalized:
    dom = e.split("@", 1)[1].lower() if "@" in e else "unknown"
    by_domain[dom].append((e, pw, meta))
  for dom, items in by_domain.items():
    safe = re.sub(r"[^a-zA-Z0-9._\-]", "_", dom) or "unknown"
    zf.writestr(
        f"domains/{safe}.txt", "\n".join(f"{e}:{pw}" for e, pw, _ in items)
    )

  # 5. Free accounts (if any in CapCut / Crunchyroll)
  if free_list:
    norm_free = [_normalize_valid_item(it) for it in free_list]
    norm_free = [it for it in norm_free if it[0]]
    if norm_free:
      free_lines = [
          format_full_capture_line(e, pw, meta, mode)
          for e, pw, meta in norm_free
      ]
      zf.writestr("free_accounts.txt", "\n".join(free_lines))

  # 6. Gamertags file (when gamertag is present in Hotmail/Xbox/Full)
  gt_lines = [
      f"{e}:{pw} | Gamertag: {meta.get('gamertag')} | Gamerscore:"
      f" {meta.get('gscore', 0)}G | Country: {resolve_country_code(e, meta)}"
      for e, pw, meta in normalized
      if meta.get("gamertag")
  ]
  if gt_lines:
    zf.writestr("gamertags.txt", "\n".join(gt_lines))

  # 7. Inbox & High-Value Target Sniper (inbox, imap, full)
  if mode in ("inbox", "imap", "full"):
    by_target = defaultdict(list)
    for e, pw, meta in normalized:
      senders = meta.get("senders") or {}
      domains = meta.get("domains") or {}
      total = meta.get("total", 0)
      server = meta.get("server", "")
      cc = resolve_country_code(e, meta)
      targets = detect_high_value_targets(domains)
      for t_name in targets:
        cnt = sum(
            v
            for k, v in domains.items()
            if any(
                k.lower() == pat or k.lower().endswith("." + pat)
                for pat in HIGH_VALUE_TARGETS.get(t_name, ())
            )
        )
        by_target[t_name].append(
            f"{e}:{pw} | Country: {cc} | Target: {t_name} ({cnt} msgs)"
        )

      safe_email = re.sub(r"[^a-zA-Z0-9._\-@]", "_", e)
      body = [
          f"Email: {e}",
          f"Password: {pw}",
          f"Country: {format_country_label(cc)}",
          f"Server: {server}",
          f"Total messages: {total}",
          f"Unique senders: {len(senders)}",
          f"Unique domains: {len(domains)}",
          f"Detected Targets: {', '.join(targets) if targets else 'None'}",
          "",
      ]
      if senders and mode == "imap":
        body.append("── Senders ──")
        for snd, cnt in sorted(senders.items(), key=lambda x: -x[1])[:500]:
          body.append(f"  {snd} ({cnt})")
        body.append("")
      if domains:
        body.append("── Domains ──")
        for dom, cnt in sorted(domains.items(), key=lambda x: -x[1])[:500]:
          body.append(f"  {dom} ({cnt})")
      zf.writestr(f"inbox/{safe_email}.txt", "\n".join(body))

    for t_name, t_lines in by_target.items():
      zf.writestr(f"targets/{t_name}.txt", "\n".join(t_lines))

  if mode in ("xbox", "full"):
    by_tier = defaultdict(list)
    for e, pw, meta in normalized:
      by_tier[meta.get("gamepass", "NO")].append((e, pw, meta))
    for tier, items in by_tier.items():
      safe = re.sub(r"[^a-zA-Z0-9]", "_", str(tier)) or "NO"
      zf.writestr(
          f"gamepass/{safe}.txt",
          "\n".join(
              format_full_capture_line(e, pw, m, mode) for e, pw, m in items
          ),
      )

    for e, pw, meta in normalized:
      games = meta.get("games") or []
      if not games:
        continue
      safe_email = re.sub(r"[^a-zA-Z0-9._\-@]", "_", e)
      zf.writestr(f"games/{safe_email}.txt", "\n".join(games))

    card_lines = []
    for e, pw, meta in normalized:
      cards = meta.get("cards", "NO CC")
      balance = meta.get("balance", "N/A")
      cc = resolve_country_code(e, meta)
      if (cards and cards != "NO CC") or (balance and balance != "N/A"):
        card_lines += [
            f"=== {e}:{pw} | Country: {format_country_label(cc)}",
            f"Cards: {cards}",
            f"Balance: {balance}",
            "",
        ]
    if card_lines:
      zf.writestr("cards.txt", "\n".join(card_lines))

  if mode in ("xbox", "full", "minecraft"):
    mc_lines = [
        format_full_capture_line(e, pw, meta, mode)
        for e, pw, meta in normalized
        if meta.get("minecraft") == "YES"
    ]
    if mc_lines:
      zf.writestr("minecraft.txt", "\n".join(mc_lines))

  if mode == "crunchyroll":
    by_tier = defaultdict(list)
    for e, pw, meta in normalized:
      tier = meta.get("plan") or meta.get("tier") or "Premium"
      by_tier[tier].append(format_full_capture_line(e, pw, meta, mode))
    for tier, items in by_tier.items():
      safe_tier = re.sub(r"[^a-zA-Z0-9._\-]", "_", str(tier)) or "Premium"
      zf.writestr(f"tiers/{safe_tier}.txt", "\n".join(items))

  if mode in ("capcut", "cupcut"):
    by_plan = defaultdict(list)
    for e, pw, meta in normalized:
      plan = meta.get("plan", "Premium")
      by_plan[plan].append(format_full_capture_line(e, pw, meta, mode))
    for plan, items in by_plan.items():
      safe_plan = re.sub(r"[^a-zA-Z0-9._\-]", "_", str(plan)) or "Premium"
      zf.writestr(f"plans/{safe_plan}.txt", "\n".join(items))

  if mode == "express":
    by_plan = defaultdict(list)
    lic_lines = []
    ovpn_lines = []
    for e, pw, meta in normalized:
      plan = meta.get("plan", "Active")
      full_line = format_full_capture_line(e, pw, meta, mode)
      by_plan[plan].append(full_line)
      lic = meta.get("license", "N/A")
      if lic and lic != "N/A":
        lic_lines.append(f"{e}:{pw} | License: {lic} | Plan: {plan} | Expiry: {meta.get('expiry', 'N/A')}")
      ou, op = meta.get("ovpn_user", "N/A"), meta.get("ovpn_pass", "N/A")
      pu, pp = meta.get("pptp_user", "N/A"), meta.get("pptp_pass", "N/A")
      if ou != "N/A":
        ovpn_lines.append(f"{e}:{pw} | OVPN: {ou}:{op} | PPTP: {pu}:{pp}")
    for plan, items in by_plan.items():
      safe_plan = re.sub(r"[^a-zA-Z0-9._\-]", "_", str(plan)) or "Active"
      zf.writestr(f"plans/{safe_plan}.txt", "\n".join(items))
    if lic_lines:
      zf.writestr("licenses.txt", "\n".join(lic_lines))
    if ovpn_lines:
      zf.writestr("ovpn_credentials.txt", "\n".join(ovpn_lines))

  if mode == "duolingo":
    by_plan = defaultdict(list)
    inv_lines = []
    for e, pw, meta in normalized:
      plan = meta.get("plan", "Duolingo Super")
      full_line = format_full_capture_line(e, pw, meta, mode)
      by_plan[plan].append(full_line)
      inv = meta.get("invite", "")
      if inv:
        inv_lines.append(f"{e}:{pw} | Invite: {inv} | Country: {resolve_country_code(e, meta)} | Expiry: {meta.get('expiry', 'N/A')}")
    for plan, items in by_plan.items():
      safe_plan = re.sub(r"[^a-zA-Z0-9._\-]", "_", str(plan)) or "Super"
      zf.writestr(f"plans/{safe_plan}.txt", "\n".join(items))
    if inv_lines:
      zf.writestr("family_invites.txt", "\n".join(inv_lines))


def _build_zip_buf(valid_list, mode, free_list=None):
  buf = io.BytesIO()
  with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
    _fill_zip(zf, valid_list, mode, free_list=free_list)
  buf.seek(0)
  return buf


def build_zip_chunks(valid_list, mode, free_list=None):
  if not valid_list and not free_list:
    return []

  per_item_estimate = {
      "imap": 15_000,
      "inbox": 5_000,
      "full": 8_000,
      "xbox": 800,
      "minecraft": 400,
      "hotmail": 350,
      "crunchyroll": 500,
      "capcut": 500,
      "cupcut": 500,
      "express": 600,
      "duolingo": 500,
  }.get(mode, 400)
  estimated_size = per_item_estimate * (
      len(valid_list) + len(free_list or [])
  )

  if estimated_size > MAX_ZIP_SIZE_BYTES * 0.8 and len(valid_list) > 1:
    ratio = MAX_ZIP_SIZE_BYTES / estimated_size
    batch_size = max(1, int(len(valid_list) * ratio * 0.85))
    batches = [
        valid_list[i : i + batch_size]
        for i in range(0, len(valid_list), batch_size)
    ]
    n = len(batches)
    return [
        (
            _build_zip_buf(
                batch, mode, free_list=(free_list if idx == 1 else None)
            ),
            idx,
            n,
            len(batch),
        )
        for idx, batch in enumerate(batches, 1)
    ]

  buf = _build_zip_buf(valid_list, mode, free_list=free_list)
  size = buf.seek(0, 2)
  buf.seek(0)

  if size <= MAX_ZIP_SIZE_BYTES or len(valid_list) <= 1:
    return [(buf, 1, 1, len(valid_list))]

  ratio = MAX_ZIP_SIZE_BYTES / size
  batch_size = max(1, int(len(valid_list) * ratio * 0.85))
  batches = [
      valid_list[i : i + batch_size]
      for i in range(0, len(valid_list), batch_size)
  ]
  n = len(batches)
  return [
      (
          _build_zip_buf(
              batch, mode, free_list=(free_list if idx == 1 else None)
          ),
          idx,
          n,
          len(batch),
      )
      for idx, batch in enumerate(batches, 1)
  ]


# ═══════════════ PROXY VERIFY ═══════════════
def verify_proxy_sample(sid=None):
  tot, healthy, quar = get_proxy_health_summary()
  info_parts = [f"Static={healthy}/{tot} healthy ({quar} cooldown)"]
  ok_any = healthy > 0
  if PROXY_PASS:
    try:
      sid = sid or gen_session_id()
      url = (
          f"http://{PROXY_USER_BASE}{sid}:{PROXY_PASS}@{PROXY_HOST}:{PROXY_PORT}"
      )
      r = requests.get(
          "https://api.ipify.org?format=json",
          proxies={"http": url, "https": url},
          timeout=10,
          verify=False,
      )
      if r.status_code == 200:
        ip = r.json().get("ip", "?")
        info_parts.append(f"Residential=OK(IP={ip})")
        ok_any = True
      else:
        info_parts.append(f"Residential=HTTP_{r.status_code}")
    except Exception as e:
      info_parts.append(f"Residential={type(e).__name__}")
  return ok_any, " | ".join(info_parts)


# ═══════════════ SECURE HEALTH CHECK SERVER (LOCALHOST ONLY) ═══════════════
def start_health_server(host=None, port=None):
  """Bind health server strictly to 127.0.0.1 (or configured host) with optional token check."""
  host = host or HEALTH_HOST
  port = port or HEALTH_PORT

  class _Handler(http.server.BaseHTTPRequestHandler):

    def do_GET(self):
      if HEALTH_TOKEN:
        hdr_tok = self.headers.get("X-Health-Token", "")
        if hdr_tok != HEALTH_TOKEN:
          self.send_response(403)
          self.end_headers()
          self.wfile.write(b"Forbidden")
          return
      self.send_response(200)
      self.end_headers()
      self.wfile.write(b"OK")

    def log_message(self, *args):
      pass

  def _serve():
    try:
      httpd = http.server.HTTPServer((host, port), _Handler)
      httpd.serve_forever()
    except Exception as e:
      log("health", f"server error on {host}:{port}: {e}", "WARN")

  threading.Thread(target=_serve, daemon=True).start()


# ═══════════════ MODE LABELS ═══════════════
MODE_LABELS = {
    "hotmail": "📧 Hotmail Only",
    "inbox": "📦 Hotmail + Inbox",
    "full": "🔥 Full Hotmail",
    "xbox": "🎮 Xbox GamePass",
    "minecraft": "⛏ Minecraft Only",
    "imap": "✉️ Mix Mail (IMAP)",
    "crunchyroll": "🎬 Crunchyroll",
    "capcut": "✂️ CapCut",
    "cupcut": "✂️ CapCut",
    "express": "🛡 ExpressVPN",
    "duolingo": "🦉 Duolingo",
}


# ═══════════════ CHECKJOB ═══════════════
class CheckJob:

  def __init__(self, chat_id, combos, mode="hotmail", file_label="combos.txt"):
    self.chat_id = chat_id
    self.combos = combos
    self.mode = "capcut" if mode == "cupcut" else mode
    self.file_label = file_label
    self.total = len(combos)
    self.processed = 0
    self.extracting = 0
    self.valid = 0
    self.free = 0
    self.twofa = 0
    self.bad = 0
    self.net = 0
    self.skip = 0
    self.extracted = 0
    self.throttled = 0
    self.retried = 0
    self.recovered = 0
    self.gamepass = 0
    self.minecraft = 0
    self.with_cards = 0
    self.with_balance = 0
    self.imap_locked = 0
    self.imap_expired = 0
    self.imap_rate_limited = 0
    self.unclear = 0
    self.start_time = time.time()
    self.elapsed_before_pause = 0
    self.end_time = None
    self.completed = False
    self._cancel_event = threading.Event()
    self.resumed = False
    self.valid_list = []
    self.free_list = []
    self.done_keys = set()
    self.status_msg_id = None
    self.lock = threading.Lock()

  @property
  def cancelled(self):
    return self._cancel_event.is_set()

  @cancelled.setter
  def cancelled(self, val):
    if val:
      self._cancel_event.set()
    else:
      self._cancel_event.clear()

  @property
  def mode_label(self):
    return MODE_LABELS.get(self.mode, self.mode)

  @property
  def imap_mode(self):
    return self.mode == "imap"

  @property
  def xbox_mode(self):
    return self.mode == "xbox"

  @property
  def minecraft_mode(self):
    return self.mode == "minecraft"

  @property
  def inbox_mode(self):
    return self.mode == "inbox"

  @property
  def full_mode(self):
    return self.mode == "full"
